$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$toolDir = Join-Path $root '.build-tools'
$env:JAVA_HOME = (Get-ChildItem "$toolDir/jdk" -Directory | Select-Object -First 1).FullName
$env:ANDROID_HOME = "$toolDir/sdk"
$env:GRADLE_USER_HOME = "$toolDir/gradle"
Push-Location "$root/android"
try {
    & ./gradlew.bat testDebugUnitTest assembleDebug --console=plain
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed: $LASTEXITCODE" }
} finally {
    Pop-Location
}
