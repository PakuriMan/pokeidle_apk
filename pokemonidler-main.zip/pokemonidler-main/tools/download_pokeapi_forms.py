"""Download every PokéAPI pokemon-form front/default and shiny sprite."""
import concurrent.futures
import json
import pathlib
import re
import sys
import time
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "android" / "app" / "src" / "main" / "assets"
API = "https://pokeapi.co/api/v2"
HEADERS = {"User-Agent": "PokeIdle-FormSpriteLoader/1.0 (offline asset sync)"}


def get_json(url):
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=40) as response:
                return json.load(response)
        except Exception:
            if attempt == 4:
                raise
            time.sleep(0.5 * (attempt + 1))


def get_bytes(url):
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=40) as response:
                return response.read()
        except Exception:
            if attempt == 4:
                return None
            time.sleep(0.5 * (attempt + 1))


def resource_id(url):
    match = re.search(r"/(\d+)/?$", url or "")
    return int(match.group(1)) if match else None


def fetch_detail(entry):
    return get_json(entry["url"])


def fetch_pokemon(url):
    return get_json(url)


def download_sprite(task):
    url, path = task
    data = get_bytes(url)
    if data and data.startswith(b"\x89PNG\r\n\x1a\n"):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return str(path.relative_to(ASSETS)).replace("\\", "/")
    return None


def main():
    forms_index = get_json(f"{API}/pokemon-form?limit=10000")
    entries = forms_index["results"]
    print(f"PokéAPI lists {len(entries)} forms", flush=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        details = list(pool.map(fetch_detail, entries))
    print(f"Loaded metadata for {len(details)} forms", flush=True)

    pokemon_urls = sorted({detail["pokemon"]["url"] for detail in details})
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        pokemon_data = list(pool.map(fetch_pokemon, pokemon_urls))
    pokemon_by_url = {url: data for url, data in zip(pokemon_urls, pokemon_data)}
    print(f"Resolved {len(pokemon_by_url)} Pokémon records", flush=True)

    rows = []
    sprite_tasks = []
    for detail in details:
        pid = resource_id(detail["pokemon"]["url"])
        pokemon = pokemon_by_url[detail["pokemon"]["url"]]
        species_id = resource_id(pokemon["species"]["url"])
        form_id = detail["id"]
        sprites = detail.get("sprites") or {}
        fallback = pokemon.get("sprites") or {}
        other = fallback.get("other") or {}
        home = other.get("home") or {}
        artwork = other.get("official-artwork") or {}
        default_url = sprites.get("front_default") or fallback.get("front_default") or home.get("front_default") or artwork.get("front_default")
        shiny_url = sprites.get("front_shiny") or fallback.get("front_shiny") or home.get("front_shiny") or artwork.get("front_shiny")
        default_path = f"pokemon_forms/{form_id}.png"
        shiny_path = f"pokemon_forms/shiny/{form_id}.png"
        row = {
            "speciesId": species_id,
            "pokemonId": pid,
            "formId": form_id,
            "name": detail["name"],
            "formName": detail.get("form_name") or "",
            "isDefault": bool(detail.get("is_default")),
            "defaultSprite": default_path if default_url else None,
            "shinySprite": shiny_path if shiny_url else None,
        }
        rows.append(row)
        if default_url:
            sprite_tasks.append((default_url, ASSETS / default_path))
        if shiny_url:
            sprite_tasks.append((shiny_url, ASSETS / shiny_path))

    with concurrent.futures.ThreadPoolExecutor(max_workers=24) as pool:
        sprite_paths = list(pool.map(download_sprite, sprite_tasks))
    downloaded = {path for path in sprite_paths if path}
    for row in rows:
        if row["defaultSprite"] not in downloaded:
            row["defaultSprite"] = None
        if row["shinySprite"] not in downloaded:
            row["shinySprite"] = None

    output = ASSETS / "pokemon_forms.json"
    output.write_text(json.dumps({"forms": rows}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    default_count = sum(row["defaultSprite"] is not None for row in rows)
    shiny_count = sum(row["shinySprite"] is not None for row in rows)
    print(f"Saved {output}; default={default_count}, shiny={shiny_count}, forms={len(rows)}", flush=True)
    print(f"Forms missing default sprites: {sum(row['defaultSprite'] is None for row in rows)}", flush=True)
    print(f"Forms missing shiny sprites: {sum(row['shinySprite'] is None for row in rows)}", flush=True)


if __name__ == "__main__":
    main()
