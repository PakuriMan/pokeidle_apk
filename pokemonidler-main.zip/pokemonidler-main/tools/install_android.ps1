param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
try {
    $paths = @("$root/.build-tools/sdk/platform-tools/adb.exe", "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe", "$env:ANDROID_HOME/platform-tools/adb.exe", "$env:ANDROID_SDK_ROOT/platform-tools/adb.exe")
    $adb = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (!$adb) { $adb = (Get-Command adb.exe -ErrorAction SilentlyContinue).Source }
    if (!$adb) { throw 'ADB not found. Install Android SDK platform-tools.' }
    $apk = "$root/android/app/build/outputs/apk/debug/app-debug.apk"
    Write-Host "ADB: $adb"
    if ($CheckOnly) { Write-Host "APK exists: $(Test-Path $apk)"; exit 0 }
    if (!(Test-Path $apk)) { & "$PSScriptRoot/build_android.ps1" }
    if (!(Test-Path $apk)) { throw 'APK not found.' }
    Write-Host 'Connect phone via USB and approve USB debugging on its screen.'
    $deadline = (Get-Date).AddMinutes(2)
    do {
        $output = & $adb devices
        if ($LASTEXITCODE -ne 0) { throw 'ADB discovery failed.' }
        $devices = @($output | Where-Object { $_ -match '^\S+\s+device\s*$' } | ForEach-Object { ($_ -split '\s+')[0] })
        if ($devices.Count -gt 1) { throw 'Multiple devices: leave only the target phone connected.' }
        if ($devices.Count -eq 1) { break }
        Write-Host 'Waiting for phone. Enable USB debugging and approve the prompt on phone.'
        Start-Sleep -Seconds 3
    } while ((Get-Date) -lt $deadline)
    if ($devices.Count -ne 1) { throw 'No authorized phone found within 2 minutes.' }
    & $adb -s $devices[0] install -r $apk
    if ($LASTEXITCODE -ne 0) { throw 'Installation failed. See ADB error above. App data has not been deleted.' }
    $launch = & $adb -s $devices[0] shell am start -W -n 'com.pokeidle.app.debug/com.pokeidle.app.presentation.MainActivity' 2>&1
    $code = $LASTEXITCODE
    $launch | ForEach-Object { Write-Host $_ }
    if ($code -ne 0 -or ($launch -match 'Error:|Exception')) { throw 'Installed, but launch failed.' }
    Write-Host 'Installation and launch completed.'
    exit 0
} catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
