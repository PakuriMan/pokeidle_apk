param([string]$SdkRoot = "$env:LOCALAPPDATA\Android\Sdk")
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$signingRoot = Join-Path $projectRoot '.release-signing'
$outputRoot = Join-Path $projectRoot 'android/app/build/outputs/apk/release'
$buildTools = Join-Path $SdkRoot 'build-tools/36.0.0'
$unsignedApk = Join-Path $outputRoot 'app-release-unsigned.apk'
$alignedApk = Join-Path $outputRoot 'app-release-aligned.apk'
$releaseApk = Join-Path $outputRoot 'PokeIdle-1.0-release.apk'
& (Join-Path $buildTools 'zipalign.exe') -f -p 4 $unsignedApk $alignedApk
if ($LASTEXITCODE -ne 0) { throw 'APK alignment failed' }
& (Join-Path $buildTools 'apksigner.bat') sign --ks (Join-Path $signingRoot 'release.jks') --ks-key-alias pokeidle --ks-pass "file:$(Join-Path $signingRoot 'password.txt')" --out $releaseApk $alignedApk
if ($LASTEXITCODE -ne 0) { throw 'APK signing failed' }
& (Join-Path $buildTools 'apksigner.bat') verify $releaseApk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed' }
Write-Output $releaseApk

