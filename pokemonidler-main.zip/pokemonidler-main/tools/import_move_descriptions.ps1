$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$uri = 'https://raw.githubusercontent.com/PokeAPI/pokeapi/master/data/v2/csv/move_flavor_text.csv'
$rows = (Invoke-WebRequest $uri -UseBasicParsing -TimeoutSec 60).Content | ConvertFrom-Csv
$ko = @{}
foreach ($row in ($rows | Where-Object language_id -eq '3' | Sort-Object { [int]$_.version_group_id })) {
    $ko[$row.move_id] = ($row.flavor_text -replace '\s+', ' ').Trim()
}
$path = Join-Path $root 'android/app/src/main/assets/damaging_moves.json'
$data = Get-Content $path -Raw -Encoding utf8 | ConvertFrom-Json
$count = 0
foreach ($property in $data.moves.PSObject.Properties) {
    if ($ko.ContainsKey($property.Name)) {
        $property.Value | Add-Member -NotePropertyName txt -NotePropertyValue $ko[$property.Name] -Force
        $count++
    }
}
$data | ConvertTo-Json -Depth 12 -Compress | Set-Content $path -Encoding utf8
Write-Output "Korean descriptions imported: $count"
