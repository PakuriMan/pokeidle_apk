using System;
using System.Diagnostics;
using System.IO;
class InstallerLauncher {
    static int Main(string[] args) {
        int code = 1;
        bool check = Array.IndexOf(args, "--check") >= 0;
        try {
            string root = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(root, "tools", "install_android.ps1");
            if (!File.Exists(script)) throw new Exception("Keep EXE in project folder.");
            string shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
            var info = new ProcessStartInfo(shell, "-NoProfile -ExecutionPolicy Bypass -File \"" + script + "\"" + (check ? " -CheckOnly" : ""));
            info.WorkingDirectory = root;
            info.UseShellExecute = false;
            using (var process = Process.Start(info)) { process.WaitForExit(); code = process.ExitCode; }
        } catch (Exception e) { Console.WriteLine("ERROR: " + e.Message); }
        if (!check) { Console.WriteLine("Press Enter to close."); Console.ReadLine(); }
        return code;
    }
}
