package com.pokeidle.app

import com.pokeidle.app.domain.math.BattleMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.pow

class BattleMathTest {

    @Test
    fun testLogAdd() {
        // 10^2 + 10^2 = 200 -> log10(200) ~= 2.30103
        val result = BattleMath.logAdd(2.0, 2.0)
        assertEquals(2.30103, result, 0.0001)

        // a >> b (차이가 16 초과) -> 큰 쪽 유지
        val bigResult = BattleMath.logAdd(100.0, 10.0)
        assertEquals(100.0, bigResult, 0.0001)
    }

    @Test
    fun testLogSub() {
        // 10^3 - 10^2 = 900 -> log10(900) ~= 2.95424
        val result = BattleMath.logSub(3.0, 2.0)
        assertEquals(2.95424, result, 0.0001)

        // a <= b -> -300
        val underflow = BattleMath.logSub(2.0, 3.0)
        assertEquals(-300.0, underflow, 0.0001)
    }

    @Test
    fun testSpeedFold() {
        // n <= 1 -> 그대로 반환
        assertEquals(0.5, BattleMath.speedFold(0.5), 0.0001)
        assertEquals(1.0, BattleMath.speedFold(1.0), 0.0001)

        // n = 10 -> 1 + log2(1 + log10(10)) = 1 + log2(2) = 2.0
        assertEquals(2.0, BattleMath.speedFold(10.0), 0.0001)
    }

    @Test
    fun testEnemyHpL() {
        // species baseHp = 40, lvl = 1 -> 40 * 1.5 = 60
        val hpSpecies = BattleMath.enemyHpL(40.0, 1)
        assertEquals(60.0, 10.0.pow(hpSpecies), 0.01)

        // fallback lvl = 1 -> log10(1500)
        val hp1 = BattleMath.enemyHpL(1)
        assertEquals(1500.0, 10.0.pow(hp1), 0.01)

        // fallback lvl = 2 -> 1500 * 1.12 = 1680
        val hp2 = BattleMath.enemyHpL(2)
        assertEquals(1680.0, 10.0.pow(hp2), 0.01)
    }

    @Test
    fun testCalcOverkillExtra() {
        // r < 1 -> 0
        assertEquals(0, BattleMath.calcOverkillExtra(0.9, isUnderMaxLevel = false))

        // r = 10 -> log10(10)=1 -> floor(log2(1)) + 1 = 1
        assertEquals(1, BattleMath.calcOverkillExtra(10.0, isUnderMaxLevel = false))

        // r = 100 -> log10(100)=2 -> floor(log2(2)) + 1 = 2
        assertEquals(2, BattleMath.calcOverkillExtra(100.0, isUnderMaxLevel = false))

        // r = 10^30 -> log10(r)=30 -> floor(log2(30)) + 1 = 4 + 1 = 5
        val extra30 = BattleMath.calcOverkillExtra(1e30, isUnderMaxLevel = false)
        assertEquals(5, extra30)

        // r = 10^300 (최대 연쇄 상한 테스트) -> log10(r)=300 -> floor(log2(300)) + 1 = 8 + 1 = 9
        val extra300 = BattleMath.calcOverkillExtra(1e300, isUnderMaxLevel = false)
        assertEquals(9, extra300)

        // 극단적 수치 상한 검증
        val extraCapped = BattleMath.calcOverkillExtra(Double.MAX_VALUE, isUnderMaxLevel = false)
        assertTrue(extraCapped <= 10)

        val extraUnderMaxCapped = BattleMath.calcOverkillExtra(Double.MAX_VALUE, isUnderMaxLevel = true)
        assertTrue(extraUnderMaxCapped <= 100)
    }

    @Test
    fun testFmtL() {
        assertEquals("0", BattleMath.fmtL(Double.NaN))
        // 10^2 = 100 -> "100"
        assertEquals("100", BattleMath.fmtL(2.0))
        // 10^3 = 1000 -> "1.00K"
        assertEquals("1.00K", BattleMath.fmtL(3.0))
        // 10^6 = 1M -> "1.00M"
        assertEquals("1.00M", BattleMath.fmtL(6.0))
    }

    @Test
    fun testTkCost() {
        assertEquals(10, BattleMath.tkCost(0))
        assertEquals(11, BattleMath.tkCost(1))
        assertEquals(12, BattleMath.tkCost(2))
    }

    @Test
    fun testFormatNumber() {
        assertEquals("0", BattleMath.formatNumber(0.0))
        assertEquals("0", BattleMath.formatNumber(-10.0))
        assertEquals("0", BattleMath.formatNumber(Double.NaN))
        assertEquals("0.5", BattleMath.formatNumber(0.5))
        assertEquals("1", BattleMath.formatNumber(1.0))
        assertEquals("25", BattleMath.formatNumber(25.0))
        assertEquals("999", BattleMath.formatNumber(999.0))
        assertEquals("1.00K", BattleMath.formatNumber(1000.0))
        assertEquals("1.50K", BattleMath.formatNumber(1500.0))
        assertEquals("12.5K", BattleMath.formatNumber(12500.0))
        assertEquals("100K", BattleMath.formatNumber(100000.0))
        assertEquals("1.00M", BattleMath.formatNumber(1000000.0))
        assertEquals("2.50M", BattleMath.formatNumber(2500000.0))
        assertEquals("50.0M", BattleMath.formatNumber(50000000.0))
        assertEquals("350M", BattleMath.formatNumber(350000000.0))
        assertEquals("1.00B", BattleMath.formatNumber(1000000000.0))
        assertEquals("12.5B", BattleMath.formatNumber(12500000000.0))
        assertEquals("1.50T", BattleMath.formatNumber(1500000000000.0))
    }
}
