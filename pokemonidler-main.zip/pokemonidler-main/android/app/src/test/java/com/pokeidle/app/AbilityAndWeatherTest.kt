package com.pokeidle.app

import com.pokeidle.app.data.repository.DefaultPokemonRepository
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.system.AbilitySystem
import com.pokeidle.app.domain.system.WeatherTerrainSystem
import com.pokeidle.app.domain.system.WeatherType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.FileInputStream

class AbilityAndWeatherTest {

    private lateinit var repository: DefaultPokemonRepository

    @Before
    fun setUp() {
        repository = DefaultPokemonRepository()
        val assetsFile = File("src/main/assets/data.json")
        FileInputStream(assetsFile).use { stream ->
            repository.loadData(stream)
        }
    }

    @Test
    fun testWeatherResolutionAndOverrides() {
        // 그란돈 (가뭄 특성 ID: 70) joined = 10
        val groudon = AllyMon(id = 383, ab = 70, joined = 10L)
        // 가이오가 (잔비 특성 ID: 2) joined = 20 (나중에 합류)
        val kyogre = AllyMon(id = 382, ab = 2, joined = 20L)

        val team = listOf(groudon, kyogre)

        val weather = WeatherTerrainSystem.resolveWeather(team) {
            AbilitySystem.getEffectiveAbilityName(it, team, repository)
        }
        assertNotNull(weather)
        // 나중에 합류한 가이오가의 잔비(비)가 적용되어야 함
        assertEquals(WeatherType.RAIN, weather!!.weather)
        assertEquals(kyogre, weather.setter)
    }

    @Test
    fun testWeatherSuppressionByAirLock() {
        val groudon = AllyMon(id = 383, ab = 70, joined = 10L) // 가뭄
        val rayquaza = AllyMon(id = 384, ab = 76, joined = 30L) // 에어록 (특성 ID: 76)

        val team = listOf(groudon, rayquaza)

        val weather = WeatherTerrainSystem.resolveWeather(team) {
            AbilitySystem.getEffectiveAbilityName(it, team, repository)
        }
        // 에어록에 의해 날씨가 무효화되어야 함
        assertNull("Weather must be nullified by Air Lock", weather)
    }

    @Test
    fun testNeutralizingGasSuppressesOtherAbilities() {
        // 또도가스 (화학변화가스 특성 ID: 256)
        val weezing = AllyMon(id = 110, ab = 256, slot = 0)
        // 피카츄 (정전기 특성 ID: 9)
        val pikachu = AllyMon(id = 25, ab = 9, slot = 1)

        val team = listOf(weezing, pikachu)

        val weezingAb = AbilitySystem.getEffectiveAbilityName(weezing, team, repository)
        val pikachuAb = AbilitySystem.getEffectiveAbilityName(pikachu, team, repository)

        assertEquals("화학변화가스", weezingAb)
        assertNull("Pikachu's ability must be suppressed by Neutralizing Gas", pikachuAb)
    }
}
