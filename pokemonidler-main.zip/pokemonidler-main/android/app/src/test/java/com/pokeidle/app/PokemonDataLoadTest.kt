package com.pokeidle.app

import com.pokeidle.app.data.repository.DefaultPokemonRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileInputStream

class PokemonDataLoadTest {

    @Test
    fun testLoadGameData() {
        val assetsFile = File("src/main/assets/data.json")
        assertTrue("data.json asset file must exist", assetsFile.exists())
        assertTrue("data.json size should be greater than 1MB", assetsFile.length() > 1_000_000)

        val repo = DefaultPokemonRepository()
        FileInputStream(assetsFile).use { stream ->
            FileInputStream(File("src/main/assets/pokemon_forms.json")).use { formsStream ->
                repo.loadData(stream, pokemonFormsStream = formsStream)
            }
        }

        assertTrue("Repository should be loaded", repo.isLoaded())

        // Official origin forms must not inherit their base species stats.
        val palkiaOrigin = repo.getPokemon(10246)!!
        assertEquals(listOf(90, 100, 100, 150, 120, 120), listOf(palkiaOrigin.hp, palkiaOrigin.atk, palkiaOrigin.def, palkiaOrigin.spa, palkiaOrigin.sdf, palkiaOrigin.spd))
        val dialgaOrigin = repo.getPokemon(10245)!!
        assertEquals(100, dialgaOrigin.atk)
        assertEquals(120, dialgaOrigin.sdf)

        val hisuiTyphlosion = repo.getAllFormViews(157).first { it.formKey == "form_10233" }
        assertEquals("pokemon_forms/shiny/10402.png", hisuiTyphlosion.shinySpriteAssetName)
        val formsJson = kotlinx.serialization.json.Json.parseToJsonElement(File("src/main/assets/pokemon_forms.json").readText())
        val entries = (formsJson as kotlinx.serialization.json.JsonObject)["forms"] as kotlinx.serialization.json.JsonArray
        entries.forEach { entry ->
            val obj = entry as kotlinx.serialization.json.JsonObject
            val name = (obj["name"] as kotlinx.serialization.json.JsonPrimitive).content
            if (listOf("hisui", "alola", "galar", "paldea").any { name.contains(it) }) {
                val path = (obj["shinySprite"] as kotlinx.serialization.json.JsonPrimitive).content
                assertTrue("Missing shiny regional sprite: $name", File("src/main/assets/$path").length() > 0)
            }
        }

        // 1,025종 포켓몬 도감 로드 확인
        val all = repo.getAllPokemon()
        assertEquals(1027, all.size)
        assertEquals(999, repo.getPokemon(1027)!!.atk)
        assertEquals(repo.getPokemon(384)!!.moves, repo.getPokemon(1027)!!.moves)
        assertEquals(999, repo.getMegas(1027).first().spa)
        val hidden = repo.getPokemon(1026)!!
        val lugia = repo.getPokemon(249)!!
        assertEquals(lugia.moves, hidden.moves)
        assertEquals(lugia.atk, hidden.atk)
        assertEquals(lugia.spa, hidden.spa)
        assertEquals("shadow_lugia.png", repo.getPokemonFormSpriteAsset(1026))

        // 이상해씨 확인
        val bulbasaur = repo.getPokemon(1)
        assertNotNull(bulbasaur)
        assertEquals("이상해씨", bulbasaur!!.ko)
        assertEquals(listOf(12, 4), bulbasaur.types) // 풀/독

        // 피카츄 확인
        val pikachu = repo.getPokemon(25)
        assertNotNull(pikachu)
        assertEquals("피카츄", pikachu!!.ko)
        assertEquals(listOf(13), pikachu.types) // 전기

        // 폼체인지 확인 (알로라 꼬렛 10091)
        val alolanRattata = repo.getPokemon(10091)
        assertNotNull(alolanRattata)
        assertEquals("알로라 꼬렛", alolanRattata!!.ko)

        // 기술 로드 확인 (10만볼트 85 등)
        val tbolt = repo.getMove(85)
        assertNotNull(tbolt)
        assertEquals("10만볼트", tbolt!!.ko)
        assertEquals(13, tbolt.t)
        assertEquals(90.0, tbolt.p, 0.001)

        // 스타터 목록 28종 확인
        val starters = repo.getStarters()
        assertEquals(28, starters.size)

        // 상성표 확인 (불꽃 10 -> 풀 12: 2.0배, 노말 1 -> 고스트 8: 무효 0.1배)
        val fireOnGrass = repo.getTypeEff(10, listOf(12))
        assertEquals(2.0, fireOnGrass, 0.001)

        val normalOnGhost = repo.getTypeEff(1, listOf(8))
        assertEquals(0.1, normalOnGhost, 0.001) // 0배 무효는 0.1배 변환

        // 도감 상세 폼 선택 토글 검증 (리자몽, 네크로즈마, 라이츄, 캐스퐁)
        val charizardForms = repo.getAllFormViews(6)
        assertTrue("Charizard should have at least 3 forms (base, megaX, megaY)", charizardForms.size >= 3)
        assertEquals("기본 폼", charizardForms[0].label)
        assertTrue(charizardForms.any { it.label == "메가X" })
        assertTrue(charizardForms.any { it.label == "메가Y" })
        assertEquals(2, charizardForms.count { it.formKey.startsWith("mega_") })
        assertFalse("English PokéAPI aliases should not duplicate Mega X/Y", charizardForms.any {
            it.label.equals("Mega X", ignoreCase = true) || it.label.equals("Mega Y", ignoreCase = true)
        })

        // 네크로즈마 4대 폼 (기본 폼, 황혼의 갈기, 새벽의 날개, 울트라폼) 검증
        val necrozmaForms = repo.getAllFormViews(800)
        assertEquals(4, necrozmaForms.size)
        assertEquals("기본 폼", necrozmaForms[0].label)
        assertTrue("Dusk Mane should exist", necrozmaForms.any { it.label == "황혼의 갈기" })
        assertTrue("Dawn Wings should exist", necrozmaForms.any { it.label == "새벽의 날개" })
        assertTrue("Ultra should exist", necrozmaForms.any { it.label == "울트라폼" })

        val duskMane = necrozmaForms.first { it.label == "황혼의 갈기" }
        assertEquals(listOf(14, 9), duskMane.types) // 에스퍼 / 강철
        assertEquals(157, duskMane.atk)
        assertTrue(duskMane.img.startsWith("data:image/png;base64,"))

        val dawnWings = necrozmaForms.first { it.label == "새벽의 날개" }
        assertEquals(listOf(14, 8), dawnWings.types) // 에스퍼 / 고스트
        assertEquals(157, dawnWings.spa)
        assertTrue(dawnWings.img.startsWith("data:image/png;base64,"))

        // 울트라 네크로즈마 공식 종족값 (HP 97, ATK 167, DEF 97, SPA 167, SDF 97, SPD 129) 검증
        val ultraNecrozma = necrozmaForms.first { it.label == "울트라폼" }
        assertEquals(97, ultraNecrozma.hp)
        assertEquals(167, ultraNecrozma.atk)
        assertEquals(97, ultraNecrozma.def)
        assertEquals(167, ultraNecrozma.spa)
        assertEquals(97, ultraNecrozma.sdf)
        assertEquals(129, ultraNecrozma.spd)

        // 메가리자몽 X 공식 종족값 (HP 78, ATK 130, DEF 111, SPA 130, SDF 85, SPD 100) 검증
        val charizardX = charizardForms.first { it.label == "메가X" }
        assertEquals(78, charizardX.hp)
        assertEquals(130, charizardX.atk)
        assertEquals(111, charizardX.def)
        assertEquals(130, charizardX.spa)
        assertEquals(85, charizardX.sdf)
        assertEquals(100, charizardX.spd)

        // 불비달마 달마모드 (555) 공식 종족값 (HP 105, ATK 30, DEF 105, SPA 140, SDF 105, SPD 55) 검증
        val darmanitanForms = repo.getAllFormViews(555)
        val zenMode = darmanitanForms.first { it.formKey == "alt_zen" || it.label.contains("달마") || it.label == "zen" }
        assertEquals(105, zenMode.hp)
        assertEquals(30, zenMode.atk)
        assertEquals(105, zenMode.def)
        assertEquals(140, zenMode.spa)
        assertEquals(105, zenMode.sdf)
        assertEquals(55, zenMode.spd)

        // 약어리 군집의 모습 (746) 공식 종족값 (HP 45, ATK 140, DEF 130, SPA 140, SDF 135, SPD 30) 검증
        val wishiwashiForms = repo.getAllFormViews(746)
        val schoolForm = wishiwashiForms.first { it.formKey == "alt_school" || it.label.contains("군집") || it.label == "school" }
        assertEquals(45, schoolForm.hp)
        assertEquals(140, schoolForm.atk)
        assertEquals(130, schoolForm.def)
        assertEquals(140, schoolForm.spa)
        assertEquals(135, schoolForm.sdf)
        assertEquals(30, schoolForm.spd)

        // 솔가레오 & 루나아라 연동 검증
        val solgaleoForms = repo.getAllFormViews(791)
        assertTrue("Solgaleo should have Dusk Mane form", solgaleoForms.any { it.label == "황혼의 갈기" })

        val lunalaForms = repo.getAllFormViews(792)
        assertTrue("Lunala should have Dawn Wings form", lunalaForms.any { it.label == "새벽의 날개" })

        val raichuForms = repo.getAllFormViews(26)
        assertTrue("Raichu should have Alolan form", raichuForms.any { it.label == "알로라" })

        val castformForms = repo.getAllFormViews(351)
        assertTrue("Castform should have weather forms", castformForms.size >= 4)

        // 지가르데 폼별 공식 종족치 (PokéAPI 기준)와 메가폼 정규값 검증
        val zygardeForms = repo.getAllFormViews(718)
        val zygardeTen = zygardeForms.first { it.formKey == "api_form_10340" }
        assertEquals(listOf(54, 100, 71, 61, 85, 115), listOf(zygardeTen.hp, zygardeTen.atk, zygardeTen.def, zygardeTen.spa, zygardeTen.sdf, zygardeTen.spd))
        val zygardeFifty = zygardeForms.first { it.formKey.startsWith("base_") }
        assertEquals(listOf(108, 100, 121, 81, 95, 95), listOf(zygardeFifty.hp, zygardeFifty.atk, zygardeFifty.def, zygardeFifty.spa, zygardeFifty.sdf, zygardeFifty.spd))
        val zygardeComplete = zygardeForms.first { it.formKey == "api_form_10222" }
        assertEquals(listOf(216, 100, 121, 91, 95, 85), listOf(zygardeComplete.hp, zygardeComplete.atk, zygardeComplete.def, zygardeComplete.spa, zygardeComplete.sdf, zygardeComplete.spd))
        val megaZygarde = zygardeForms.first { it.formKey == "mega_10301" }
        assertEquals(listOf(216, 70, 91, 216, 85, 100), listOf(megaZygarde.hp, megaZygarde.atk, megaZygarde.def, megaZygarde.spa, megaZygarde.sdf, megaZygarde.spd))

        // PokéAPI 기반 배울 수 있는 위력(데미지) 기술 재구성 검증
        // 1. 피카츄 (25번)
        val pikachuMoves = pikachu.moves
        assertTrue("Pikachu should have damaging moves from PokéAPI", pikachuMoves.isNotEmpty())
        pikachuMoves.forEach { mid ->
            val m = repo.getMove(mid)
            assertNotNull("Move $mid should exist", m)
            assertTrue("Move ${m?.ko} (id=$mid) must have power > 0 (power=${m?.p})", (m?.p ?: 0.0) > 0.0)
        }

        // 2. 리자몽 (6번)
        val charizard = repo.getPokemon(6)
        assertNotNull(charizard)
        assertTrue("Charizard should have >= 50 damaging moves", charizard!!.moves.size >= 50)
        charizard.moves.forEach { mid ->
            val m = repo.getMove(mid)
            assertNotNull(m)
            assertTrue("Charizard move ${m?.ko} must have power > 0", (m?.p ?: 0.0) > 0.0)
        }

        // 3. 네크로즈마 (800번) 및 모든 폼의 배움 기술이 오직 위력 있는 기술인지 검증
        val necrozma = repo.getPokemon(800)
        assertNotNull(necrozma)
        assertEquals(44, necrozma!!.moves.size)
        necrozmaForms.forEach { form ->
            assertTrue("Form ${form.label} should have damaging moves", form.moves.isNotEmpty())
            form.moves.forEach { mid ->
                val m = repo.getMove(mid)
                assertNotNull(m)
                assertTrue("Form move ${m?.ko} must have power > 0", (m?.p ?: 0.0) > 0.0)
            }
        }

        // 4. 도감의 모든 포켓몬 (1~1025)에 대해 배울 수 있는 기술은 오직 위력(power > 0) 기술만 존재해야 함
        all.forEach { p ->
            assertTrue("Pokemon ${p.id} (${p.ko}) must have at least 1 damaging move", p.moves.isNotEmpty())
            p.moves.forEach { mid ->
                val m = repo.getMove(mid)
                assertNotNull("Move $mid for ${p.ko} must exist", m)
                assertTrue("Move ${m?.ko} for ${p.ko} must have power > 0", (m?.p ?: 0.0) > 0.0)
            }
        }
    }
}
