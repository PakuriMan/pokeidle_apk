package com.pokeidle.app

import com.pokeidle.app.data.repository.DefaultPokemonRepository
import com.pokeidle.app.data.model.ZMoveData
import com.pokeidle.app.data.model.AchievementData
import com.pokeidle.app.domain.engine.BattleEngine
import com.pokeidle.app.domain.engine.BattleEvent
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.GameState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.FileInputStream

class BattleEngineTest {

    @Test
    fun shopSpendsOneCoinAndRejectsInvalidPurchase() {
        val state = GameState.createInitial(starterId = 25)
        val engine = BattleEngine(state, repository)
        val item = repository.getAllHeldItems().first().id
        assertFalse(engine.buyShopItem(item))
        state.coins = 2
        assertFalse(engine.buyShopItem("missing-item"))
        assertEquals(2L, state.coins)
        assertTrue(engine.buyShopItem(item))
        assertEquals(1L, state.coins)
        assertEquals(1, state.items[item])
        assertTrue(engine.buyShopItem(item))
        assertEquals(0L, state.coins)
        assertEquals(2, state.items[item])
        assertFalse(engine.buyShopItem(item))
    }
    @Test
    fun exclusiveZMovesRequireTheirSignatureMoves() {
        val entries = listOf(
            Triple("decidium", 724, 662), Triple("incinium", 727, 663), Triple("primarium", 730, 664),
            Triple("tapunium", 785, 717), Triple("marshadium", 802, 712), Triple("aloraichium", 10100, 85),
            Triple("snorlium", 143, 416), Triple("eevium", 133, 387), Triple("mewnium", 151, 94),
            Triple("lycanium", 745, 444), Triple("mimikium", 778, 583), Triple("kommonium", 784, 691),
            Triple("solganium", 791, 713), Triple("lunalium", 792, 714), Triple("pikanium", 25, 344), Triple("pikashunium", 10094, 85)
        )
        for ((key, species, moveId) in entries) {
            val item = "$key-z--held"
            assertNotNull(repository.getHeldItem(item))
            val move = repository.getMove(moveId)!!
            assertNotNull("Missing Z move: $key", ZMoveData.resolve(item, species, moveId, move.t, move.p))
            assertNull(ZMoveData.resolve(item, species, 33, move.t, 40.0))
        }
    }
    @Test
    fun collectorRequiresAll1025OrdinarySpecies() {
        val state = GameState.createInitial(starterId = 1)
        (1..1024).forEach { state.caught[it] = 1 }
        state.caught[1026] = 1
        state.caught[1027] = 1
        assertFalse(AchievementData.getAll(state, 1027).first { it.id == "dex" }.completed)
        state.caught[1025] = 1
        assertTrue(AchievementData.getAll(state, 1027).first { it.id == "dex" }.completed)
    }
    @Test
    fun primalRequiresMatchingOrbAndFullGauge() {
        for ((species, orb) in listOf(383 to "red-orb", 382 to "blue-orb")) {
            val state = GameState.createInitial(starterId = species)
            val ally = state.team.first()
            val engine = BattleEngine(state, repository)
            ally.mg = 100.0
            assertFalse(engine.canMegaEvolve(ally))
            ally.item = if (orb == "red-orb") "blue-orb" else "red-orb"
            engine.megaEvolve(ally)
            assertFalse(ally.isMega)
            ally.item = orb
            ally.mg = 99.9
            engine.megaEvolve(ally)
            assertFalse(ally.isMega)
            ally.mg = 100.0
            engine.megaEvolve(ally)
            assertTrue(ally.isMega)
            assertEquals(0.0, ally.mg, 0.0)
        }
    }
    @Test
    fun rayquazaAndPrimalTriggersSelectCorrectForms() {
        for ((species, item, expected) in listOf(Triple(384, null, 10079), Triple(383, "red-orb", 10078), Triple(382, "blue-orb", 10077))) {
            val state = GameState.createInitial(starterId = species)
            val ally = state.team.first()
            ally.item = item
            ally.move = if (species == 384) 620 else 33
            ally.mg = 100.0
            val engine = BattleEngine(state, repository)
            assertTrue(engine.canMegaEvolve(ally))
            engine.megaEvolve(ally)
            assertEquals(expected, ally.megaFormId)
            assertTrue(ally.isMega)
        }
    }
    @Test
    fun zygardeFusionConsumesBoxMaterialsAndPreservesSelectedShiny() {
        val state = GameState.createInitial(starterId = 25)
        val selected = AllyMon(id = 10181, joined = 10, slot = -1, isShiny = true, move = 687, lvl = 50)
        state.box.add(selected)
        val engine = BattleEngine(state, repository)
        assertTrue(!engine.evolve(selected, 718))
        (11..14).forEach { state.box.add(AllyMon(id = 10181, joined = it.toLong(), slot = -1)) }
        assertTrue(engine.evolve(selected, 718))
        assertEquals(1, state.box.size)
        assertTrue(selected.isShiny)
        assertEquals(687, selected.move)
        state.box.add(AllyMon(id = 718, joined = 15, slot = -1, ab = 188))
        selected.ab = 188
        assertTrue(!engine.evolve(selected, 10120))
        selected.ab = 211
        assertTrue(engine.evolve(selected, 10120))
        assertEquals(1, state.box.size)
        assertTrue(selected.isShiny)
        val stone = repository.getAllHeldItems().first { it.ko == "지가르데나이트" }
        state.items[stone.id] = 1
        assertTrue(engine.equipItem(selected, stone.id))
        selected.mg = 100.0
        engine.megaEvolve(selected)
        assertEquals(10301, selected.megaFormId)
        assertEquals("니힐레이저", repository.getBattleMove(selected)?.ko)
        engine.megaRevert(selected)
        assertEquals(687, selected.move)
    }

    @Test
    fun zygardeWildEncountersAlwaysUseTenPercentForm() {
        val state = GameState.createInitial(starterId = 25)
        val engine = BattleEngine(state, repository)
        listOf(718, 10119, 10120).forEach { engine.spawnEnemy(forceId = it); assertEquals(10181, state.enemy?.id) }
        val stone = repository.getAllHeldItems().first { it.ko == "지가르데나이트" }
        state.items[stone.id] = 1
        state.team.first().id = 718
        assertTrue(!engine.equipItem(state.team.first(), stone.id))
    }

    @Test
    fun megaAbilityFollowsFormAndRestoresOriginalAbility() {
        listOf(Triple(6, "charizardite-x", "단단한발톱"), Triple(6, "charizardite-y", "가뭄"), Triple(257, "blazikenite", "가속")).forEach { (id, stone, expected) ->
            val state = GameState.createInitial(starterId = id)
            val ally = state.team.first().apply { item = stone; mg = 100.0 }
            val originalAbility = ally.ab
            val engine = BattleEngine(state, repository)
            engine.megaEvolve(ally)
            assertTrue(ally.isMega)
            assertEquals(expected, com.pokeidle.app.domain.system.AbilitySystem.getEffectiveAbilityName(ally, state.team, repository))
            assertEquals(expected, repository.getAbility(repository.getBattleAbilityId(ally.copy()))?.ko)
            assertEquals(originalAbility, ally.ab)
            engine.megaRevert(ally)
            assertEquals(originalAbility, repository.getBattleAbilityId(ally))
        }
    }

    private lateinit var repository: DefaultPokemonRepository

    @Before
    fun setUp() {
        repository = DefaultPokemonRepository()
        val assetsFile = File("src/main/assets/data.json")
        FileInputStream(assetsFile).use { stream ->
            repository.loadData(stream)
        }
    }

    @Test
    fun testEnemySpawningAndInitialHit() {
        val state = GameState.createInitial(starterId = 25) // 피카츄
        val engine = BattleEngine(state, repository)

        // 1. 적 스폰
        engine.spawnEnemy(forceId = 10) // 캐터피 (벌레)
        val enemy = state.enemy
        assertNotNull(enemy)
        assertEquals(10, enemy!!.id)
        assertEquals(1, enemy.lvl)
        assertTrue(enemy.hp > 0.0)
        assertEquals(enemy.maxHp, enemy.hp, 0.001)

        // 2. 단일 타격 실행
        val initialHp = enemy.hp
        val events = mutableListOf<BattleEvent>()
        engine.addEventListener { events.add(it) }

        engine.hit(state.team.first(), 1.0)

        // 데미지가 적에게 들어가 체력이 감소했는지 확인
        assertTrue("Enemy HP should decrease after hit", enemy.hp < initialHp)
        assertTrue("Hit event should be emitted", events.any { it is BattleEvent.Hit })
    }

    @Test
    fun battleBondTransformsWithoutStoneAndReverts() {
        val state = GameState.createInitial(starterId = 658)
        val ally = state.team.first()
        ally.ab = 210
        ally.mg = 100.0
        ally.item = null
        val engine = BattleEngine(state, repository)
        assertTrue(engine.canMegaEvolve(ally))
        engine.megaEvolve(ally)
        assertEquals(10117, ally.megaFormId)
        assertEquals(11, engine.getEffectiveMoveType(ally))
        engine.megaRevert(ally)
        assertEquals(false, ally.isMega)
        assertEquals(658, ally.id)
    }

    @Test
    fun lethalFirstAttackDoesNotSkipOtherReadySlots() {
        val state = GameState.createInitial(starterId = 25)
        state.team.clear()
        repeat(3) { state.team.add(AllyMon(id = 25, slot = it, joined = it + 1L, cd = 0.0, move = 33)) }
        state.rt = 100.0
        val engine = BattleEngine(state, repository)
        engine.spawnEnemy(forceId = 10)
        state.enemy!!.hp = 1e-200
        val slots = mutableSetOf<Int>()
        engine.addEventListener {
            if (it is BattleEvent.Hit) slots.add(it.slot)
            if (it is BattleEvent.Miss) slots.add(it.slot)
        }
        engine.tick()
        assertEquals(setOf(0, 1, 2), slots)
    }

    @Test
    fun ultraBurstReturnsToBothPermanentFusionForms() {
        for (form in listOf(10155, 10156)) {
            val state = GameState.createInitial(starterId = 800)
            val ally = state.team.first()
            ally.isMega = true
            ally.megaFormId = form
            ally.item = "ultranecrozium-z"
            val engine = BattleEngine(state, repository)
            engine.megaEvolve(ally)
            assertEquals(10157, ally.megaFormId)
            engine.megaRevert(ally)
            assertTrue(ally.isMega)
            assertEquals(form, ally.megaFormId)
            assertEquals(null, ally.ultraRevertFormId)
        }
    }

    @Test
    fun ultraBurstBoxSwapPreservesFusion() {
        for (form in listOf(10155, 10156)) {
            val state = GameState.createInitial(starterId = 800)
            val ally = state.team.first()
            ally.isMega = true
            ally.megaFormId = form
            ally.item = "ultranecrozium-z"
            val replacement = AllyMon(id = 25, slot = -1, joined = 42L)
            state.box.add(replacement)
            val engine = BattleEngine(state, repository)
            engine.megaEvolve(ally)
            engine.swapTeamAndBox(ally.slot, replacement)
            assertTrue(ally.isMega)
            assertEquals(form, ally.megaFormId)
            assertEquals(null, ally.ultraRevertFormId)
        }
    }
    @Test
    fun sameHeldItemCanBeEquippedByMultipleAlliesUpToOwnedCopies() {
        val state = GameState.createInitial(starterId = 25)
        val first = state.team.first()
        val second = AllyMon(id = 4, lvl = 10, slot = 1, joined = 2)
        state.team.add(second)
        state.items["charcoal"] = 2
        val engine = BattleEngine(state, repository)

        assertTrue(engine.equipItem(first, "charcoal"))
        assertTrue(engine.equipItem(second, "charcoal"))
        assertEquals("charcoal", first.item)
        assertEquals("charcoal", second.item)
    }

    @Test
    fun greninjiteEnablesAshGreninjaEvolution() {
        val state = GameState.createInitial(starterId = 25)
        val greninja = AllyMon(id = 658, lvl = 100, slot = 0, joined = 1)
        state.team.clear()
        state.team.add(greninja)
        state.items["ash-greninjite"] = 1
        val engine = BattleEngine(state, repository)

        assertTrue(engine.equipItem(greninja, "ash-greninjite"))
        assertTrue(engine.getEvoOptions(greninja).any { it.firstOrNull() == 10117 })
        assertTrue(engine.evolve(greninja, 10117))
        assertEquals(10117, greninja.id)
        assertEquals("지우개굴닌자", repository.getPokemon(greninja.id)?.ko)
    }

    @Test
    fun matchingZCrystalActivatesForTenSecondsAfterGaugeFills() {
        val state = GameState.createInitial(starterId = 25)
        val pikachu = state.team.first().apply { move = 85 }
        val crystal = repository.getAllHeldItems().first { it.category == "z-crystals" && it.type == 13 }
        state.items[crystal.id] = 1
        val engine = BattleEngine(state, repository)
        assertTrue(engine.equipItem(pikachu, crystal.id))
        engine.spawnEnemy(forceId = 7)

        repeat(25) { engine.hit(pikachu) }

        assertEquals(10.0, pikachu.status.zMoveDuration, 0.001)
        val move = repository.getMove(pikachu.move)!!
        assertEquals(1.0, engine.getItemDamageMultiplier(pikachu, 13, move, false), 0.001)
        assertEquals(175.0, ZMoveData.resolve(crystal.id, pikachu.id, pikachu.move, move.t, move.p)?.power ?: 0.0, 0.001)
    }

    @Test
    fun ashCapPikachuUsesTenMillionVoltZMove() {
        val zMove = ZMoveData.resolve("pikashunium-z--held", 10094, 85, 13, 90.0)
        assertNotNull(zMove)
        assertEquals("1000만볼트", zMove!!.name)
        assertEquals(195.0, zMove.power, 0.001)
        assertTrue(ZMoveData.canEquip("pikashunium-z--held", 10094))
        assertTrue(!ZMoveData.canEquip("pikashunium-z--held", 25))
    }

    @Test
    fun ultraNecroziumZRequiresPhotonGeyserDuringUltraBurst() {
        val photonGeyser = ZMoveData.resolve("ultranecrozium-z", 800, 722, 14, 100.0, 10157)
        assertNotNull(photonGeyser)
        assertEquals("하늘을 태우는 멸망의 빛", photonGeyser!!.name)
        assertEquals(200.0, photonGeyser.power, 0.001)
        assertNull(ZMoveData.resolve("ultranecrozium-z", 800, 722, 14, 100.0, 10156))
        assertNull(ZMoveData.resolve("ultranecrozium-z", 800, 100, 14, 100.0, 10157))
    }

    @Test
    fun dynamaxMovePowerUsesTypeSpecificTableAndKeepsOriginalCategory() {
        assertEquals(90.0, com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(10, 40.0), 0.001)
        assertEquals(130.0, com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(10, 75.0), 0.001)
        assertEquals(70.0, com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(2, 40.0), 0.001)
        assertEquals(100.0, com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(17, 150.0), 0.001)
        val original = com.pokeidle.app.data.model.MoveDto(t = 10, p = 75.0, c = 2, ko = "불꽃펀치")
        val transformed = original.copy(p = com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(original.t, original.p))
        assertEquals(original.c, transformed.c)
    }

    @Test
    fun offlineProgressRequiresOneMinuteAndAwardsCappedIdleExp() {
        val shortState = GameState.createInitial(starterId = 25)
        val shortEngine = BattleEngine(shortState, repository)
        shortEngine.spawnEnemy(forceId = 16)
        assertNull(shortEngine.applyOfflineProgress(59.0))

        val oneHourState = GameState.createInitial(starterId = 25)
        val oneHourEngine = BattleEngine(oneHourState, repository)
        oneHourEngine.spawnEnemy(forceId = 16)
        val oneHour = oneHourEngine.applyOfflineProgress(3600.0)
        assertNotNull(oneHour)
        assertTrue(oneHour!!.first.isFinite())
        assertTrue(oneHourState.totalL.isFinite())

        val fullDayState = GameState.createInitial(starterId = 25)
        val fullDayEngine = BattleEngine(fullDayState, repository)
        fullDayEngine.spawnEnemy(forceId = 16)
        val fullDay = fullDayEngine.applyOfflineProgress(24.0 * 3600.0)
        assertEquals(oneHour!!.first + kotlin.math.log10(6.0), fullDay!!.first, 0.01)
    }

    @Test
    fun achievementsReflectRebirthLevelAndPokedexProgress() {
        val state = GameState.createInitial(starterId = 25)
        state.rebirths = 1
        state.kills = 4_000L
        val achievements = AchievementData.getAll(state, repository.getAllPokemon().size)
        assertTrue(achievements.first { it.id == "rb1" }.completed)
        assertTrue(achievements.first { it.id == "lv1k" }.completed)
        assertTrue(!achievements.first { it.id == "dex" }.completed)
    }

    @Test
    fun megaStoneSuffixSelectsMatchingMegaForm() {
        val cases = listOf(Triple(6, "charizardite-x", 10034), Triple(6, "charizardite-y", 10035), Triple(257, "blazikenite", 10050))
        cases.forEach { (pokemonId, stoneId, expectedFormId) ->
            val state = GameState.createInitial(starterId = pokemonId)
            val ally = state.team.first().apply { item = stoneId; mg = 100.0 }
            val engine = BattleEngine(state, repository)

            assertTrue("$stoneId should allow its matching Mega form", engine.canMegaEvolve(ally))
            engine.megaEvolve(ally)
            assertEquals(expectedFormId, ally.megaFormId)
        }
    }

    @Test
    fun testDamageCalculationSTABAndEffectiveness() {
        val state = GameState.createInitial(starterId = 25) // 피카츄 (전기 13)
        val pikachu = state.team.first()
        pikachu.move = 85 // 10만볼트 (전기 13, 위력 90)

        val engine = BattleEngine(state, repository)

        // 물 타입 적 스폰 (꼬부기 7) -> 2배 상성
        engine.spawnEnemy(forceId = 7)
        val waterEnemy = state.enemy!!

        val (dmgWater, effWater) = engine.calculateDamage(pikachu, waterEnemy)
        assertEquals("Electric vs Water should be 2.0x effective", 2.0, effWater, 0.001)
        assertTrue("Damage should be positive", dmgWater > 0.0)

        // 땅 타입 적 스폰 (디그다 50) -> 전기 무효 상성 (게임 공식상 0.1x)
        engine.spawnEnemy(forceId = 50)
        val groundEnemy = state.enemy!!

        val (dmgGround, effGround) = engine.calculateDamage(pikachu, groundEnemy)
        assertEquals("Electric vs Ground immunity should convert to 0.1x", 0.1, effGround, 0.001)
        assertTrue(dmgWater > dmgGround)
    }

    @Test
    fun testEnemyDefeatAndExpGain() {
        val state = GameState.createInitial(starterId = 4) // 파이리
        val engine = BattleEngine(state, repository)

        engine.spawnEnemy(forceId = 1) // 이상해씨
        val enemy = state.enemy!!
        enemy.hp = 0.0

        val initialExp = state.exp
        val initialKills = state.kills

        engine.defeat()

        assertEquals(initialKills + 1, state.kills)
        assertTrue("Exp should increase", state.exp > initialExp)
        assertNotNull("New enemy should be spawned", state.enemy)
    }

    @Test
    fun testOverkillChainDefeat() {
        val state = GameState.createInitial(starterId = 6) // 리자몽
        val charizard = state.team.first()
        charizard.lvl = 100 // 높은 레벨

        val engine = BattleEngine(state, repository)
        engine.spawnEnemy(forceId = 10) // 1레벨 캐터피
        val enemy = state.enemy!!

        val initialKills = state.kills
        val events = mutableListOf<BattleEvent>()
        engine.addEventListener { events.add(it) }

        // 압도적인 공격력으로 만피 적 타격
        engine.hit(charizard, 1.0)

        if (enemy.hp <= 0.0) {
            engine.defeat()
        }

        // 오버킬 연쇄로 인해 1킬 이상 누적되었는지 확인
        assertTrue("Kills should be greater than initial + 1 due to overkill", state.kills > initialKills + 1)
        assertTrue("Overkill event should be emitted", events.any { it is BattleEvent.Overkill })
    }

    @Test
    fun testScaleNormalization() {
        val state = GameState.createInitial(starterId = 25)
        state.exp = 1e250 // 극단적인 경험치 축적

        val engine = BattleEngine(state, repository)
        engine.spawnEnemy(forceId = 1)

        val oldK = state.K
        engine.normalizeScale()

        assertTrue("K should be shifted to prevent overflow", state.K > oldK)
        assertTrue("Scaled exp should fit in safe range", state.exp < 1e200)
    }

    @Test
    fun testEvolutionAndLevelUp() {
        // 이상해씨 (ID: 1, 16레벨 이상에서 이상해풀 ID: 2로 진화 가능)
        val state = GameState.createInitial(starterId = 1)
        val engine = BattleEngine(state, repository)
        val bulbasaur = state.team.first()

        // 충분한 경험치 부여
        state.exp = 1e20

        // 1. 레벨업 15회 진행 -> Lv.16 도달
        engine.levelUp(bulbasaur, 15)
        assertEquals("15회 레벨업하여 Lv.16이어야 함", 16, bulbasaur.lvl)
        assertEquals("gameState 원본 레벨도 16이어야 함", 16, state.team.first().lvl)

        // 2. 16레벨에서 이상해풀(2) 진화 가능 옵션 확인
        val evoOpts = engine.getEvoOptions(bulbasaur)
        assertTrue("이상해풀(2)로의 진화 옵션이 있어야 함", evoOpts.any { it[0] == 2 })

        // 3. 진화 실행 -> 이상해풀 (ID: 2)
        val didEvolve = engine.evolve(bulbasaur, 2)
        assertTrue("진화 성공해야 함", didEvolve)
        assertEquals("ID가 이상해풀(2)로 변경되어야 함", 2, bulbasaur.id)
        assertEquals("gameState 원본 ID도 2여야 함", 2, state.team.first().id)
        assertTrue("도감에 잡은 수 등록되어야 함", (state.caught[2] ?: 0) >= 1)

        // 4. 레벨업이 자유롭게 계속 진행되는지 확인
        engine.levelUp(bulbasaur, 16)
        assertEquals("32레벨 도달", 32, bulbasaur.lvl)

        // 5. 이상해꽃(3)으로 최종 진화
        val didEvolveFinal = engine.evolve(bulbasaur, 3)
        assertTrue("이상해꽃으로 진화 성공해야 함", didEvolveFinal)
        assertEquals("이상해꽃 ID 3", 3, bulbasaur.id)

        // 6. 최종 진화체도 자유롭게 레벨업 가능
        engine.levelUp(bulbasaur, 20)
        assertEquals(52, bulbasaur.lvl)
    }

    @Test
    fun testRerollMoveWithCopyInstance() {
        val state = GameState.createInitial(starterId = 1)
        val bulbasaur = state.team.first()
        val originalMove = bulbasaur.move

        // 증표 부여
        state.tokens[1] = 5

        val engine = BattleEngine(state, repository)

        // UI에서처럼 copy()된 인스턴스를 전달
        val copyMon = bulbasaur.copy(status = bulbasaur.status.copy())
        val didReroll = engine.rerollMove(copyMon)

        assertTrue("기술 변경 성공해야 함", didReroll)
        assertEquals("증표 1개 차감되어 4개여야 함", 4, state.tokens[1])
        assertTrue("복사본 인스턴스의 기술이 바뀌어야 함", copyMon.move != originalMove)
        assertTrue("원본 gameState의 기술도 바뀌어야 함", state.team.first().move != originalMove)
        assertEquals("복사본과 원본의 새 기술이 일치해야 함", copyMon.move, state.team.first().move)
    }
}
