package com.pokeidle.app.data.repository

import com.pokeidle.app.domain.model.GameState
import java.io.InputStream
import java.io.OutputStream

/**
 * 게임 진행 상태의 영속화(저장/불러오기) 및 .psv 파일 내보내기/가져오기를 담당하는 리포지토리 규격
 */
interface SaveRepository {
    /**
     * 현재 게임 상태를 비동기로 SQLite 저장소에 원자적 저장
     */
    suspend fun saveGame(state: GameState): Result<Unit>

    /**
     * 저장된 게임 상태를 비동기로 불러옵니다 (세이브가 없으면 null 반환)
     */
    suspend fun loadGame(): Result<GameState?>

    /**
     * 저장된 세이브가 존재하는지 확인
     */
    suspend fun hasSave(): Boolean

    /**
     * 저장된 세이브 데이터를 전체 삭제/초기화
     */
    suspend fun clearSave(): Result<Unit>

    /**
     * 현재 SQLite 세이브를 .psv 파일 스트림으로 내보내기 (Export)
     */
    suspend fun exportSaveToPsv(destinationStream: OutputStream): Result<Unit>

    /**
     * 외부 .psv 파일 스트림으로부터 세이브를 가져와 검증 및 복원 (Import)
     */
    suspend fun importSaveFromPsv(sourceStream: InputStream): Result<GameState>
}
