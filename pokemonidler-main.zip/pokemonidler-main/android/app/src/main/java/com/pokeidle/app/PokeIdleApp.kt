package com.pokeidle.app

import android.app.Application

/**
 * 커스텀 Application 클래스.
 * 앱 전역 초기화(assets 로드, DataStore 설정 등)를 여기서 수행한다.
 */
class PokeIdleApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
