package com.pokeidle.app.data.model

/**
 * PokéAPI v2 SQLite 공식 데이터베이스에서 추출된 정식 종족치(HP, ATK, DEF, SPA, SDF, SPD, PW)
 * - 메가진화(100종), 울트라 네크로즈마(10157), 원시회귀, 무한다이맥스
 * - 배틀 대체 폼체인지(달마모드, 군집의 모습, 히어로폼 등)
 * 공식 종족값(방어 DEF, 특방 SDF, 체력 HP)을 완벽 보정합니다.
 */
object CanonicalStatsData {

    data class CanonicalStat(
        val hp: Int,
        val atk: Int,
        val def: Int,
        val spa: Int,
        val sdf: Int,
        val spd: Int,
        val pw: Double
    )

    // PokéAPI pokemon_stats.csv 기준 메가진화 / 변신 폼체인지 100종
    val MEGA_STATS: Map<Int, CanonicalStat> = mapOf(
        10033 to CanonicalStat(hp = 80, atk = 100, def = 123, spa = 122, sdf = 120, spd = 80, pw = 104.2), // venusaur-mega
        10034 to CanonicalStat(hp = 78, atk = 130, def = 111, spa = 130, sdf = 85, spd = 100, pw = 105.7), // charizard-mega-x
        10035 to CanonicalStat(hp = 78, atk = 104, def = 78, spa = 159, sdf = 115, spd = 100, pw = 105.7), // charizard-mega-y
        10036 to CanonicalStat(hp = 79, atk = 103, def = 120, spa = 135, sdf = 115, spd = 78, pw = 105.0), // blastoise-mega
        10037 to CanonicalStat(hp = 55, atk = 50, def = 65, spa = 175, sdf = 105, spd = 150, pw = 100.0), // alakazam-mega
        10038 to CanonicalStat(hp = 60, atk = 65, def = 80, spa = 170, sdf = 95, spd = 130, pw = 100.0), // gengar-mega
        10039 to CanonicalStat(hp = 105, atk = 125, def = 100, spa = 60, sdf = 100, spd = 100, pw = 98.3), // kangaskhan-mega
        10040 to CanonicalStat(hp = 65, atk = 155, def = 120, spa = 65, sdf = 90, spd = 105, pw = 100.0), // pinsir-mega
        10041 to CanonicalStat(hp = 95, atk = 155, def = 109, spa = 70, sdf = 130, spd = 81, pw = 106.7), // gyarados-mega
        10042 to CanonicalStat(hp = 80, atk = 135, def = 85, spa = 70, sdf = 95, spd = 150, pw = 102.5), // aerodactyl-mega
        10043 to CanonicalStat(hp = 106, atk = 190, def = 100, spa = 154, sdf = 100, spd = 130, pw = 130.0), // mewtwo-mega-x
        10044 to CanonicalStat(hp = 106, atk = 150, def = 70, spa = 194, sdf = 120, spd = 140, pw = 130.0), // mewtwo-mega-y
        10045 to CanonicalStat(hp = 90, atk = 95, def = 105, spa = 165, sdf = 110, spd = 45, pw = 101.7), // ampharos-mega
        10046 to CanonicalStat(hp = 70, atk = 150, def = 140, spa = 65, sdf = 100, spd = 75, pw = 100.0), // scizor-mega
        10047 to CanonicalStat(hp = 80, atk = 185, def = 115, spa = 40, sdf = 105, spd = 75, pw = 100.0), // heracross-mega
        10048 to CanonicalStat(hp = 75, atk = 90, def = 90, spa = 140, sdf = 90, spd = 115, pw = 100.0), // houndoom-mega
        10049 to CanonicalStat(hp = 100, atk = 164, def = 150, spa = 95, sdf = 120, spd = 71, pw = 116.7), // tyranitar-mega
        10050 to CanonicalStat(hp = 80, atk = 160, def = 80, spa = 130, sdf = 80, spd = 100, pw = 105.0), // blaziken-mega
        10051 to CanonicalStat(hp = 68, atk = 85, def = 65, spa = 165, sdf = 135, spd = 100, pw = 103.0), // gardevoir-mega
        10052 to CanonicalStat(hp = 50, atk = 105, def = 125, spa = 55, sdf = 95, spd = 50, pw = 80.0), // mawile-mega
        10053 to CanonicalStat(hp = 70, atk = 140, def = 230, spa = 60, sdf = 80, spd = 50, pw = 105.0), // aggron-mega
        10054 to CanonicalStat(hp = 60, atk = 100, def = 85, spa = 80, sdf = 85, spd = 100, pw = 85.0), // medicham-mega
        10055 to CanonicalStat(hp = 70, atk = 75, def = 80, spa = 135, sdf = 80, spd = 135, pw = 95.8), // manectric-mega
        10056 to CanonicalStat(hp = 64, atk = 165, def = 75, spa = 93, sdf = 83, spd = 75, pw = 92.5), // banette-mega
        10057 to CanonicalStat(hp = 65, atk = 150, def = 60, spa = 115, sdf = 60, spd = 115, pw = 94.2), // absol-mega
        10058 to CanonicalStat(hp = 108, atk = 170, def = 115, spa = 120, sdf = 95, spd = 92, pw = 116.7), // garchomp-mega
        10059 to CanonicalStat(hp = 70, atk = 145, def = 88, spa = 140, sdf = 70, spd = 112, pw = 104.2), // lucario-mega
        10060 to CanonicalStat(hp = 90, atk = 132, def = 105, spa = 132, sdf = 105, spd = 30, pw = 99.0), // abomasnow-mega
        10062 to CanonicalStat(hp = 80, atk = 100, def = 120, spa = 140, sdf = 150, spd = 110, pw = 116.7), // latias-mega
        10063 to CanonicalStat(hp = 80, atk = 130, def = 100, spa = 160, sdf = 120, spd = 110, pw = 116.7), // latios-mega
        10064 to CanonicalStat(hp = 100, atk = 150, def = 110, spa = 95, sdf = 110, spd = 70, pw = 105.8), // swampert-mega
        10065 to CanonicalStat(hp = 70, atk = 110, def = 75, spa = 145, sdf = 85, spd = 145, pw = 105.0), // sceptile-mega
        10066 to CanonicalStat(hp = 50, atk = 85, def = 125, spa = 85, sdf = 115, spd = 20, pw = 80.0), // sableye-mega
        10067 to CanonicalStat(hp = 75, atk = 110, def = 110, spa = 110, sdf = 105, spd = 80, pw = 98.3), // altaria-mega
        10068 to CanonicalStat(hp = 68, atk = 165, def = 95, spa = 65, sdf = 115, spd = 110, pw = 103.0), // gallade-mega
        10069 to CanonicalStat(hp = 103, atk = 60, def = 126, spa = 80, sdf = 126, spd = 50, pw = 90.8), // audino-mega
        10070 to CanonicalStat(hp = 70, atk = 140, def = 70, spa = 110, sdf = 65, spd = 105, pw = 93.3), // sharpedo-mega
        10071 to CanonicalStat(hp = 95, atk = 75, def = 180, spa = 130, sdf = 80, spd = 30, pw = 98.3), // slowbro-mega
        10072 to CanonicalStat(hp = 75, atk = 125, def = 230, spa = 55, sdf = 95, spd = 30, pw = 101.7), // steelix-mega
        10073 to CanonicalStat(hp = 83, atk = 80, def = 80, spa = 135, sdf = 80, spd = 121, pw = 96.5), // pidgeot-mega
        10074 to CanonicalStat(hp = 80, atk = 120, def = 80, spa = 120, sdf = 80, spd = 100, pw = 96.7), // glalie-mega
        10075 to CanonicalStat(hp = 50, atk = 160, def = 110, spa = 160, sdf = 110, spd = 110, pw = 116.7), // diancie-mega
        10076 to CanonicalStat(hp = 80, atk = 145, def = 150, spa = 105, sdf = 110, spd = 110, pw = 116.7), // metagross-mega
        10077 to CanonicalStat(hp = 100, atk = 150, def = 90, spa = 180, sdf = 160, spd = 90, pw = 128.3), // kyogre-primal
        10078 to CanonicalStat(hp = 100, atk = 180, def = 160, spa = 150, sdf = 90, spd = 90, pw = 128.3), // groudon-primal
        10079 to CanonicalStat(hp = 105, atk = 180, def = 100, spa = 180, sdf = 100, spd = 115, pw = 130.0), // rayquaza-mega
        10087 to CanonicalStat(hp = 70, atk = 120, def = 100, spa = 145, sdf = 105, spd = 20, pw = 93.3), // camerupt-mega
        10088 to CanonicalStat(hp = 65, atk = 136, def = 94, spa = 54, sdf = 96, spd = 135, pw = 96.7), // lopunny-mega
        10089 to CanonicalStat(hp = 95, atk = 145, def = 130, spa = 120, sdf = 90, spd = 120, pw = 116.7), // salamence-mega
        10090 to CanonicalStat(hp = 65, atk = 150, def = 40, spa = 15, sdf = 80, spd = 145, pw = 82.5), // beedrill-mega
        10157 to CanonicalStat(hp = 97, atk = 167, def = 97, spa = 167, sdf = 97, spd = 129, pw = 125.7), // necrozma-ultra
        10190 to CanonicalStat(hp = 255, atk = 115, def = 250, spa = 125, sdf = 250, spd = 130, pw = 187.5), // eternatus-eternamax
        10193 to CanonicalStat(hp = 100, atk = 165, def = 150, spa = 85, sdf = 130, spd = 50, pw = 113.3), // calyrex-ice
        10194 to CanonicalStat(hp = 100, atk = 85, def = 80, spa = 165, sdf = 100, spd = 150, pw = 113.3), // calyrex-shadow
        10277 to CanonicalStat(hp = 160, atk = 105, def = 110, spa = 130, sdf = 110, spd = 85, pw = 116.7), // terapagos-stellar
        10278 to CanonicalStat(hp = 95, atk = 80, def = 93, spa = 135, sdf = 110, spd = 70, pw = 97.2), // clefable-mega
        10279 to CanonicalStat(hp = 80, atk = 125, def = 85, spa = 135, sdf = 95, spd = 70, pw = 98.3), // victreebel-mega
        10280 to CanonicalStat(hp = 60, atk = 100, def = 105, spa = 130, sdf = 105, spd = 120, pw = 103.3), // starmie-mega
        10281 to CanonicalStat(hp = 91, atk = 124, def = 115, spa = 145, sdf = 125, spd = 100, pw = 116.7), // dragonite-mega
        10282 to CanonicalStat(hp = 80, atk = 92, def = 115, spa = 143, sdf = 115, spd = 80, pw = 104.2), // meganium-mega
        10283 to CanonicalStat(hp = 85, atk = 160, def = 125, spa = 89, sdf = 93, spd = 78, pw = 105.0), // feraligatr-mega
        10284 to CanonicalStat(hp = 65, atk = 140, def = 110, spa = 40, sdf = 100, spd = 110, pw = 94.2), // skarmory-mega
        10285 to CanonicalStat(hp = 70, atk = 80, def = 70, spa = 140, sdf = 100, spd = 120, pw = 96.7), // froslass-mega
        10286 to CanonicalStat(hp = 110, atk = 148, def = 75, spa = 110, sdf = 110, spd = 75, pw = 104.7), // emboar-mega
        10287 to CanonicalStat(hp = 110, atk = 165, def = 100, spa = 65, sdf = 65, spd = 103, pw = 101.3), // excadrill-mega
        10288 to CanonicalStat(hp = 60, atk = 140, def = 149, spa = 75, sdf = 99, spd = 62, pw = 97.5), // scolipede-mega
        10289 to CanonicalStat(hp = 65, atk = 130, def = 135, spa = 55, sdf = 135, spd = 68, pw = 98.0), // scrafty-mega
        10290 to CanonicalStat(hp = 85, atk = 145, def = 80, spa = 135, sdf = 90, spd = 80, pw = 102.5), // eelektross-mega
        10291 to CanonicalStat(hp = 60, atk = 75, def = 110, spa = 175, sdf = 110, spd = 90, pw = 103.3), // chandelure-mega
        10292 to CanonicalStat(hp = 88, atk = 137, def = 172, spa = 74, sdf = 115, spd = 44, pw = 105.0), // chesnaught-mega
        10293 to CanonicalStat(hp = 75, atk = 69, def = 72, spa = 159, sdf = 125, spd = 134, pw = 105.7), // delphox-mega
        10294 to CanonicalStat(hp = 72, atk = 125, def = 77, spa = 133, sdf = 81, spd = 142, pw = 105.0), // greninja-mega
        10295 to CanonicalStat(hp = 86, atk = 88, def = 92, spa = 129, sdf = 86, spd = 126, pw = 101.2), // pyroar-mega
        10296 to CanonicalStat(hp = 74, atk = 85, def = 87, spa = 155, sdf = 148, spd = 102, pw = 108.5), // floette-mega
        10297 to CanonicalStat(hp = 86, atk = 102, def = 88, spa = 98, sdf = 120, spd = 88, pw = 97.0), // malamar-mega
        10298 to CanonicalStat(hp = 72, atk = 140, def = 130, spa = 64, sdf = 106, spd = 88, pw = 100.0), // barbaracle-mega
        10299 to CanonicalStat(hp = 65, atk = 85, def = 105, spa = 132, sdf = 163, spd = 44, pw = 99.0), // dragalge-mega
        10300 to CanonicalStat(hp = 78, atk = 137, def = 100, spa = 74, sdf = 93, spd = 118, pw = 100.0), // hawlucha-mega
        10302 to CanonicalStat(hp = 78, atk = 85, def = 110, spa = 160, sdf = 116, spd = 36, pw = 97.5), // drampa-mega
        10303 to CanonicalStat(hp = 65, atk = 135, def = 135, spa = 70, sdf = 65, spd = 100, pw = 95.0), // falinks-mega
        10304 to CanonicalStat(hp = 60, atk = 135, def = 95, spa = 90, sdf = 95, spd = 110, pw = 97.5), // raichu-mega-x
        10305 to CanonicalStat(hp = 60, atk = 100, def = 55, spa = 160, sdf = 80, spd = 130, pw = 97.5), // raichu-mega-y
        10306 to CanonicalStat(hp = 75, atk = 50, def = 110, spa = 135, sdf = 120, spd = 65, pw = 92.5), // chimecho-mega
        10308 to CanonicalStat(hp = 85, atk = 140, def = 100, spa = 60, sdf = 90, spd = 110, pw = 97.5), // staraptor-mega
        10311 to CanonicalStat(hp = 91, atk = 120, def = 106, spa = 175, sdf = 141, spd = 67, pw = 116.7), // heatran-mega
        10312 to CanonicalStat(hp = 70, atk = 120, def = 130, spa = 165, sdf = 130, spd = 85, pw = 116.7), // darkrai-mega
        10313 to CanonicalStat(hp = 89, atk = 159, def = 105, spa = 70, sdf = 105, spd = 55, pw = 97.2), // golurk-mega
        10314 to CanonicalStat(hp = 74, atk = 48, def = 76, spa = 143, sdf = 101, spd = 124, pw = 94.3), // meowstic-male-mega
        10315 to CanonicalStat(hp = 97, atk = 157, def = 122, spa = 62, sdf = 107, spd = 33, pw = 96.3), // crabominable-mega
        10316 to CanonicalStat(hp = 75, atk = 150, def = 175, spa = 70, sdf = 120, spd = 40, pw = 105.0), // golisopod-mega
        10317 to CanonicalStat(hp = 80, atk = 125, def = 115, spa = 170, sdf = 115, spd = 95, pw = 116.7), // magearna-mega
        10318 to CanonicalStat(hp = 80, atk = 125, def = 115, spa = 170, sdf = 115, spd = 95, pw = 116.7), // magearna-original-mega
        10319 to CanonicalStat(hp = 88, atk = 157, def = 75, spa = 147, sdf = 80, spd = 153, pw = 116.7), // zeraora-mega
        10320 to CanonicalStat(hp = 65, atk = 138, def = 85, spa = 138, sdf = 85, spd = 75, pw = 97.7), // scovillain-mega
        10321 to CanonicalStat(hp = 83, atk = 90, def = 105, spa = 150, sdf = 96, spd = 101, pw = 104.2), // glimmora-mega
        10322 to CanonicalStat(hp = 68, atk = 65, def = 90, spa = 135, sdf = 125, spd = 92, pw = 95.8), // tatsugiri-curly-mega
        10323 to CanonicalStat(hp = 68, atk = 65, def = 90, spa = 135, sdf = 125, spd = 92, pw = 95.8), // tatsugiri-droopy-mega
        10324 to CanonicalStat(hp = 68, atk = 65, def = 90, spa = 135, sdf = 125, spd = 92, pw = 95.8), // tatsugiri-stretchy-mega
        10325 to CanonicalStat(hp = 115, atk = 175, def = 117, spa = 105, sdf = 101, spd = 87, pw = 116.7), // baxcalibur-mega
        10326 to CanonicalStat(hp = 74, atk = 48, def = 76, spa = 143, sdf = 101, spd = 124, pw = 94.3), // meowstic-female-mega
    )

    // PokéAPI pokemon_stats.csv 기준 배틀 대체 폼체인지
    val ALT_STATS: Map<String, CanonicalStat> = mapOf(
        "10177_zen" to CanonicalStat(hp = 105, atk = 160, def = 55, spa = 30, sdf = 55, spd = 135, pw = 90.0), // darmanitan-galar-zen
        "1024_stellar" to CanonicalStat(hp = 160, atk = 105, def = 110, spa = 130, sdf = 110, spd = 85, pw = 116.7), // terapagos-stellar
        "1024_tera" to CanonicalStat(hp = 95, atk = 95, def = 110, spa = 105, sdf = 110, spd = 85, pw = 100.0), // terapagos-terastal
        "351_rain" to CanonicalStat(hp = 70, atk = 70, def = 70, spa = 70, sdf = 70, spd = 70, pw = 70.0), // castform-rainy
        "351_snow" to CanonicalStat(hp = 70, atk = 70, def = 70, spa = 70, sdf = 70, spd = 70, pw = 70.0), // castform-snowy
        "351_sun" to CanonicalStat(hp = 70, atk = 70, def = 70, spa = 70, sdf = 70, spd = 70, pw = 70.0), // castform-sunny
        "555_zen" to CanonicalStat(hp = 105, atk = 30, def = 105, spa = 140, sdf = 105, spd = 55, pw = 90.0), // darmanitan-zen
        "718_complete" to CanonicalStat(hp = 216, atk = 100, def = 121, spa = 91, sdf = 95, spd = 85, pw = 118.0), // zygarde-complete
        "746_school" to CanonicalStat(hp = 45, atk = 140, def = 130, spa = 140, sdf = 135, spd = 30, pw = 103.3), // wishiwashi-school
        "877_hangry" to CanonicalStat(hp = 58, atk = 95, def = 58, spa = 70, sdf = 58, spd = 97, pw = 72.7), // morpeko-hangry
        "964_hero" to CanonicalStat(hp = 100, atk = 160, def = 97, spa = 106, sdf = 87, spd = 100, pw = 108.3), // palafin-hero
    )

    // PokéAPI /pokemon/718 및 /pokemon/10181 종족치. 합체폼은 50%/퍼펙트 별도 레코드.
    val ZYGARDE_10 = CanonicalStat(hp = 54, atk = 100, def = 71, spa = 61, sdf = 85, spd = 115, pw = 81.0)
    val ZYGARDE_50 = CanonicalStat(hp = 108, atk = 100, def = 121, spa = 81, sdf = 95, spd = 95, pw = 100.0)
    val ZYGARDE_COMPLETE = CanonicalStat(hp = 216, atk = 100, def = 121, spa = 91, sdf = 95, spd = 85, pw = 118.0)
    val ZYGARDE_MEGA = CanonicalStat(hp = 216, atk = 70, def = 91, spa = 216, sdf = 85, spd = 100, pw = 129.7)

    fun getActiveFormStat(ally: com.pokeidle.app.domain.model.AllyMon): CanonicalStat? {
        if (ally.id == 1027) return CanonicalStat(999, 999, 999, 999, 999, 999, 999.0)
        if (!ally.isMega || ally.megaFormId == null) return when (ally.id) {
            in ZygardeFusionData.tenIds -> ZYGARDE_10
            in ZygardeFusionData.fiftyIds -> ZYGARDE_50
            ZygardeFusionData.COMPLETE -> ZYGARDE_COMPLETE
            else -> OfficialFormStats.all[ally.id]
        }
        return when {
            ally.id == 800 && ally.megaFormId in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID) -> null
            ally.id in ZygardeFusionData.allIds && ally.megaFormId == 10301 -> ZYGARDE_MEGA
            GigantamaxFormsData.isForm(ally.megaFormId) -> getMegaStat(ally.megaFormId!!)
            else -> getMegaStat(ally.megaFormId!!)
        }
    }

    fun getMegaStat(megaId: Int): CanonicalStat? = OfficialFormStats.all[megaId] ?: MEGA_STATS[megaId]

    fun getAltStat(speciesId: Int, formKey: String): CanonicalStat? = ALT_STATS["${speciesId}_${formKey}"]

    fun getPokemonFormStat(speciesId: Int, pokemonId: Int): CanonicalStat? = when {
        speciesId == 718 && pokemonId in setOf(10118, 10181) -> ZYGARDE_10
        speciesId == 718 && pokemonId in setOf(718, 10119) -> ZYGARDE_50
        speciesId == 718 && pokemonId == 10120 -> ZYGARDE_COMPLETE
        speciesId == 718 && pokemonId == 10301 -> ZYGARDE_MEGA
        else -> null
    }

}
