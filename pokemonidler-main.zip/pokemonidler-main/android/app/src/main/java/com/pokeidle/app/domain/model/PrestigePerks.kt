package com.pokeidle.app.domain.model

data class PrestigePerkDefinition(
    val key: String,
    val name: String,
    val description: String,
    val baseCost: Double,
    val maxLevel: Int? = null
)

object PrestigePerks {
    val all = listOf(
        PrestigePerkDefinition("dmg", "힘의 기억", "동료 전체 데미지 ×1.1 (복리)", 60.0),
        PrestigePerkDefinition("spd", "민첩의 기억", "동료 전체 공격 주기 ×0.95 (복리)", 60.0),
        PrestigePerkDefinition("exp", "성장의 기억", "레벨업 필요 경험치 ×0.95 (복리)", 50.0),
        PrestigePerkDefinition("join", "인연의 기억", "합류 확률 ×1.1 (최대 20회)", 50.0, 20),
        PrestigePerkDefinition("tok", "증표의 기억", "증표 획득량 ×1.1 (복리)", 40.0),
        PrestigePerkDefinition("res", "인내의 기억", "야생 포켓몬 저항 주기 ×1.1 (복리)", 50.0),
        PrestigePerkDefinition("quest", "보상의 기억", "퀘스트 보상 경험치 ×1.1 (복리)", 40.0)
    )
}
