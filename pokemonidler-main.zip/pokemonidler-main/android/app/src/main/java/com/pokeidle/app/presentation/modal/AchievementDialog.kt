package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokeidle.app.data.model.AchievementData
import com.pokeidle.app.domain.model.GameState

@Composable
fun AchievementDialog(
    gameState: GameState,
    dexSize: Int,
    onSelectTitle: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val achievements = AchievementData.getAll(gameState, dexSize)
    val tiers = listOf("동", "은", "금", "무지개")
    val selected = gameState.selectedTitle
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🏆 업적 · 칭호 ${achievements.count { it.completed }}/${achievements.size}") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("칭호 선택: ${if (selected.isBlank()) "없음" else achievements.firstOrNull { it.id == selected }?.title ?: "없음"}", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { onSelectTitle("") }) { Text("칭호 없음") }
                    if (selected.isNotBlank()) OutlinedButton(onClick = { onSelectTitle("") }) { Text("해제") }
                }
                tiers.forEach { tier ->
                    val section = achievements.filter { it.tier == tier }
                    if (section.isNotEmpty()) {
                        Text("${tierIcon(tier)} $tier 등급", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 5.dp))
                        section.forEach { achievement ->
                            val completed = achievement.completed
                            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${if (completed) "✓" else "○"} ${achievement.name}", fontWeight = if (completed) FontWeight.Bold else FontWeight.Normal)
                                    if (completed) {
                                        OutlinedButton(onClick = { onSelectTitle(achievement.id) }, enabled = selected != achievement.id) {
                                            Text(if (selected == achievement.id) "장착 중" else "칭호")
                                        }
                                    }
                                }
                                if (!completed) Text("${achievement.progress.coerceAtMost(achievement.goal)} / ${achievement.goal} · 칭호 「${achievement.title}」", style = MaterialTheme.typography.bodySmall)
                                else Text("칭호 「${achievement.title}」 획득", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("닫기") } }
    )
}

private fun tierIcon(tier: String) = when (tier) { "동" -> "🥉"; "은" -> "🥈"; "금" -> "🥇"; else -> "🌈" }
