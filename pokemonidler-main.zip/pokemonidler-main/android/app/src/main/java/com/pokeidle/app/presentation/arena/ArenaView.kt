package com.pokeidle.app.presentation.arena

import androidx.compose.ui.zIndex

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.engine.BattleEngine
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.WildEnemy
import com.pokeidle.app.presentation.AttackSlashEffect
import com.pokeidle.app.presentation.FloatingEffect
import com.pokeidle.app.presentation.components.PokemonSprite
import com.pokeidle.app.presentation.components.TYPE_COLORS
import com.pokeidle.app.presentation.components.TypeBadge
import kotlin.math.log10
import kotlin.math.roundToInt

/**
 * 원작 웹 버전(src.html)과 동일한 원형 360도 전투 아레나.
 * - 중앙(50%, 50%): 야생 적 포켓몬 원형 카드 (HP, 저항 게이지, 피격 효과, 터치 타격)
 * - 원형 둘레 6개 슬롯:
 *     SLOT_POS = [[50%, 12%], [18%, 30%], [82%, 30%], [16%, 70%], [84%, 70%], [50%, 88%]]
 *     아군 포켓몬들이 중앙의 적을 둘러싸고 공격 시 안쪽(중앙)으로 돌진(Lunge) 타격 연출.
 */
@Composable
fun ArenaView(
    currentWeather: com.pokeidle.app.domain.system.ActiveWeather? = null,
    enemy: WildEnemy?,
    enemyDto: PokemonDto?,
    team: List<AllyMon>,
    rt: Double,
    rtMax: Double,
    selectedSlot: Int,
    attackingSlots: Set<Int>,
    enemyHitTrigger: Long = 0L,
    levelingUpSlots: Set<Int> = emptySet(),
    floatingEffects: List<FloatingEffect>,
    attackEffects: List<AttackSlashEffect> = emptyList(),
    repository: PokemonRepository,
    onSelectSlot: (Int) -> Unit,
    onRelieveAlly: (AllyMon) -> Unit,
    onEnemyTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 웹 규격 슬롯 6개 좌표 (비율: x, y)
    val slotPositions = remember {
        listOf(
            Offset(0.50f, 0.12f), // Slot 0: 적과 간격 확대, 원 안쪽 여백 유지
            Offset(0.18f, 0.30f), // Slot 1: 좌측 상단
            Offset(0.82f, 0.30f), // Slot 2: 우측 상단
            Offset(0.18f, 0.70f), // Slot 3: 좌측 하단
            Offset(0.82f, 0.70f), // Slot 4: 우측 하단
            Offset(0.50f, 0.88f)  // Slot 5: 하단 중앙, 원 안쪽 여백 유지
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        val arenaSize = minOf(maxWidth, maxHeight)

        // 원형 경기장 컨테이너 (모든 노드가 이 원 내부 중심을 기준으로 정렬됨)
        Box(
            modifier = Modifier
                .size(arenaSize)
                .clip(CircleShape)
                .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant)
        ) {
            WeatherBackdrop(currentWeather?.weather)
            // 1. 원형 경기장 점선 및 외곽 링 캔버스
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 2.dp.toPx()
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                drawCircle(
                    color = Color(0xFFB9C4B6),
                    radius = (size.minDimension - strokeWidth) / 2f,
                    style = Stroke(width = strokeWidth, pathEffect = dashEffect)
                )

                // 내부 보조 경기장 링
                drawCircle(
                    color = Color(0x33B9C4B6),
                    radius = (size.minDimension) * 0.38f,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }

            // 2. 중앙 야생 적 포켓몬 노드 (지름 약 35%)
            val enemySize = arenaSize * 0.35f
            CenterEnemyNode(
                enemy = enemy,
                enemyDto = enemyDto,
                repository = repository,
                rt = rt,
                rtMax = rtMax,
                size = enemySize,
                enemyHitTrigger = enemyHitTrigger,
                onTap = onEnemyTap,
                modifier = Modifier.align(Alignment.Center)
            )

            // 3. 외곽 6개 동료 슬롯 (지름 약 20%)
            val slotSize = arenaSize * 0.20f
            slotPositions.forEachIndexed { index, pos ->
                val ally = team.find { it.slot == index }
                val isAttacking = attackingSlots.contains(index)
                val isLevelingUp = levelingUpSlots.contains(index)
                val isSelected = selectedSlot == index

                CircularAllySlot(
                    slotIndex = index,
                    ally = ally,
                    repository = repository,
                    position = pos,
                    arenaSize = arenaSize,
                    slotSize = slotSize,
                    isAttacking = isAttacking,
                    isLevelingUp = isLevelingUp,
                    isSelected = isSelected,
                    onClick = {
                        onSelectSlot(index)
                        if (ally != null) {
                            onRelieveAlly(ally)
                        }
                    },
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            // 4. 타입별 공격 발사체 및 슬래시/충격파 이펙트 레이어 (Item 8)
            AttackSlashEffectLayer(
                attackEffects = attackEffects,
                slotPositions = slotPositions,
                modifier = Modifier.fillMaxSize()
            )

            // 5. 중앙 피격 데미지 플로팅 텍스트 (적 머리 위)
            CentralDamageFloatingLayer(
                floatingEffects = floatingEffects,
                modifier = Modifier
                    .size(enemySize)
                    .align(Alignment.Center)
            )
        }
    }
}

/**
 * 아레나 정중앙에 위치한 야생 적 포켓몬 원형 카드
 */
@Composable
fun CenterEnemyNode(
    currentWeather: com.pokeidle.app.domain.system.ActiveWeather? = null,
    enemy: WildEnemy?,
    enemyDto: PokemonDto?,
    repository: PokemonRepository,
    rt: Double,
    rtMax: Double,
    size: Dp,
    enemyHitTrigger: Long = 0L,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val shakeOffsetX = remember { Animatable(0f) }
    val hitFlashAlpha = remember { Animatable(0f) }

    LaunchedEffect(enemyHitTrigger) {
        if (enemyHitTrigger > 0) {
            launch {
                hitFlashAlpha.snapTo(0.50f)
                hitFlashAlpha.animateTo(0f, tween(130))
            }
            shakeOffsetX.animateTo(-8f, tween(25))
            shakeOffsetX.animateTo(8f, tween(30))
            shakeOffsetX.animateTo(-5f, tween(25))
            shakeOffsetX.animateTo(5f, tween(25))
            shakeOffsetX.animateTo(0f, tween(30))
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(androidx.compose.material3.MaterialTheme.colorScheme.surface)
            .border(
                width = 3.dp,
                color = if (enemy?.isShiny == true) Color(0xFFE0A21B) else Color(0xFFD93A2F),
                shape = CircleShape
            )
            .clickable(interactionSource = interactionSource, indication = null) {
                onTap()
            },
        contentAlignment = Alignment.Center
    ) {
        if (enemy != null && enemyDto != null) {
            // 저항 카운트다운 외곽 링 게이지
            val resistRatio = if (rtMax > 0.0) (rt / rtMax).toFloat().coerceIn(0f, 1f) else 0f
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = 3.5.dp.toPx()
                drawArc(
                    color = if (rt < 4.0) Color(0xFFD93A2F) else Color(0xFFE08A1B),
                    startAngle = -90f,
                    sweepAngle = 360f * (1f - resistRatio),
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // 이름 & 레벨
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (enemy.isShiny) {
                        Text("✨", fontSize = 9.sp)
                    }
                    Text(
                        text = "${enemyDto.ko} Lv.${enemy.lvl}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // 적 포켓몬 타입 배지 (Item 6 해결)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 1.dp)
                ) {
                    enemyDto.types.forEach { typeId ->
                        TypeBadge(typeId = typeId)
                    }
                }

                // 적 포켓몬 스프라이트
                PokemonSprite(
                    imgBase64 = if (enemy.isShiny) {
                        repository.getShinySprite(enemy.id) ?: enemyDto.img
                    } else {
                        enemyDto.img
                    },
                    contentDescription = enemyDto.ko,
                    spriteAssetName = repository.getPokemonFormSpriteAsset(enemy.id, enemy.isShiny),
                    modifier = Modifier.offset(x = shakeOffsetX.value.dp),
                    size = (size.value * 0.38f).dp
                )

                // HP 바
                val hpRatio = if (enemy.maxHp > 0) (enemy.hp / enemy.maxHp).toFloat().coerceIn(0f, 1f) else 0f
                LinearProgressIndicator(
                    progress = { hpRatio },
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = when {
                        hpRatio > 0.5f -> Color(0xFF3CAE5C)
                        hpRatio > 0.2f -> Color(0xFFE0A21B)
                        else -> Color(0xFFD93A2F)
                    },
                    trackColor = Color(0xFFE4E9E2)
                )

                Spacer(modifier = Modifier.height(2.dp))

                // HP 수치 & 저항 잔여 시간
                Row(
                    modifier = Modifier.fillMaxWidth(0.75f),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = BattleMath.fmtL(log10(enemy.hp.coerceAtLeast(1e-9))),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF3CAE5C)
                    )
                    Text(
                        text = "저항 ${String.format("%.1f", rt)}s",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (rt < 4.0) Color(0xFFD93A2F) else Color(0xFF8E5BD1)
                    )
                }

                // 버프 배지 (리플렉터/빛의장막)
                val buffs = enemy.enemyBuffs
                if (buffs.hasAnyBuff) {
                    buffs.screen?.let { scr ->
                        Text(
                            text = if (scr == "reflect") "🛡리플렉터" else "🛡빛의장막",
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2F7BD9)
                        )
                    }
                }
            }
        } else {
            Text("탐색 중...", fontSize = 11.sp, color = Color.Gray)
        }

        // 피격 시 붉은 점멸 플래시 오버레이
        if (hitFlashAlpha.value > 0.01f) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(CircleShape)
                    .background(Color(0xFFE53935).copy(alpha = hitFlashAlpha.value))
            )
        }
    }
}

/**
 * 6개 둘레 슬롯에 배치되는 원형 아군 포켓몬 노드
 * - 공격 시 중심(적) 방향으로 돌진(Lunge) 애니메이션 적용
 */
@Composable
fun CircularAllySlot(
    slotIndex: Int,
    ally: AllyMon?,
    repository: PokemonRepository,
    position: Offset,
    arenaSize: Dp,
    slotSize: Dp,
    isAttacking: Boolean,
    isLevelingUp: Boolean = false,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 경기장 중앙(0.5, 0.5)을 기준으로 한 상대 비율 오프셋 (-0.5 ~ +0.5)
    val relX = position.x - 0.50f
    val relY = position.y - 0.50f
    val dist = kotlin.math.sqrt(relX * relX + relY * relY).coerceAtLeast(0.01f)
    val dirX = -relX / dist
    val dirY = -relY / dist

    val lungeAnimX = remember { Animatable(0f) }
    val lungeAnimY = remember { Animatable(0f) }
    val attackScale = remember { Animatable(1f) }
    val popScale = remember { Animatable(1f) }

    LaunchedEffect(isAttacking) {
        if (isAttacking) {
            val targetX = dirX * 7f
            val targetY = dirY * 7f
            launch {
                attackScale.animateTo(1.15f, tween(50))
                attackScale.animateTo(1.0f, tween(90))
            }
            lungeAnimX.animateTo(targetX, tween(50, easing = FastOutSlowInEasing))
            lungeAnimY.animateTo(targetY, tween(50, easing = FastOutSlowInEasing))
            lungeAnimX.animateTo(0f, tween(90, easing = FastOutSlowInEasing))
            lungeAnimY.animateTo(0f, tween(90, easing = FastOutSlowInEasing))
        }
    }

    LaunchedEffect(isLevelingUp) {
        if (isLevelingUp) {
            popScale.animateTo(1.30f, tween(110, easing = FastOutSlowInEasing))
            popScale.animateTo(1.0f, tween(180, easing = FastOutSlowInEasing))
        }
    }

    // 원형 슬롯은 고정하고 포켓몬 스프라이트만 공격/레벨업 애니메이션을 적용한다.
    val offsetX = arenaSize * relX
    val offsetY = arenaSize * relY

    Box(
        modifier = modifier
            .offset(x = offsetX, y = offsetY)
            .size(slotSize)
            .background(if (ally != null) Color.White else Color(0x33FFFFFF), CircleShape)
            .border(
                width = if (isLevelingUp) 3.dp else if (isSelected) 3.dp else 2.dp,
                color = when {
                    isLevelingUp -> Color(0xFFE0A21B) // 레벨업 골드 링
                    isSelected -> Color(0xFF2F7BD9) // 선택 슬롯 강조
                    ally?.isMega == true -> Color(0xFF8E5BD1) // 메가진화
                    ally?.status?.hasAilment == true -> Color(0xFFD93A2F) // 상태이상
                    ally != null -> Color(0xFFB9C4B6) // 일반
                    else -> Color(0xFFCBD6C8) // 빈 슬롯
                },
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (ally != null) {
            val dto = repository.getPokemon(ally.id)
            val activeMegaForm = if (ally.isMega && !com.pokeidle.app.data.model.GigantamaxFormsData.isForm(ally.megaFormId) && ally.megaFormId != -1) {
                repository.getMegas(ally.id).firstOrNull { it.id == ally.megaFormId }
                    ?: if (ally.megaFormId == null) repository.getMegas(ally.id).firstOrNull() else null
            } else null
            // 울트라버스트 중에는 현재 폼 ID가 10157로 바뀌므로,
            // 저장해 둔 복귀 폼 ID를 사용해 황혼의 갈기/새벽의 날개 스프라이트를 유지한다.
            val fusionFormId = when {
                ally.megaFormId == 10155 || ally.megaFormId == 10156 -> ally.megaFormId
                ally.megaFormId == 10157 -> null
                else -> null
            }
            val fusionForm = if (ally.isMega && ally.id == 800) repository.getAllFormViews(800).firstOrNull {
                (fusionFormId == 10155 && it.formKey == "necrozma_dusk_mane") ||
                    (fusionFormId == 10156 && it.formKey == "necrozma_dawn_wings")
            } else null
            val isGmax = com.pokeidle.app.data.model.GigantamaxFormsData.isForm(ally.megaFormId)
            val gmaxSprite = if (isGmax) com.pokeidle.app.data.model.GigantamaxFormsData.getSpriteAssetPathForFormId(ally.megaFormId!!, ally.isShiny) else null
            val shinyBaseSprite = if (ally.isShiny && !ally.isMega) repository.getShinySprite(ally.id) else null
            val transformedSprite = fusionForm?.let { if (ally.isShiny) it.shinySpriteAssetName else it.spriteAssetName }
                ?: fusionFormId?.let { repository.getPokemonFormSpriteAsset(it, ally.isShiny) }
                ?: activeMegaForm?.let { repository.getPokemonFormSpriteAsset(it.id, ally.isShiny) }

            // 1. 레벨 배지 (상단 오버랩)
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .zIndex(2f)
                    .offset(y = (-2).dp)
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.onSurface, RoundedCornerShape(8.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "Lv.${ally.lvl}",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // 1-1. 증표 강화 배지 (◆tb) (Item 4 해결)
            if (ally.tb > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = (-2).dp, y = (-2).dp)
                        .background(Color(0xFF8E5BD1), RoundedCornerShape(8.dp))
                        .padding(horizontal = 3.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "◆${ally.tb}",
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // 2. 포켓몬 스프라이트
            if (dto != null) {
                PokemonSprite(
                    imgBase64 = fusionForm?.img ?: activeMegaForm?.img?.takeIf { it.isNotEmpty() } ?: shinyBaseSprite ?: dto.img,
                    contentDescription = when {
                        com.pokeidle.app.data.model.GigantamaxFormsData.isForm(ally.megaFormId) -> "${dto.ko} 거다이맥스"
                        fusionForm != null -> fusionForm.fullName
                        activeMegaForm != null -> "${dto.ko} 메가진화"
                        else -> dto.ko
                    },
                    modifier = Modifier
                        .align(Alignment.Center)
                        .scale(popScale.value * attackScale.value),
                    size = (slotSize.value * if (com.pokeidle.app.data.model.GigantamaxFormsData.isForm(ally.megaFormId)) 0.85f else 0.65f).dp,
                    centerVisiblePixels = true,
                    spriteAssetName = gmaxSprite ?: ally.megaFormId?.takeIf { ally.isMega }?.let { repository.getPokemonFormSpriteAsset(it, ally.isShiny) } ?: transformedSprite ?: repository.getPokemonFormSpriteAsset(ally.id, ally.isShiny)
                )
            }

            // 3. 공격 주기 쿨다운 게이지 바 (하단)
            val iv0 = if (dto != null) dto.spd.toDouble() else 100.0
            val maxCd = 100.0 / iv0.coerceAtLeast(10.0)
            val cdProgress = ((maxCd - ally.cd) / maxCd).toFloat().coerceIn(0f, 1f)

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth(0.70f)
                    .offset(y = 7.dp)
            ) {
                LinearProgressIndicator(
                    progress = { cdProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = if (cdProgress >= 0.95f) Color(0xFFD93A2F) else Color(0xFFE08A1B),
                    trackColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant
                )
            }

            // 4. 상태이상 뱃지 표시
            if (ally.status.hasAilment) {
                val ailText = when {
                    ally.status.par > 0 -> "마비"
                    ally.status.brn > 0 -> "화상"
                    ally.status.psn > 0 -> "독"
                    ally.status.slp > 0 -> "잠"
                    ally.status.frz > 0 -> "얼음"
                    ally.status.cnf > 0 -> "혼란"
                    else -> "디버프"
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .background(Color(0xFFD93A2F), RoundedCornerShape(4.dp))
                        .padding(horizontal = 2.dp)
                ) {
                    Text(ailText, fontSize = 7.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // 빈 슬롯 '+' 표시
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "빈 슬롯",
                tint = Color(0xFF8A9A8C),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * 중앙 야생 적 바로 위에서 피격 데미지 수치가 떠오르는 플로팅 레이어
 */
@Composable
fun CentralDamageFloatingLayer(
    floatingEffects: List<FloatingEffect>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        floatingEffects.forEach { eff ->
            key(eff.id) {
                AnimatedFloatingDamageItem(eff)
            }
        }
    }
}

@Composable
fun AnimatedFloatingDamageItem(eff: FloatingEffect) {
    val offsetY = remember { Animatable(0f) }
    val alpha = remember { Animatable(1f) }

    LaunchedEffect(eff.id) {
        launch {
            offsetY.animateTo(-45f, tween(650, easing = FastOutSlowInEasing))
        }
        launch {
            kotlinx.coroutines.delay(350)
            alpha.animateTo(0f, tween(300))
        }
    }

    Text(
        text = eff.text,
        fontWeight = FontWeight.ExtraBold,
        fontSize = when {
            eff.isOverkill -> 16.sp
            eff.isCritical -> 15.sp
            eff.isSuperEffective -> 14.sp
            else -> 12.sp
        },
        color = when {
            eff.isOverkill -> Color(0xFFD93A2F)
            eff.isCritical -> Color(0xFFE08A1B)
            eff.isSuperEffective -> Color(0xFFE08A1B)
            eff.isNotVeryEffective -> Color(0xFF758578)
            else -> Color(0xFFD93A2F)
        },
        modifier = Modifier
            .offset(y = (-20 + offsetY.value).dp)
            .graphicsLayer(alpha = alpha.value)
    )
}

/**
 * 포켓몬 공격 발사체 및 타입별 슬래시/충격파 시각 이펙트 (Item 8)
 */
@Composable
fun AttackSlashEffectLayer(
    attackEffects: List<AttackSlashEffect>,
    slotPositions: List<Offset>,
    modifier: Modifier = Modifier
) {
    attackEffects.forEach { eff ->
        key(eff.id) {
            val fromPos = slotPositions.getOrNull(eff.fromSlot) ?: Offset(0.5f, 0.5f)
            SingleAttackEffect(
                from = fromPos,
                moveType = eff.moveType,
                isCritical = eff.isCritical,
                modifier = modifier
            )
        }
    }
}

@Composable
fun SingleAttackEffect(
    from: Offset,
    moveType: Int,
    isCritical: Boolean,
    modifier: Modifier = Modifier
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        anim.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
    }

    val typeColor = TYPE_COLORS[moveType] ?: Color(0xFFD93A2F)
    val progress = anim.value

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val startX = from.x * w
        val startY = from.y * h
        val centerX = w * 0.5f
        val centerY = h * 0.5f

        // 1. 발사체 광선 (Slot -> Center)
        if (progress < 0.65f) {
            val u = (progress / 0.65f).coerceIn(0f, 1f)
            val currentX = startX + (centerX - startX) * u
            val currentY = startY + (centerY - startY) * u
            val trailX = startX + (centerX - startX) * (u - 0.25f).coerceAtLeast(0f)
            val trailY = startY + (centerY - startY) * (u - 0.25f).coerceAtLeast(0f)

            // 궤적 광선
            drawLine(
                color = typeColor.copy(alpha = 0.85f),
                start = Offset(trailX, trailY),
                end = Offset(currentX, currentY),
                strokeWidth = if (isCritical) 6.dp.toPx() else 3.5.dp.toPx(),
                cap = StrokeCap.Round
            )
            // 발사체 코어
            drawCircle(
                color = Color.White,
                radius = if (isCritical) 5.dp.toPx() else 3.5.dp.toPx(),
                center = Offset(currentX, currentY)
            )
            drawCircle(
                color = typeColor,
                radius = if (isCritical) 8.dp.toPx() else 5.5.dp.toPx(),
                center = Offset(currentX, currentY)
            )
        }

        // 2. 중심 충격 버스트 & 슬래시 (0.20 ~ 1.0)
        if (progress >= 0.20f) {
            val impactProgress = ((progress - 0.20f) / 0.80f).coerceIn(0f, 1f)
            val alpha = (1f - impactProgress).coerceIn(0f, 1f)
            val burstRadius = (impactProgress * (if (isCritical) 45.dp.toPx() else 30.dp.toPx()))

            // 충격 링 파동
            drawCircle(
                color = typeColor.copy(alpha = alpha * 0.7f),
                radius = burstRadius,
                center = Offset(centerX, centerY),
                style = Stroke(width = if (isCritical) 4.dp.toPx() else 2.5.dp.toPx())
            )

            // 각도 슬래시 이펙트 (타입 색상 검기)
            val angleRad = kotlin.math.atan2(centerY - startY, centerX - startX)
            val perpAngle = angleRad + (Math.PI / 2.0).toFloat()
            val slashLength = (if (isCritical) 40.dp.toPx() else 28.dp.toPx()) * impactProgress
            val dx = kotlin.math.cos(perpAngle) * slashLength
            val dy = kotlin.math.sin(perpAngle) * slashLength

            drawLine(
                color = typeColor.copy(alpha = alpha),
                start = Offset(centerX - dx, centerY - dy),
                end = Offset(centerX + dx, centerY + dy),
                strokeWidth = if (isCritical) 5.dp.toPx() else 3.dp.toPx(),
                cap = StrokeCap.Round
            )
            // 코어 흰색 빛
            drawLine(
                color = Color.White.copy(alpha = alpha * 0.9f),
                start = Offset(centerX - dx * 0.6f, centerY - dy * 0.6f),
                end = Offset(centerX + dx * 0.6f, centerY + dy * 0.6f),
                strokeWidth = if (isCritical) 2.5.dp.toPx() else 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}
