package com.pokeidle.app.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokeidle.app.presentation.arena.ArenaView
import com.pokeidle.app.presentation.components.BottomPanel
import com.pokeidle.app.presentation.components.GameTopBar
import com.pokeidle.app.presentation.modal.DebugDialog
import com.pokeidle.app.presentation.modal.PokedexDialog
import com.pokeidle.app.presentation.modal.StarterSelectionDialog
import com.pokeidle.app.presentation.modal.AchievementDialog
import com.pokeidle.app.presentation.modal.GameSettingsDialog
import com.pokeidle.app.presentation.modal.OfflineProgressDialog
import com.pokeidle.app.presentation.modal.PrestigeDialog

/**
 * 게임 메인 플레이 화면
 * - 반응형 레이아웃 지원:
 *   1) 일반 스마트폰 세로 모드 (maxWidth < 600dp) 또는 폴드 접었을 때: 세로 1컬럼 일체형 뷰
 *   2) 갤럭시 폴드 펼침 / 태블릿 / 가로 모드 (maxWidth >= 600dp): 좌측 아레나 + 우측 패널 2-Pane 분할 뷰
 */
@Composable
fun GamePlayScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var showDebugDialog by remember { mutableStateOf(false) }
    var showPokedexDialog by remember { mutableStateOf(false) }
    var showShop by remember { mutableStateOf(false) }
    var showPrestigeDialog by remember { mutableStateOf(false) }
    var showAchievementDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val settings = remember { context.getSharedPreferences("pokeidle-settings", android.content.Context.MODE_PRIVATE) }
    var bgmVolume by remember { mutableFloatStateOf(settings.getFloat("bgm_volume", 0.35f)) }
    var sfxVolume by remember { mutableFloatStateOf(settings.getFloat("sfx_volume", 0.35f)) }

    if (uiState.isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF3F5F0)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Color(0xFF2F7BD9))
                Spacer(modifier = Modifier.height(12.dp))
                Text("포켓몬 1,025종 데이터를 불러오는 중...", color = Color.Gray, fontSize = 13.sp)
            }
        }
        return
    }

    // 신규 게임 시작 시 스타터 선택 다이얼로그
    if (uiState.showStarterDialog) {
        val starters = viewModel.pokemonRepository.getStarters()
        StarterSelectionDialog(
            starters = starters,
            onSelectStarter = { starterId ->
                viewModel.selectStarter(starterId)
            }
        )
    }

    // 📖 포켓몬 도감 모달 다이얼로그 (요구사항 3)
    if (showPokedexDialog) {
        PokedexDialog(
            gameState = uiState.gameState,
            repository = viewModel.pokemonRepository,
            onDismiss = { showPokedexDialog = false }
        )
    }

    if (showShop) com.pokeidle.app.presentation.modal.ShopDialog(uiState.gameState, viewModel.pokemonRepository.getAllHeldItems(), { viewModel.buyShopItem(it) }, { showShop = false })
    if (showPrestigeDialog) {
        PrestigeDialog(
            gameState = uiState.gameState,
            now = System.currentTimeMillis(),
            onBuyPerk = { viewModel.buyPrestigePerk(it) },
            onTogglePerk = { key, enabled -> viewModel.togglePrestigePerk(key, enabled) },
            onPrestige = { viewModel.performPrestige() },
            onMakeShiny = { viewModel.makeAllyShiny(it) },
            onUpgradeAlly = { viewModel.buyAllyRebirth(it) },
            pokemonName = { viewModel.pokemonRepository.getPokemon(it)?.ko ?: "No.$it" },
            onDismiss = { showPrestigeDialog = false }
        )
    }

    if (showAchievementDialog) {
        AchievementDialog(
            gameState = uiState.gameState,
            dexSize = viewModel.pokemonRepository.getAllPokemon().size,
            onSelectTitle = { viewModel.selectAchievementTitle(it) },
            onDismiss = { showAchievementDialog = false }
        )
    }

    if (showSettingsDialog) {
        GameSettingsDialog(
            bgmVolume = bgmVolume,
            sfxVolume = sfxVolume,
            onBgmVolumeChange = { bgmVolume = it; settings.edit().putFloat("bgm_volume", it).apply() },
            onSfxVolumeChange = { sfxVolume = it; settings.edit().putFloat("sfx_volume", it).apply() },
            onDismiss = { showSettingsDialog = false }
        )
    }

    uiState.offlineReward?.let { reward ->
        OfflineProgressDialog(reward = reward, onDismiss = { viewModel.dismissOfflineReward() })
    }

    // 🛠️ 개발자 디버그 모달 다이얼로그
    if (showDebugDialog && com.pokeidle.app.BuildConfig.DEBUG) {
        DebugDialog(
            gameState = uiState.gameState,
            repository = viewModel.pokemonRepository,
            onDismiss = { showDebugDialog = false },
            onAddExp = { exp -> viewModel.debugAddExp(exp) },
            onAddRp = { rpL -> viewModel.debugAddRp(rpL) },
            onResetRp = { viewModel.debugResetRp() },
            onAddBalls = { p, u, m -> viewModel.debugAddBalls(p, u, m) },
            onAddAllHeldItems = { viewModel.debugAddAllHeldItems() },
            onAddTokensToParty = { count -> viewModel.debugAddTokensToParty(count) },
            onSetAllyLevel = { slot, lvl -> viewModel.debugSetAllyLevel(slot, lvl) },
            onAddAllyTb = { slot, delta -> viewModel.debugAddAllyTb(slot, delta) },
            onAddAllyRb = { slot, delta -> viewModel.debugAddAllyRb(slot, delta) },
            onFillMegaGauge = { slot -> viewModel.debugFillMegaGauge(slot) },
            onHealStatus = { slot -> viewModel.debugHealStatus(slot) },
            onSetSlotPokemon = { slot, id, shiny -> viewModel.debugSetSlotPokemon(slot, id, shiny) },
            onAddPokemonToBox = { id, lvl, shiny -> viewModel.debugAddPokemonToBox(id, lvl, shiny) },
            onSpawnEnemy = { id, shiny -> viewModel.debugSpawnEnemy(id, shiny) },
            onKillEnemy = { viewModel.debugKillEnemy() },
            onAddKills = { count -> viewModel.debugAddKills(count) },
            onUnlockAllPokedex = { viewModel.debugUnlockAllPokedex() },
            onSetWeather = { w -> viewModel.debugSetWeather(w) },
            onSetTerrain = { t -> viewModel.debugSetTerrain(t) },
            onResetAllSave = { viewModel.debugResetAllSave() }
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F5F0))
    ) {
        // 안드로이드 표준 분할 기준점 (600dp 이상: 폴더블 펼침 / 태블릿 / 가로 화면)
        val isWideScreen = maxWidth >= 600.dp

        if (isWideScreen) {
            // [폴더블 펼침 / 태블릿 분할 뷰]
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 좌측: 원형 배틀 아레나 (가운데 적 + 6개 슬롯)
                Box(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    ArenaView(
                        currentWeather = uiState.currentWeather,
                        enemy = uiState.gameState.enemy,
                        enemyDto = uiState.enemyPokemon,
                        team = uiState.gameState.team,
                        rt = uiState.gameState.rt,
                        rtMax = uiState.gameState.rtMax,
                        selectedSlot = uiState.selectedSlot,
                        attackingSlots = uiState.attackingSlots,
                        enemyHitTrigger = uiState.enemyHitTrigger,
                        levelingUpSlots = uiState.levelingUpSlots,
                        floatingEffects = uiState.floatingEffects,
                        attackEffects = uiState.attackEffects,
                        repository = viewModel.pokemonRepository,
                        onSelectSlot = { slot -> viewModel.selectSlot(slot) },
                        onRelieveAlly = { ally -> viewModel.relieveAlly(ally) },
                        onEnemyTap = { viewModel.tapEnemy() },
                        modifier = Modifier
                            .fillMaxHeight(0.95f)
                            .aspectRatio(1f)
                    )
                }

                // 우측: 상단 정보바 + 하단 제어 패널
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GameTopBar(
                        gameState = uiState.gameState,
                        teamDps = viewModel.getTeamDpsLabel(),
                        expPerSecond = viewModel.getTeamExpPerSecondLabel(),
                        currentWeather = uiState.currentWeather,
                        currentTerrain = uiState.currentTerrain,
                        onChangeRegion = { regionId ->
                            viewModel.changeRegion(regionId)
                        },
                        onOpenDebug = { showDebugDialog = true },
                        onOpenPokedex = { showPokedexDialog = true },
                        onOpenShop = { showShop = true },
                        onOpenPrestige = { showPrestigeDialog = true },
                        onOpenAchievements = { showAchievementDialog = true },
                        onOpenSettings = { showSettingsDialog = true }
                    )

                    BottomPanel(
                        selectedSlot = uiState.selectedSlot,
                        onSelectSlot = { slot -> viewModel.selectSlot(slot) },
                        gameState = uiState.gameState,
                        repository = viewModel.pokemonRepository,
                        onLevelUp = { ally, times -> viewModel.levelUpAlly(ally, times) },
                        onEvolveAlly = { ally, toId -> viewModel.evolveAlly(ally, toId) },
                        onMegaEvolveAlly = { ally -> viewModel.megaEvolveAlly(ally) },
                        onRelieveAlly = { ally -> viewModel.relieveAlly(ally) },
                        onRerollMove = { ally -> viewModel.rerollMove(ally) },
                        onRerollAbility = { ally -> viewModel.rerollAbility(ally) },
                        onUpgradeTokenSpeed = { ally -> viewModel.upgradeTokenSpeed(ally) },
                        onFormatAlly = { ally -> viewModel.formatAlly(ally) },
                        onEquipItem = { ally, itemId -> viewModel.equipItem(ally, itemId) },
                        onReleaseBoxMon = { ally -> viewModel.releaseBoxMon(ally) },
                        onSwapParty = { slot, boxMon -> viewModel.swapTeamAndBox(slot, boxMon) },
                        recentLogs = uiState.recentLogs,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                }
            }
        } else {
            // [일반 스마트폰 세로 모드 / 폴더블 접었을 때]
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // 1. 상단 정보바
                GameTopBar(
                    gameState = uiState.gameState,
                    teamDps = viewModel.getTeamDpsLabel(),
                    expPerSecond = viewModel.getTeamExpPerSecondLabel(),
                    currentWeather = uiState.currentWeather,
                    currentTerrain = uiState.currentTerrain,
                    onChangeRegion = { regionId ->
                        viewModel.changeRegion(regionId)
                    },
                    onOpenDebug = { showDebugDialog = true },
                    onOpenPokedex = { showPokedexDialog = true },
                    onOpenShop = { showShop = true },
                        onOpenPrestige = { showPrestigeDialog = true },
                    onOpenAchievements = { showAchievementDialog = true },
                    onOpenSettings = { showSettingsDialog = true }
                )

                // 2. 원형 아레나 (가운데 적 포켓몬 + 적을 둘러싼 아군 6마리 파티)
                ArenaView(
                        currentWeather = uiState.currentWeather,
                    enemy = uiState.gameState.enemy,
                    enemyDto = uiState.enemyPokemon,
                    team = uiState.gameState.team,
                    rt = uiState.gameState.rt,
                    rtMax = uiState.gameState.rtMax,
                    selectedSlot = uiState.selectedSlot,
                    attackingSlots = uiState.attackingSlots,
                    enemyHitTrigger = uiState.enemyHitTrigger,
                    levelingUpSlots = uiState.levelingUpSlots,
                    floatingEffects = uiState.floatingEffects,
                    attackEffects = uiState.attackEffects,
                    repository = viewModel.pokemonRepository,
                    onSelectSlot = { slot -> viewModel.selectSlot(slot) },
                    onRelieveAlly = { ally -> viewModel.relieveAlly(ally) },
                    onEnemyTap = { viewModel.tapEnemy() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.15f, fill = false)
                        .aspectRatio(1f, matchHeightConstraintsFirst = true)
                )

                // 3. 하단 제어 패널 (팀 레벨업, 보관 박스, 전투 로그)
                BottomPanel(
                    selectedSlot = uiState.selectedSlot,
                    onSelectSlot = { slot -> viewModel.selectSlot(slot) },
                    gameState = uiState.gameState,
                    repository = viewModel.pokemonRepository,
                    onLevelUp = { ally, times -> viewModel.levelUpAlly(ally, times) },
                    onEvolveAlly = { ally, toId -> viewModel.evolveAlly(ally, toId) },
                    onMegaEvolveAlly = { ally -> viewModel.megaEvolveAlly(ally) },
                    onRelieveAlly = { ally -> viewModel.relieveAlly(ally) },
                    onRerollMove = { ally -> viewModel.rerollMove(ally) },
                    onRerollAbility = { ally -> viewModel.rerollAbility(ally) },
                    onUpgradeTokenSpeed = { ally -> viewModel.upgradeTokenSpeed(ally) },
                    onFormatAlly = { ally -> viewModel.formatAlly(ally) },
                    onEquipItem = { ally, itemId -> viewModel.equipItem(ally, itemId) },
                    onReleaseBoxMon = { ally -> viewModel.releaseBoxMon(ally) },
                    onSwapParty = { slot, boxMon -> viewModel.swapTeamAndBox(slot, boxMon) },
                    recentLogs = uiState.recentLogs,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.85f)
                )
            }
        }
    }
}
