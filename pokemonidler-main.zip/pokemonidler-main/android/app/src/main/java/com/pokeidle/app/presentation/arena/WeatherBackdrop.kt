package com.pokeidle.app.presentation.arena

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.pokeidle.app.domain.system.WeatherType

@Composable
fun WeatherBackdrop(weather: WeatherType?) {
    if (weather == null) return
    val transition = rememberInfiniteTransition(label = "weather")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "weather drift")
    Canvas(Modifier.fillMaxSize()) {
        val tint = when (weather) {
            WeatherType.SUN, WeatherType.HARD_SUN -> Color(0xFFFFB74D)
            WeatherType.RAIN, WeatherType.HARD_RAIN -> Color(0xFF426DA9)
            WeatherType.SNOW -> Color(0xFFB3DAED)
            WeatherType.SAND -> Color(0xFFD6AE69)
            WeatherType.WIND -> Color(0xFF8CBCA9)
        }
        drawRect(tint.copy(alpha = 0.25f))
        repeat(32) { i ->
            val x = ((i * 0.618f + phase * 0.3f) % 1f) * size.width
            val y = ((i * 0.37f + phase) % 1f) * size.height
            when (weather) {
                WeatherType.RAIN, WeatherType.HARD_RAIN -> drawLine(Color(0xFF9DD7FF), Offset(x, y), Offset(x - 5f, y + 18f), 2f)
                WeatherType.SNOW -> drawCircle(Color.White.copy(alpha = 0.75f), 3f, Offset(x, y))
                WeatherType.SAND -> drawCircle(tint.copy(alpha = 0.7f), 2f, Offset(x, y))
                WeatherType.WIND -> drawLine(Color.White.copy(alpha = 0.35f), Offset(x, y), Offset(x + 25f, y - 4f), 2f)
                else -> if (i < 8) drawCircle(tint.copy(alpha = 0.08f), size.width * (0.1f + phase * 0.2f), Offset(size.width * 0.8f, size.height * 0.15f))
            }
        }
    }
}
