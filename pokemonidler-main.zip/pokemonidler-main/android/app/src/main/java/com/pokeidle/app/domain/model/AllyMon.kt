package com.pokeidle.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 파티 또는 박스에 보관된 동료 포켓몬 엔티티
 */
@Serializable
data class AllyMon(
    var id: Int,                        // 도감 번호 (1 ~ 1025)
    var lvl: Int = 1,                   // 현재 레벨
    var cd: Double = 1.0,               // 공격 주기 쿨다운 잔여 시간(초)
    var move: Int = 33,                 // 장착 기술 ID (기본: 몸통박치기 33)
    var ab: Int = 1,                    // 장착 특성 ID
    var slot: Int = -1,                 // 파티 슬롯 인덱스 (0 ~ 5: 파티, -1: 박스 보관)
    var joined: Long = 0L,              // 합류 순번 (날씨/필드 적용 우선순위 판별용)
    var tb: Int = 0,                    // 증표를 사용한 영구 강화 레벨 (Token Boost)
    var rb: Int = 0,                    // 환생 포인트 강화 레벨 (Rebirth Boost)
    var tbOff: Boolean = false,         // 증표강화 일시 OFF
    var rbOff: Boolean = false,         // 환생강화 일시 OFF
    var mg: Double = 0.0,               // 메가 게이지 (0.0 ~ 100.0)
    var isMega: Boolean = false,        // 메가진화 / 폼체인지 활성화 여부
    var megaDuration: Double = 0.0,     // 메가진화 잔여 지속 시간 (기본 30초)
    var megaFormId: Int? = null,        // 현재 활성화된 메가/폼 ID
    var ultraRevertFormId: Int? = null, // 울트라버스트 종료 후 복원할 융합 폼 ID
    var status: AllyStatus = AllyStatus(), // 전투 상태이상 및 랭크 변화
    var item: String? = null,           // 장착한 지닌도구 ID (e.g. "charcoal", "choice-band")
    var isShiny: Boolean = false        // 동료 이로치 여부
)
