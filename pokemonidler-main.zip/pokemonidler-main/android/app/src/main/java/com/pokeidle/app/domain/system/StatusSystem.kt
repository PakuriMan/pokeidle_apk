package com.pokeidle.app.domain.system

import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.data.model.NecrozmaFusionData
import com.pokeidle.app.data.model.CanonicalStatsData
import com.pokeidle.app.domain.model.AllyMon
import kotlin.math.max
import kotlin.random.Random

/**
 * 상태이상(Status) 및 능력 랭크 변화의 발생, 틱 감쇠, 유저 회복 돕기(relieve) 처리 시스템
 */
object StatusSystem {

    const val RANK_DUR = 40.0 // 랭크 변화 기본 지속 시간

    val STATUS_BASE_DURATIONS = mapOf(
        "par" to 20.0, // 마비
        "brn" to 20.0, // 화상
        "psn" to 25.0, // 독
        "slp" to 8.0,  // 잠듦
        "frz" to 7.0,  // 얼음
        "cnf" to 13.0, // 혼란
        "acc" to 25.0  // 명중 저하
    )

    /**
     * 방어 종족값에 따른 랭크 저하 회복 속도 배율: clamp(def / 70, 0.5, 3.0)
     */
    fun getDefRate(ally: AllyMon, repo: PokemonRepository): Double {
        val fusionDef = if (ally.id == 800) repo.getAllFormViews(800).firstOrNull {
            (ally.megaFormId == NecrozmaFusionData.DUSK_MANE_FORM_ID && it.formKey == "necrozma_dusk_mane") ||
                (ally.megaFormId == NecrozmaFusionData.DAWN_WINGS_FORM_ID && it.formKey == "necrozma_dawn_wings")
        }?.def else null
        val def = CanonicalStatsData.getActiveFormStat(ally)?.def ?: fusionDef ?: repo.getPokemon(ally.id)?.def ?: 70
        return (def / 70.0).coerceIn(0.5, 3.0)
    }

    /**
     * 특수방어 종족값에 따른 상태이상 회복 속도 배율: clamp(sdf / 70, 0.5, 3.0)
     */
    fun getSdfRate(ally: AllyMon, repo: PokemonRepository): Double {
        val fusionSdf = if (ally.id == 800) repo.getAllFormViews(800).firstOrNull {
            (ally.megaFormId == NecrozmaFusionData.DUSK_MANE_FORM_ID && it.formKey == "necrozma_dusk_mane") ||
                (ally.megaFormId == NecrozmaFusionData.DAWN_WINGS_FORM_ID && it.formKey == "necrozma_dawn_wings")
        }?.sdf else null
        val sdf = CanonicalStatsData.getActiveFormStat(ally)?.sdf ?: fusionSdf ?: repo.getPokemon(ally.id)?.sdf ?: 70
        return (sdf / 70.0).coerceIn(0.5, 3.0)
    }

    /**
     * 매 틱마다 상태이상 및 버프 지속 시간 감소 처리
     */
    fun tickStatus(
        team: List<AllyMon>,
        dt: Double,
        repo: PokemonRepository,
        onStatusRecovered: ((AllyMon, String) -> Unit)? = null
    ) {
        for (ally in team) {
            val s = ally.status
            // 원본 효과: 회복 속도에 0.95배를 적용해 상태/랭크 회복이 조금 느려진다.
            val rankDuration = if (ally.item == "clear-amulet") 0.95 else 1.0
            val statusDuration = if (ally.item == "leftovers") 0.95 else 1.0
            val dr = dt * getDefRate(ally, repo) / rankDuration
            val sr = dt * getSdfRate(ally, repo) / statusDuration

            // 1. 상태이상 잔여 시간 감쇠 (특수방어 비례)
            if (s.par > 0.0) { s.par -= sr; if (s.par <= 0.0) { s.par = 0.0; onStatusRecovered?.invoke(ally, "마비") } }
            if (s.brn > 0.0) { s.brn -= sr; if (s.brn <= 0.0) { s.brn = 0.0; onStatusRecovered?.invoke(ally, "화상") } }
            if (s.psn > 0.0) { s.psn -= sr; if (s.psn <= 0.0) { s.psn = 0.0; onStatusRecovered?.invoke(ally, "독") } }
            if (s.tox > 0.0) { s.tox -= sr; if (s.tox <= 0.0) { s.tox = 0.0; onStatusRecovered?.invoke(ally, "맹독") } }
            if (s.slp > 0.0) { s.slp -= sr; if (s.slp <= 0.0) { s.slp = 0.0; onStatusRecovered?.invoke(ally, "잠듦") } }
            if (s.frz > 0.0) { s.frz -= sr; if (s.frz <= 0.0) { s.frz = 0.0; onStatusRecovered?.invoke(ally, "얼음") } }
            if (s.cnf > 0.0) { s.cnf -= sr; if (s.cnf <= 0.0) { s.cnf = 0.0; onStatusRecovered?.invoke(ally, "혼란") } }
            if (s.acc > 0.0) { s.acc -= sr; if (s.acc <= 0.0) { s.acc = 0.0; onStatusRecovered?.invoke(ally, "명중 저하") } }

            // 2. 특성 버프 타이머 감쇠 (절대 시간)
            if (s.wb > 0.0) { s.wb = max(0.0, s.wb - dt) }
            if (s.rage > 0.0) { s.rage = max(0.0, s.rage - dt) }
            if (s.shell > 0.0) { s.shell = max(0.0, s.shell - dt) }
            if (s.kill > 0.0) { s.kill = max(0.0, s.kill - dt) }
            if (s.steam > 0.0) { s.steam = max(0.0, s.steam - dt) }
            if (s.zMoveDuration > 0.0) { s.zMoveDuration = max(0.0, s.zMoveDuration - dt) }

            // 3. 랭크 변화 지속 시간 감쇠 (방어 비례)
            if (s.rank != 0) {
                s.rankLeft -= dr
                if (s.rankLeft <= 0.0) {
                    s.rank = 0
                    s.rankLeft = 0.0
                    onStatusRecovered?.invoke(ally, "능력 변화")
                }
            }
        }
    }

    /**
     * 유저가 동료 슬롯/카드를 터치하여 회복을 돕는 기능 (relieve)
     * - 랭크 저하 1단계 회복 (단순 특성이면 한 번에 즉시 0단계로 복구)
     * - 상태이상 타이머 3초 단축
     */
    fun relieve(ally: AllyMon, team: List<AllyMon>, repo: PokemonRepository): Boolean {
        val s = ally.status
        var didSomething = false

        if (s.rank < 0) {
            if (AbilitySystem.has(ally, team, repo, "단순")) {
                s.rank = 0
            } else {
                s.rank++
            }
            if (s.rank == 0) s.rankLeft = 0.0
            didSomething = true
        }

        val reduce = 3.0
        if (s.par > 0.0) { s.par = max(0.0, s.par - reduce); didSomething = true }
        if (s.brn > 0.0) { s.brn = max(0.0, s.brn - reduce); didSomething = true }
        if (s.psn > 0.0) { s.psn = max(0.0, s.psn - reduce); didSomething = true }
        if (s.tox > 0.0) { s.tox = max(0.0, s.tox - reduce); didSomething = true }
        if (s.slp > 0.0) { s.slp = max(0.0, s.slp - reduce); didSomething = true }
        if (s.frz > 0.0) { s.frz = max(0.0, s.frz - reduce); didSomething = true }
        if (s.cnf > 0.0) { s.cnf = max(0.0, s.cnf - reduce); didSomething = true }
        if (s.acc > 0.0) { s.acc = max(0.0, s.acc - reduce); didSomething = true }

        return didSomething
    }

    /**
     * 랭크 변동 적용
     */
    fun addRank(
        ally: AllyMon,
        delta: Int,
        team: List<AllyMon>,
        enemyTypes: List<Int>,
        weather: WeatherType?,
        repo: PokemonRepository
    ): Boolean {
        if (delta < 0) {
            // 랭크 저하 방지 특성 확인
            if (AbilitySystem.has(ally, team, repo, "괴력집게", "균사의힘", "메탈프로텍트", "부풀린가슴", "클리어바디", "하얀연기")) {
                return false
            }
            // 적 타입 면역 특성 확인
            if (AbilitySystem.isResistImmune(ally, enemyTypes, team, weather, repo) != null) {
                return false
            }
            // 기묘한약 50% 확률 방어
            if (AbilitySystem.teamHas(team, repo, "기묘한약") && Random.nextDouble() < 0.5) {
                return false
            }
            // 피격 반응 특성 트리거
            onDisturbed(ally, enemyTypes, team, repo)
        }

        val s = ally.status
        s.rank = (s.rank + delta).coerceIn(-6, 6)
        s.rankLeft = RANK_DUR
        return true
    }

    /**
     * 상태이상 부여
     */
    fun addStatus(
        ally: AllyMon,
        key: String,
        duration: Double? = null,
        team: List<AllyMon>,
        enemyTypes: List<Int>,
        weather: WeatherType?,
        terrain: TerrainType?,
        repo: PokemonRepository
    ): Boolean {
        val s = ally.status
        val ab = AbilitySystem.getEffectiveAbilityName(ally, team, repo)

        if (ab == "균사의힘") return false
        if (key == "acc" && ab == "날카로운눈") return false
        if (AbilitySystem.isResistImmune(ally, enemyTypes, team, weather, repo) != null) return false

        if (key == "frz" && ab == "마그마의무장") return false
        if (key == "brn" && (ab in setOf("수의베일", "수포"))) return false
        if (key == "slp" && (ab in setOf("불면", "의기양양", "일찍기상") || AbilitySystem.teamHas(team, repo, "스위트베일"))) return false
        if (ab == "정화의소금" || (ab == "촉촉바디" && (weather == WeatherType.RAIN || weather == WeatherType.HARD_RAIN))) return false
        if (key == "psn" && (ab in setOf("면역", "포이즌힐") || AbilitySystem.teamHas(team, repo, "파스텔베일"))) return false
        if (key == "cnf" && ab in setOf("갈지자걸음", "굳건한신념", "둔감", "마이페이스")) return false

        onDisturbed(ally, enemyTypes, team, repo)

        // 필드 상태이상 면역 확인
        if (WeatherTerrainSystem.isStatusBlocked(key, terrain)) {
            return false
        }

        val dur = duration ?: (STATUS_BASE_DURATIONS[key] ?: 15.0)
        when (key) {
            "par" -> s.par = dur
            "brn" -> s.brn = dur
            "psn" -> s.psn = dur
            "slp" -> s.slp = dur
            "frz" -> s.frz = dur
            "cnf" -> s.cnf = dur
            "acc" -> s.acc = dur
        }
        return true
    }

    /**
     * 방해(저항 공격)를 받았을 때 발동하는 특성 처리
     */
    fun onDisturbed(
        ally: AllyMon,
        enemyTypes: List<Int>,
        team: List<AllyMon>,
        repo: PokemonRepository
    ) {
        val s = ally.status
        val ab = AbilitySystem.getEffectiveAbilityName(ally, team, repo)

        if (ab == "깨어진갑옷") s.wb = 10.0
        if (ab in setOf("발끈", "분노의경혈")) s.rage = 10.0
        if (ab == "분노의껍질") s.shell = 8.0
        if (ab == "전기로바꾸기") s.charge = true
        if (ab == "증기기관" && (10 in enemyTypes || 11 in enemyTypes)) s.steam = 10.0
        if (ab == "변색") s.color = enemyTypes
    }
}
