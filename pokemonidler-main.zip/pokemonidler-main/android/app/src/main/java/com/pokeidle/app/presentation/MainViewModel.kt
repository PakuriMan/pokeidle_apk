package com.pokeidle.app.presentation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pokeidle.app.data.local.db.PokeIdleDatabaseHelper
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.repository.DefaultPokemonRepository
import com.pokeidle.app.data.repository.SqliteSaveRepository
import com.pokeidle.app.domain.engine.BattleEngine
import com.pokeidle.app.domain.engine.BattleEvent
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.AllyStatus
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.domain.model.PrestigePerks
import com.pokeidle.app.domain.model.WildEnemy
import com.pokeidle.app.domain.system.ActiveTerrain
import com.pokeidle.app.domain.system.ActiveWeather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class FloatingEffect(
    val id: Long,
    val text: String,
    val isSuperEffective: Boolean = false,
    val isNotVeryEffective: Boolean = false,
    val isCritical: Boolean = false,
    val isOverkill: Boolean = false,
    val fromSlot: Int = -1
)

data class AttackSlashEffect(
    val id: Long,
    val fromSlot: Int,
    val moveType: Int,
    val isCritical: Boolean = false
)

data class MainUiState(
    val isLoading: Boolean = true,
    val showStarterDialog: Boolean = false,
    val gameState: GameState = GameState(),
    val enemyPokemon: PokemonDto? = null,
    val currentWeather: ActiveWeather? = null,
    val currentTerrain: ActiveTerrain? = null,
    val recentLogs: List<String> = emptyList(),
    val floatingEffects: List<FloatingEffect> = emptyList(),
    val attackEffects: List<AttackSlashEffect> = emptyList(),
    val selectedSlot: Int = 0,
    val attackingSlots: Set<Int> = emptySet(),
    val enemyHitTrigger: Long = 0L,
    val levelingUpSlots: Set<Int> = emptySet(),
    val stateVersion: Long = 0L,
    val offlineReward: OfflineReward? = null
)

data class OfflineReward(val expL: Double, val kills: Long, val elapsedSeconds: Long)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val pokemonRepository = DefaultPokemonRepository()
    private val dbHelper = PokeIdleDatabaseHelper(application)
    private val psvManager = com.pokeidle.app.data.local.PsvFileManager(application, dbHelper)
    val saveRepository = SqliteSaveRepository(dbHelper, psvManager)

    var battleEngine: BattleEngine? = null
        private set

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun getTeamDpsLabel(): String = BattleMath.fmtL(battleEngine?.getTeamDpsL() ?: 0.0)

    fun getTeamExpPerSecondLabel(): String {
        val rateL = battleEngine?.getTeamExpPerSecondL() ?: Double.NEGATIVE_INFINITY
        return "초당 약 ${if (rateL.isFinite()) BattleMath.fmtL(rateL) else "0"} EXP"
    }

    fun dismissOfflineReward() {
        _uiState.value = _uiState.value.copy(offlineReward = null)
    }

    fun buyShopItem(id: String) {
        if (battleEngine?.buyShopItem(id) == true) {
            syncGameState()
            triggerManualSave()
        }
    }

    fun buyPrestigePerk(key: String): Boolean {
        val state = battleEngine?.gameState ?: return false
        val definition = PrestigePerks.all.firstOrNull { it.key == key } ?: return false
        val level = state.perks[key] ?: 0
        if (definition.maxLevel != null && level >= definition.maxLevel) return false
        val costL = BattleMath.perkCostL(definition.baseCost, level)
        if (state.rpL < costL) return false
        state.rpL = BattleMath.logSub(state.rpL, costL)
        state.perks[key] = level + 1
        addLog("환생 상점: ${definition.name} Lv.${level + 1} 구매")
        syncGameState()
        triggerManualSave()
        return true
    }

    fun togglePrestigePerk(key: String, enabled: Boolean) {
        val state = battleEngine?.gameState ?: return
        state.offPerk[key] = !enabled
        syncGameState()
        triggerManualSave()
    }

    fun performPrestige(): Boolean {
        val engine = battleEngine ?: return false
        val state = engine.gameState
        val now = System.currentTimeMillis()
        if (engine.getEnemyLevel() < 100 || now - state.lastPrestigeAt < 5 * 60 * 1000L || state.runExp <= 0.0) return false
        val earnedPointsL = BattleMath.runPointsL(state.runExp, state.K)
        state.maxLvl = maxOf(state.maxLvl, engine.getEnemyLevel())
        state.rpL = BattleMath.logAdd(state.rpL, earnedPointsL)
        state.rebirths += 1
        state.lastPrestigeAt = now
        (state.team + state.box).forEach { ally ->
            if (ally.isMega) engine.megaRevert(ally)
            ally.lvl = 1
            ally.cd = 1.0
            ally.status = AllyStatus()
            ally.mg = 0.0
            ally.isMega = false
            ally.megaFormId = null
            ally.ultraRevertFormId = null
            ally.megaDuration = 0.0
        }
        state.kills = 0L
        state.exp = 0.0
        state.runExp = 0.0
        state.K = 0
        state.enemy = null
        state.rt = 30.0
        state.rtMax = 30.0
        engine.spawnEnemy()
        addLog("환생 완료! ${state.rebirths}회째 · 환생 포인트 +${BattleMath.fmtL(earnedPointsL)}P")
        syncGameState()
        triggerManualSave()
        return true
    }

    fun selectAchievementTitle(titleId: String) {
        val state = battleEngine?.gameState ?: return
        state.selectedTitle = titleId
        syncGameState()
        triggerManualSave()
    }

    private val logs = mutableListOf<String>()
    private var effectCounter = 0L
    private var stateVersionCounter = 0L

    init {
        loadDataAndStartEngine()
    }

    private fun loadDataAndStartEngine() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                // 1. data.json, 기본/ PokéAPI 이로치, 기술, 도구 에셋 로드
                val assets = getApplication<Application>().assets
                val shinyStream = try { assets.open("shiny.json") } catch (e: Exception) { null }
                val pokeApiShinyStream = try { assets.open("shiny_sprites.json") } catch (e: Exception) { null }
                val damagingStream = try { assets.open("damaging_moves.json") } catch (e: Exception) { null }
                val heldItemsStream = try { assets.open("held_items.json") } catch (e: Exception) { null }
                val pokemonFormsStream = try { assets.open("pokemon_forms.json") } catch (e: Exception) { null }
                try {
                    assets.open("data.json").use { dataStream ->
                        pokemonRepository.loadData(dataStream, shinyStream, damagingStream, heldItemsStream, pokeApiShinyStream, pokemonFormsStream)
                    }
                } finally {
                    shinyStream?.close()
                    pokeApiShinyStream?.close()
                    damagingStream?.close()
                    heldItemsStream?.close()
                    pokemonFormsStream?.close()
                }

                // 2. 세이브 데이터 로드 또는 신규 생성
                val loadedState = saveRepository.loadGame().getOrNull()
                val needsStarter = loadedState == null || loadedState.team.isEmpty()
                val state: GameState = loadedState ?: GameState.createInitial(starterId = 25)

                // 제거된 도구를 예전 세이브가 계속 보유/장착하지 않도록 정리한다.
                val supportedItemIds = pokemonRepository.getAllHeldItems().mapTo(mutableSetOf()) { it.id }
                var removedLegacyItems = state.items.keys.removeAll { it !in supportedItemIds }
                (state.team + state.box).forEach { ally ->
                    if (ally.item != null && ally.item !in supportedItemIds) {
                        ally.item = null
                        removedLegacyItems = true
                    }
                }
                if (removedLegacyItems && loadedState != null) saveRepository.saveGame(state)

                val engine = BattleEngine(state, pokemonRepository)
                battleEngine = engine
                val offlineSeconds = if (state.lastSeenAt > 0L) {
                    ((System.currentTimeMillis() - state.lastSeenAt).coerceAtLeast(0L) / 1000.0)
                } else 0.0
                val offlineResult = if (!needsStarter) engine.applyOfflineProgress(offlineSeconds) else null
                val offlineSummary = offlineResult?.let {
                    OfflineReward(it.first, it.second, offlineSeconds.toLong().coerceAtMost(6 * 60 * 60L))
                }
                if (offlineResult != null) saveRepository.saveGame(state)

                // 배틀 이벤트 리스너 등록
                engine.addEventListener { event ->
                    handleBattleEvent(event)
                }

                val enemyDto: PokemonDto? = state.enemy?.let { e: WildEnemy -> pokemonRepository.getPokemon(e.id) }

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    showStarterDialog = needsStarter,
                    gameState = state,
                    enemyPokemon = enemyDto,
                    currentWeather = engine.currentWeather,
                    currentTerrain = engine.currentTerrain,
                    offlineReward = offlineSummary
                )
            }

            // 3. 100ms 전투 루프 코루틴 실행
            startBattleLoop()

            // 4. 주기적 자동 저장 (10초 주기)
            startAutoSaveLoop()
        }
    }

    private fun startBattleLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                val engine = battleEngine
                if (engine != null && !_uiState.value.isLoading && !_uiState.value.showStarterDialog) {
                    engine.tick(0.1)

                    val state = engine.gameState
                    val enemy = state.enemy
                    val enemyDto = enemy?.let { pokemonRepository.getPokemon(it.id) }

                    _uiState.value = _uiState.value.copy(
                        gameState = state.copy(
                            team = state.team.map { it.copy(status = it.status.copy()) }.toMutableList(),
                            box = synchronized(state.box) { state.box.toList() }.map { it.copy(status = it.status.copy()) }.toMutableList(),
                            tokens = state.tokens.toMutableMap(),
                            enemy = enemy?.copy()
                        ),
                        enemyPokemon = enemyDto,
                        currentWeather = engine.currentWeather,
                        currentTerrain = engine.currentTerrain,
                        recentLogs = logs.takeLast(50)
                    )
                }
                delay(100) // 100ms TICK
            }
        }
    }

    private fun startAutoSaveLoop() {
        viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(10000) // 10초마다 자동 세이브
                val state = battleEngine?.gameState
                if (state != null) {
                    saveRepository.saveGame(state)
                }
            }
        }
    }

    private fun triggerManualSave() {
        val state = battleEngine?.gameState ?: return
        viewModelScope.launch(Dispatchers.IO) {
            saveRepository.saveGame(state)
        }
    }

    private fun handleBattleEvent(event: BattleEvent) {
        when (event) {
            is BattleEvent.Hit -> {
                val dmgText = BattleMath.formatNumber(event.damage)
                val eff = FloatingEffect(
                    id = ++effectCounter,
                    text = dmgText,
                    isSuperEffective = event.isSuperEffective,
                    isNotVeryEffective = event.isNotVeryEffective,
                    isCritical = event.isCritical,
                    fromSlot = event.slot
                )
                addFloatingEffect(eff)
                val slashEff = AttackSlashEffect(
                    id = ++effectCounter,
                    fromSlot = event.slot,
                    moveType = event.moveType,
                    isCritical = event.isCritical
                )
                addAttackSlashEffect(slashEff)
                triggerSlotLunge(event.slot)
                triggerEnemyHit()
            }
            is BattleEvent.Miss -> {
                val eff = FloatingEffect(
                    id = ++effectCounter,
                    text = "빗나감",
                    fromSlot = event.slot
                )
                addFloatingEffect(eff)
                triggerSlotLunge(event.slot)
            }
            is BattleEvent.Overkill -> {
                val eff = FloatingEffect(
                    id = ++effectCounter,
                    text = "⚡ 오버킬 +${event.extraKills}",
                    isOverkill = true
                )
                addFloatingEffect(eff)
                addLog("⚡ 오버킬! 연쇄 처치 +${event.extraKills}")
            }
            is BattleEvent.EnemyDefeated -> {
                val p = pokemonRepository.getPokemon(event.pokemonId)
                val shinyTag = if (event.isShiny) "✨ [이로치] " else ""
                val expText = BattleMath.formatNumber(event.expGained)
                addLog("${shinyTag}${p?.ko ?: "적"} 처치! 경험치 +${expText}")
            }
            is BattleEvent.PokemonCaught -> {
                val p = pokemonRepository.getPokemon(event.pokemonId)
                val shinyTag = if (event.isShiny) "✨ 이로치 " else ""
                if (event.isSentToBox) {
                    addLog("${shinyTag}${p?.ko ?: "포켓몬"}이(가) 합류해 박스로 보내졌다.")
                } else {
                    addLog("🎉 ${shinyTag}${p?.ko ?: "포켓몬"}이(가) 파티 동료로 합류했다!")
                }
            }
            is BattleEvent.TokenGained -> {
                val p = pokemonRepository.getPokemon(event.pokemonId)
                addLog("💎 ${p?.ko ?: "포켓몬"}의 증표 +${event.count}개 획득!")
            }
            is BattleEvent.BallRewarded -> {
                val name = when (event.ballType) {
                    "master" -> "마스터볼"
                    "ultra" -> "하이퍼볼"
                    else -> "몬스터볼"
                }
                addLog("🎁 ${name} 1개를 획득했다! (보유 ${event.count}개)")
            }
            is BattleEvent.ShinyEncounter -> {
                val p = pokemonRepository.getPokemon(event.pokemonId)
                addLog("✨ 색이 다른 [${p?.ko ?: "포켓몬"}]이(가) 나타났다! (경험치 25배)")
            }
            is BattleEvent.LevelUp -> {
                addLog("🎉 Lv.${event.newLevel} 달성!")
                triggerSlotLevelUp(event.slot)
            }
            is BattleEvent.Evolution -> {
                val from = pokemonRepository.getPokemon(event.oldId)
                val to = pokemonRepository.getPokemon(event.newId)
                addLog("✨ 축하합니다! ${from?.ko ?: "포켓몬"}은(는) ${to?.ko ?: "진화체"}(으)로 진화했다!")
                if (event.slot >= 0) {
                    triggerSlotLevelUp(event.slot)
                }
            }
            is BattleEvent.EnemyResist -> {
                addLog("⚠ ${event.message}")
            }
            is BattleEvent.LogMessage -> {
                addLog(event.text)
            }
            is BattleEvent.ItemDropped -> {
                addLog("🎒 [${event.itemName}]을(를) 주웠다! (보유: ${event.count}개)")
            }
            is BattleEvent.ItemEquipped -> {
                if (event.itemId == null) {
                    addLog("🎒 도구를 해제했습니다.")
                } else {
                    addLog("🎒 [${event.itemName}]을(를) 지니게 했습니다.")
                }
            }
            is BattleEvent.MegaEvolution -> {
                val mon = battleEngine?.gameState?.team?.firstOrNull { it.slot == event.slot }
                val name = mon?.let { pokemonRepository.getPokemon(it.id)?.ko } ?: "포켓몬"
                val durationText = if (event.formName in setOf("황혼의 갈기", "새벽의 날개")) "영구 융합" else "30초"
                addLog("✨ ${name}이(가) ${event.formName}(으)로 변신했다! ($durationText)")
            }
            is BattleEvent.MegaRevert -> {
                val mon = battleEngine?.gameState?.team?.firstOrNull { it.slot == event.slot }
                val name = mon?.let { pokemonRepository.getPokemon(it.id)?.ko } ?: "포켓몬"
                addLog("⏱ ${name}의 변신이 끝났다.")
            }
            else -> {}
        }
    }

    private fun triggerEnemyHit() {
        _uiState.value = _uiState.value.copy(
            enemyHitTrigger = _uiState.value.enemyHitTrigger + 1
        )
    }

    private fun triggerSlotLevelUp(slot: Int) {
        _uiState.value = _uiState.value.copy(
            levelingUpSlots = _uiState.value.levelingUpSlots + slot
        )
        val eff = FloatingEffect(
            id = ++effectCounter,
            text = "✨ LEVEL UP!",
            isSuperEffective = true,
            fromSlot = slot
        )
        addFloatingEffect(eff)
        viewModelScope.launch {
            delay(500)
            _uiState.value = _uiState.value.copy(
                levelingUpSlots = _uiState.value.levelingUpSlots - slot
            )
        }
    }

    private fun addFloatingEffect(eff: FloatingEffect) {
        val current = _uiState.value.floatingEffects.takeLast(5) + eff
        _uiState.value = _uiState.value.copy(floatingEffects = current)
        viewModelScope.launch {
            delay(800)
            _uiState.value = _uiState.value.copy(
                floatingEffects = _uiState.value.floatingEffects.filter { it.id != eff.id }
            )
        }
    }

    private fun addAttackSlashEffect(eff: AttackSlashEffect) {
        val current = _uiState.value.attackEffects.takeLast(6) + eff
        _uiState.value = _uiState.value.copy(attackEffects = current)
        viewModelScope.launch {
            delay(350)
            _uiState.value = _uiState.value.copy(
                attackEffects = _uiState.value.attackEffects.filter { it.id != eff.id }
            )
        }
    }

    private fun addLog(text: String) {
        logs.add(text)
        if (logs.size > 100) logs.removeAt(0)
    }

    fun syncGameState() {
        val engine = battleEngine ?: return
        val s = engine.gameState
        (s.team + s.box).filter { it.id in setOf(1026, 1027) }.forEach { it.isShiny = false }
        s.shinySeen.remove(1026)
        s.shinySeen.remove(1027)
        if ((1..1025).all { (s.caught[it] ?: 0) > 0 } && (s.caught[1026] ?: 0) == 0) {
            val hidden = pokemonRepository.getPokemon(1026)
            if (hidden != null) {
                if ((s.team + s.box).none { it.id == 1026 }) {
                    s.box.add(com.pokeidle.app.domain.model.AllyMon(id = 1026, lvl = 100, slot = -1, joined = ++s.seq, move = pokemonRepository.randomMove(hidden), ab = pokemonRepository.rollAbility(hidden)))
                }
                s.caught[1026] = 1
                s.seen[1026] = 1
                addLog("🏆 1025종 수집 완료! 다크 루기아 Lv.100이 박스에 합류했습니다.")
                triggerManualSave()
            }
        }
        (s.team + s.box).filter { it.isShiny && it.id !in setOf(1026, 1027) }.forEach { s.shinySeen[-it.id] = 1 }
        if (com.pokeidle.app.data.model.AchievementData.masterComplete(s) && (s.caught[1027] ?: 0) == 0) {
            pokemonRepository.getPokemon(1027)?.let { p ->
                if ((s.team + s.box).none { it.id == 1027 }) s.box.add(AllyMon(id = 1027, lvl = 100, slot = -1, joined = ++s.seq, move = pokemonRepository.randomMove(p), ab = pokemonRepository.rollAbility(p)))
                s.caught[1027] = 1
                s.seen[1027] = 1
                addLog("🏆 포켓몬 마스터 달성! 화이트 레쿠자 Lv.100이 박스에 합류했습니다.")
                triggerManualSave()
            }
        }
        _uiState.value = _uiState.value.copy(
            stateVersion = ++stateVersionCounter,
            gameState = s.copy(
                team = s.team.map { it.copy(status = it.status.copy()) }.toMutableList(),
                box = synchronized(s.box) { s.box.toList() }.map { it.copy(status = it.status.copy()) }.toMutableList(),
                tokens = s.tokens.toMutableMap(),
                seen = s.seen.toMutableMap(),
                caught = s.caught.toMutableMap(),
                shinySeen = s.shinySeen.toMutableMap(),
                enemy = s.enemy?.copy()
            )
        )
    }

    // --- 유저 인터랙션 메소드 ---

    fun selectStarter(starterId: Int) {
        val engine = battleEngine ?: return
        val starterPokemon = pokemonRepository.getPokemon(starterId) ?: return

        engine.gameState.team.clear()
        engine.gameState.team.add(
            AllyMon(
                id = starterId,
                lvl = 1,
                cd = 1.0,
                move = pokemonRepository.randomMove(starterPokemon),
                ab = pokemonRepository.rollAbility(starterPokemon),
                slot = 0,
                joined = 1L
            )
        )
        engine.gameState.caught[starterId] = 1
        engine.gameState.seen[starterId] = 1

        _uiState.value = _uiState.value.copy(showStarterDialog = false)
        viewModelScope.launch(Dispatchers.IO) {
            saveRepository.saveGame(engine.gameState)
        }
    }

    fun levelUpAlly(ally: AllyMon, times: Int = 1) {
        val engine = battleEngine ?: return
        engine.levelUp(ally, times)
        syncGameState()
    }

    fun rerollMove(ally: AllyMon) {
        val engine = battleEngine ?: return
        if (engine.rerollMove(ally)) {
            syncGameState()
        }
    }

    fun rerollAbility(ally: AllyMon) {
        val engine = battleEngine ?: return
        if (engine.rerollAbility(ally)) {
            syncGameState()
        }
    }

    fun upgradeTokenSpeed(ally: AllyMon) {
        val engine = battleEngine ?: return
        if (engine.upgradeTokenSpeed(ally)) {
            syncGameState()
        }
    }

    fun formatAlly(ally: AllyMon) {
        val engine = battleEngine ?: return
        if (engine.formatMon(ally)) {
            syncGameState()
        }
    }

    fun releaseBoxMon(ally: AllyMon) {
        val engine = battleEngine ?: return
        if (engine.releaseBoxMon(ally)) {
            syncGameState()
        }
    }

    fun makeAllyShiny(selected: AllyMon) {
        val engine = battleEngine ?: return
        val state = engine.gameState
        val ally = (state.team + state.box).firstOrNull { it.joined == selected.joined && it.id == selected.id && it.slot == selected.slot } ?: return
        if (ally.id in setOf(1026, 1027) || ally.isShiny || state.mballs < 50) return
        state.mballs -= 50
        ally.isShiny = true
        state.shinySeen[ally.id] = (state.shinySeen[ally.id] ?: 0).coerceAtLeast(1)
        state.shinySeen[-ally.id] = 1
        syncGameState()
        triggerManualSave()
    }

    fun buyAllyRebirth(selected: com.pokeidle.app.domain.model.AllyMon) {
        val engine = battleEngine ?: return
        val ally = (engine.gameState.team + engine.gameState.box).firstOrNull { it.joined == selected.joined && it.id == selected.id && it.slot == selected.slot } ?: return
        val cost = BattleMath.rbCostL(ally.rb)
        if (engine.gameState.rpL < cost) return
        engine.gameState.rpL = BattleMath.logSub(engine.gameState.rpL, cost)
        ally.rb++
        syncGameState()
        triggerManualSave()
    }
    fun relieveAlly(ally: AllyMon) {
        val engine = battleEngine ?: return
        val didRelieve = com.pokeidle.app.domain.system.StatusSystem.relieve(
            engine.gameState.team.firstOrNull { it.slot == ally.slot } ?: return, engine.gameState.team, pokemonRepository
        )
        if (didRelieve) {
            addLog("${pokemonRepository.getPokemon(ally.id)?.ko ?: "동료"}의 회복을 도왔다!")
            syncGameState()
        }
    }

    fun evolveAlly(ally: AllyMon, toId: Int) {
        val engine = battleEngine ?: return
        if (engine.evolve(ally, toId)) {
            syncGameState()
            triggerManualSave()
        }
    }

    fun megaEvolveAlly(ally: AllyMon) {
        battleEngine?.megaEvolve(ally)
        syncGameState()
    }

    fun equipItem(ally: AllyMon, itemId: String?): Boolean {
        val engine = battleEngine ?: return false
        val success = engine.equipItem(ally, itemId)
        if (success) {
            syncGameState()
            triggerManualSave()
        }
        return success
    }

    fun changeRegion(regionId: Int) {
        val engine = battleEngine ?: return
        engine.gameState.region = regionId
        engine.spawnEnemy()
        addLog("🗺 모험 지역을 [${getRegionName(regionId)}]으로 변경했다.")
        syncGameState()
    }

    fun swapTeamAndBox(teamSlot: Int, boxMon: AllyMon) {
        val engine = battleEngine ?: return
        engine.swapTeamAndBox(teamSlot, boxMon)
        syncGameState()
    }

    private fun triggerSlotLunge(slot: Int) {
        _uiState.value = _uiState.value.copy(
            attackingSlots = _uiState.value.attackingSlots + slot
        )
        viewModelScope.launch {
            delay(140)
            _uiState.value = _uiState.value.copy(
                attackingSlots = _uiState.value.attackingSlots - slot
            )
        }
    }

    fun selectSlot(slot: Int) {
        _uiState.value = _uiState.value.copy(selectedSlot = slot.coerceIn(0, 5))
    }

    fun tapEnemy() {
        battleEngine?.tapAttack()
    }

    fun getRegionName(gen: Int): String {
        return when (gen) {
            1 -> "관동"
            2 -> "성도"
            3 -> "호연"
            4 -> "신오"
            5 -> "하나"
            6 -> "칼로스"
            7 -> "알로라"
            8 -> "가라르"
            9 -> "팔데아"
            else -> "미지의 땅"
        }
    }

    // --- 🛠️ 개발 및 테스트용 디버깅 메소드 ---

    fun debugAddExp(amount: Double) {
        val engine = battleEngine ?: return
        engine.gameState.exp += amount
        addLog("🛠 [디버그] 경험치 +${String.format("%.0f", amount)} 지급")
        syncGameState()
    }

    fun debugAddRp(amountL: Double) {
        val engine = battleEngine ?: return
        engine.gameState.rpL = if (engine.gameState.rpL <= -299.0) amountL else com.pokeidle.app.domain.math.BattleMath.logAdd(engine.gameState.rpL, amountL)
        addLog("🛠 [디버그] 환생 포인트 +${com.pokeidle.app.domain.math.BattleMath.fmtL(amountL)}P 지급 (총 ${com.pokeidle.app.domain.math.BattleMath.fmtL(engine.gameState.rpL)}P)")
        syncGameState()
    }

    fun debugResetRp() {
        val engine = battleEngine ?: return
        engine.gameState.rpL = -300.0
        addLog("🛠 [디버그] 환생 포인트 0P로 초기화")
        syncGameState()
    }

    fun debugAddBalls(p: Int, u: Int, m: Int) {
        val engine = battleEngine ?: return
        engine.gameState.pballs += p
        engine.gameState.balls += u
        engine.gameState.mballs += m
        addLog("🛠 [디버그] 볼 지급: 몬스터볼 +$p, 수퍼/하이퍼볼 +$u, 마스터볼 +$m")
        syncGameState()
    }

    fun debugAddTokensToParty(count: Int) {
        val engine = battleEngine ?: return
        for (ally in engine.gameState.team) {
            val p = pokemonRepository.getPokemon(ally.id)
            val chainId = p?.chain ?: ally.id
            engine.gameState.tokens[chainId] = (engine.gameState.tokens[chainId] ?: 0) + count
        }
        addLog("🛠 [디버그] 파티 전원 증표 +${count}개 지급")
        syncGameState()
    }

    fun debugSetAllyLevel(slot: Int, newLevel: Int) {
        val engine = battleEngine ?: return
        val ally = engine.gameState.team.find { it.slot == slot } ?: return
        ally.lvl = newLevel.coerceAtLeast(1)
        val p = pokemonRepository.getPokemon(ally.id)
        addLog("🛠 [디버그] [${p?.ko ?: "슬롯 ${slot + 1}"}]의 레벨을 Lv.${ally.lvl}(으)로 변경")
        syncGameState()
    }

    fun debugAddAllyTb(slot: Int, delta: Int) {
        val engine = battleEngine ?: return
        val ally = engine.gameState.team.find { it.slot == slot } ?: return
        ally.tb = (ally.tb + delta).coerceAtLeast(0)
        val p = pokemonRepository.getPokemon(ally.id)
        addLog("🛠 [디버그] [${p?.ko ?: "슬롯 ${slot + 1}"}] 증표강화 ◆${ally.tb} (변동: $delta)")
        syncGameState()
    }

    fun debugAddAllyRb(slot: Int, delta: Int) {
        val engine = battleEngine ?: return
        val ally = engine.gameState.team.find { it.slot == slot } ?: return
        ally.rb = (ally.rb + delta).coerceAtLeast(0)
        val p = pokemonRepository.getPokemon(ally.id)
        addLog("🛠 [디버그] [${p?.ko ?: "슬롯 ${slot + 1}"}] 환생강화 ★${ally.rb} (변동: $delta)")
        syncGameState()
    }

    fun debugFillMegaGauge(slot: Int) {
        val engine = battleEngine ?: return
        val ally = engine.gameState.team.find { it.slot == slot } ?: return
        ally.mg = 100.0
        val p = pokemonRepository.getPokemon(ally.id)
        addLog("🛠 [디버그] [${p?.ko ?: "슬롯 ${slot + 1}"}] 메가 게이지 100% 충전")
        syncGameState()
    }

    fun debugHealStatus(slot: Int) {
        val engine = battleEngine ?: return
        val ally = engine.gameState.team.find { it.slot == slot } ?: return
        ally.status = com.pokeidle.app.domain.model.AllyStatus()
        val p = pokemonRepository.getPokemon(ally.id)
        addLog("🛠 [디버그] [${p?.ko ?: "슬롯 ${slot + 1}"}] 상태이상 완전 치료")
        syncGameState()
    }

    fun debugSetSlotPokemon(slot: Int, pokemonId: Int, isShiny: Boolean = false) {
        val engine = battleEngine ?: return
        val p = pokemonRepository.getPokemon(pokemonId) ?: return
        val existing = engine.gameState.team.find { it.slot == slot }
        if (existing != null) {
            existing.id = pokemonId
            existing.isShiny = isShiny && pokemonId !in setOf(1026, 1027)
            existing.move = pokemonRepository.randomMove(p)
            existing.ab = pokemonRepository.rollAbility(p)
            existing.isMega = false
            existing.megaFormId = null
            existing.ultraRevertFormId = null
            existing.mg = 0.0
        } else {
            val newMon = AllyMon(
                id = pokemonId,
                lvl = 100,
                cd = 1.0,
                move = pokemonRepository.randomMove(p),
                ab = pokemonRepository.rollAbility(p),
                slot = slot,
                joined = ++engine.gameState.seq,
                isShiny = isShiny && pokemonId !in setOf(1026, 1027)
            )
            engine.gameState.team.add(newMon)
        }
        engine.gameState.seen[pokemonId] = (engine.gameState.seen[pokemonId] ?: 0) + 1
        engine.gameState.caught[pokemonId] = (engine.gameState.caught[pokemonId] ?: 0) + 1
        if (isShiny) {
            engine.gameState.shinySeen[pokemonId] = (engine.gameState.shinySeen[pokemonId] ?: 0) + 1
        }
        addLog("🛠 [디버그] 슬롯 ${slot + 1}번에 [${if (isShiny) "✨이로치 " else ""}${p.ko}] 장착")
        syncGameState()
    }

    fun debugAddPokemonToBox(pokemonId: Int, level: Int = 100, isShiny: Boolean = false) {
        val engine = battleEngine ?: return
        val p = pokemonRepository.getPokemon(pokemonId) ?: return
        val newMon = AllyMon(
            id = pokemonId,
            lvl = level,
            cd = 1.0,
            move = pokemonRepository.randomMove(p),
            ab = pokemonRepository.rollAbility(p),
            slot = -1,
            joined = ++engine.gameState.seq,
            isShiny = isShiny && pokemonId !in setOf(1026, 1027)
        )
        engine.gameState.box.add(newMon)
        engine.gameState.seen[pokemonId] = (engine.gameState.seen[pokemonId] ?: 0) + 1
        engine.gameState.caught[pokemonId] = (engine.gameState.caught[pokemonId] ?: 0) + 1
        if (isShiny) {
            engine.gameState.shinySeen[pokemonId] = (engine.gameState.shinySeen[pokemonId] ?: 0) + 1
        }
        addLog("🛠 [디버그] 박스에 [${if (isShiny) "✨이로치 " else ""}${p.ko} Lv.$level] 추가")
        syncGameState()
    }

    fun debugSpawnEnemy(pokemonId: Int, isShiny: Boolean = false) {
        val engine = battleEngine ?: return
        engine.spawnEnemy(forceId = pokemonId, forceShiny = isShiny)
        addLog("🛠 [디버그] 야생 [${if (isShiny) "✨이로치 " else ""}${pokemonRepository.getPokemon(pokemonId)?.ko ?: ""}] 소환")
        syncGameState()
    }

    fun debugKillEnemy() {
        val engine = battleEngine ?: return
        addLog("🛠 [디버그] 현재 적 즉시 처치")
        engine.defeat()
        syncGameState()
    }

    fun debugAddKills(count: Long) {
        val engine = battleEngine ?: return
        engine.gameState.kills += count
        addLog("🛠 [디버그] 킬 수 +${count} 추가 (총 ${engine.gameState.kills}마리)")
        syncGameState()
    }

    fun debugUnlockAllPokedex() {
        val engine = battleEngine ?: return
        val all = pokemonRepository.getAllPokemon().filter { it.id in 1..1025 }
        for (p in all) {
            engine.gameState.seen[p.id] = (engine.gameState.seen[p.id] ?: 0).coerceAtLeast(1)
            engine.gameState.caught[p.id] = (engine.gameState.caught[p.id] ?: 0).coerceAtLeast(1)
            engine.gameState.shinySeen[-p.id] = 1
            engine.gameState.shinySeen[p.id] = (engine.gameState.shinySeen[p.id] ?: 0).coerceAtLeast(1)
        }
        addLog("🛠 [디버그] 일반/이로치 도감(1~1025) 등록 완료")
        syncGameState()
        triggerManualSave()
    }

    fun debugSetWeather(weatherName: String?) {
        val engine = battleEngine ?: return
        if (weatherName == null) {
            engine.forcedWeather = null
            addLog("🛠 [디버그] 날씨 고정 해제")
        } else {
            val w = com.pokeidle.app.domain.system.WeatherType.entries.find { it.name.equals(weatherName, true) || it.ko == weatherName }
            if (w != null) {
                val dummy = engine.gameState.team.firstOrNull() ?: AllyMon(25)
                engine.forcedWeather = ActiveWeather(weather = w, setter = dummy)
                addLog("🛠 [디버그] 날씨를 [${w.ko}]로 강제 설정")
            }
        }
        syncGameState()
    }

    fun debugSetTerrain(terrainName: String?) {
        val engine = battleEngine ?: return
        if (terrainName == null) {
            engine.forcedTerrain = null
            addLog("🛠 [디버그] 필드 고정 해제")
        } else {
            val t = com.pokeidle.app.domain.system.TerrainType.entries.find { it.name.equals(terrainName, true) || it.ko == terrainName }
            if (t != null) {
                val dummy = engine.gameState.team.firstOrNull() ?: AllyMon(25)
                engine.forcedTerrain = ActiveTerrain(terrain = t, setter = dummy)
                addLog("🛠 [디버그] 필드를 [${t.ko}]로 강제 설정")
            }
        }
        syncGameState()
    }

    fun debugResetAllSave() {
        viewModelScope.launch(Dispatchers.IO) {
            val initial = GameState.createInitial(25)
            saveRepository.saveGame(initial)
            val engine = BattleEngine(initial, pokemonRepository)
            engine.addEventListener { event -> handleBattleEvent(event) }
            battleEngine = engine
            _uiState.value = _uiState.value.copy(
                stateVersion = ++stateVersionCounter,
                gameState = initial,
                enemyPokemon = pokemonRepository.getPokemon(initial.enemy?.id ?: 16)
            )
            addLog("🛠 [디버그] 세이브 데이터를 완전히 초기화했습니다.")
        }
    }

    fun debugAddItem(itemId: String, count: Int = 1) {
        val engine = battleEngine ?: return
        val current = engine.gameState.items[itemId] ?: 0
        engine.gameState.items[itemId] = current + count
        val item = pokemonRepository.getHeldItem(itemId)
        addLog("🛠 [디버그] 도구 [${item?.ko ?: itemId}] +${count}개 추가 (총 ${engine.gameState.items[itemId]}개)")
        syncGameState()
        triggerManualSave()
    }

    fun debugAddAllHeldItems(count: Int = 999) {
        val engine = battleEngine ?: return
        val items = pokemonRepository.getAllHeldItems()
        if (items.isEmpty()) return

        items.forEach { item ->
            engine.gameState.items[item.id] = (engine.gameState.items[item.id] ?: 0) + count
        }
        addLog("🛠 [디버그] 등록된 지닌 도구 ${items.size}종 각각 +${count}개 지급")
        syncGameState()
        triggerManualSave()
    }
}
