package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.pokeidle.app.R
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.presentation.components.PokemonSprite
import com.pokeidle.app.presentation.components.TypeBadge

/**
 * 포켓몬 도감 (POKÉDEX) 모달 다이얼로그
 * - 상단 툴팁 바의 디버그 버튼 바로 아래 도감 버튼 클릭 시 노출
 * - 1,025종 포켓몬 도감 확인, 소유 현황(포획/만남/미발견 및 현재 파티/박스 보유 마리 수)
 * - 선택된 포켓몬의 상세 정보 및 배울 수 있는 기술 목록(타입, 위력, 분류, 설명) 참고
 */
@Composable
fun PokedexDialog(
    gameState: GameState,
    repository: PokemonRepository,
    onDismiss: () -> Unit
) {
    val allPokemon = remember { repository.getAllPokemon() }
    var selectedPokemonId by remember { mutableIntStateOf(gameState.team.firstOrNull()?.id ?: 1) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedGen by remember { mutableIntStateOf(0) } // 0: 전체, 1~9: 해당 세대
    var statusFilter by remember { mutableIntStateOf(0) } // 0: 전체, 1: 소유(포획), 2: 미소유
    var showDetailDialog by remember { mutableStateOf(false) }

    val caughtCount = remember(gameState.caught.size) {
        allPokemon.count { (gameState.caught[it.id] ?: 0) > 0 }
    }
    val seenCount = remember(gameState.seen.size) {
        allPokemon.count { (gameState.seen[it.id] ?: 0) > 0 }
    }

    // 필터링된 포켓몬 목록
    val filteredPokemon = remember(allPokemon, searchQuery, selectedGen, statusFilter, gameState.caught, gameState.seen) {
        allPokemon.filter { mon ->
            val matchGen = selectedGen == 0 || mon.gen == selectedGen
            val isCaught = (gameState.caught[mon.id] ?: 0) > 0
            val isSeen = (gameState.seen[mon.id] ?: 0) > 0
            val matchStatus = when (statusFilter) {
                1 -> isCaught
                2 -> !isCaught
                else -> true
            }
            val q = searchQuery.trim().lowercase()
            val matchQuery = if (q.isBlank()) true else {
                mon.ko.lowercase().contains(q) ||
                mon.en.lowercase().contains(q) ||
                mon.id.toString() == q
            }
            (mon.id <= 1025 || isCaught) && matchGen && matchStatus && matchQuery
        }
    }

    val selectedPokemon = remember(selectedPokemonId) {
        repository.getPokemon(selectedPokemonId) ?: allPokemon.firstOrNull()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(16.dp)),
            color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 1. 도감 상단 헤더 (빨간색 포켓몬 도감 스타일)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFD93A2F))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.pokedex),
                            contentDescription = "도감",
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "포켓몬 도감 (POKÉDEX)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = "소유 ${caughtCount} · 만남 ${seenCount} · 전체 ${allPokemon.size} (보너스 데미지 +${caughtCount}%)",
                                fontSize = 10.sp,
                                color = Color(0xFFFFD7D4)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "닫기",
                            tint = Color.White
                        )
                    }
                }

                // 2. 검색창 및 세대 / 상태 필터
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(androidx.compose.material3.MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 검색 입력 필드
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "검색",
                                tint = Color(0xFF5A665E),
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "지우기", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        placeholder = {
                            Text("포켓몬 이름 또는 도감 번호 검색...", fontSize = 12.sp, color = Color.Gray)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black,
                            cursorColor = Color.Black,
                            focusedBorderColor = Color(0xFFD93A2F),
                            unfocusedBorderColor = Color(0xFFD3DCD0),
                            focusedContainerColor = Color(0xFFF9FAF7),
                            unfocusedContainerColor = Color(0xFFF9FAF7)
                        )
                    )

                    // 세대 및 소유 상태 칩 행
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 세대 필터 칩 (전체, 1~9세대 스크롤 대신 드롭다운 버튼)
                        var showGenDropdown by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(
                                onClick = { showGenDropdown = true },
                                modifier = Modifier.height(28.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = if (selectedGen == 0) "세대: 전체" else "세대: ${selectedGen}세대",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                )
                            }
                            DropdownMenu(
                                expanded = showGenDropdown,
                                onDismissRequest = { showGenDropdown = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("전체 세대 (1~9세대)") },
                                    onClick = { selectedGen = 0; showGenDropdown = false }
                                )
                                for (gen in 1..9) {
                                    DropdownMenuItem(
                                        text = { Text("${gen}세대") },
                                        onClick = { selectedGen = gen; showGenDropdown = false }
                                    )
                                }
                            }
                        }

                        // 소유 상태 필터 버튼군 (전체 / 소유 / 미소유)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(0 to "전체", 1 to "소유(잡음)", 2 to "미소유").forEach { (type, label) ->
                                val isSel = statusFilter == type
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .clickable { statusFilter = type },
                                    color = if (isSel) Color(0xFF2F7BD9) else Color(0xFFE8ECE5),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) Color.White else Color(0xFF4A5568),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFFD3DCD0), thickness = 1.dp)

                // 3. 본문: 좌측/상단 도감 그리드 + 우측/하단 선택 포켓몬 상세 정보
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(8.dp)
                ) {
                    val isWide = maxWidth >= 500.dp

                    if (isWide) {
                        // 가로 분할: 좌측 도감 그리드 + 우측 상세 및 배울 수 있는 기술
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1.1f)
                                    .fillMaxHeight()
                            ) {
                                PokedexGridList(
                                    pokemonList = filteredPokemon,
                                    selectedId = selectedPokemonId,
                                    gameState = gameState,
                                    onSelectPokemon = { selectedPokemonId = it }
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(0.9f)
                                    .fillMaxHeight()
                            ) {
                                if (selectedPokemon != null) {
                                    PokemonDetailView(
                                        pokemon = selectedPokemon,
                                        gameState = gameState,
                                        repository = repository
                                    )
                                }
                            }
                        }
                    } else {
                        // 스마트폰 세로 모드: 상단 도감 그리드 + 하단 선택 요약 및 상세 보기 버튼
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                            ) {
                                PokedexGridList(
                                    pokemonList = filteredPokemon,
                                    selectedId = selectedPokemonId,
                                    gameState = gameState,
                                    onSelectPokemon = {
                                        selectedPokemonId = it
                                        showDetailDialog = true
                                    }
                                )
                            }

                            // 하단 선택된 포켓몬 퀵 바
                            if (selectedPokemon != null) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { showDetailDialog = true },
                                    color = Color.White,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD3DCD0)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            PokemonSprite(imgBase64 = selectedPokemon.img, contentDescription = selectedPokemon.ko, size = 36.dp)
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text(
                                                        text = "No.${selectedPokemon.id.toString().padStart(4, '0')}",
                                                        fontSize = 10.sp,
                                                        color = Color(0xFF2F7BD9),
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = selectedPokemon.ko,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                                val isCaught = (gameState.caught[selectedPokemon.id] ?: 0) > 0
                                                val currentOwnedCount = gameState.team.count { it.id == selectedPokemon.id } + gameState.box.count { it.id == selectedPokemon.id }
                                                Text(
                                                    text = if (currentOwnedCount > 0) "현재 ${currentOwnedCount}마리 보유 중 (기술 ${selectedPokemon.moves.size}개)"
                                                           else if (isCaught) "도감 등록됨 (포획 이력 있음)"
                                                           else "미소유 포켓몬",
                                                    fontSize = 10.sp,
                                                    color = if (currentOwnedCount > 0) Color(0xFF2E7D32) else Color(0xFF718096)
                                                )
                                            }
                                        }

                                        Button(
                                            onClick = { showDetailDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("기술/상세", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 모바일 전용 상세 모달
    if (showDetailDialog && selectedPokemon != null) {
        Dialog(
            onDismissRequest = { showDetailDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.85f)
                    .clip(RoundedCornerShape(14.dp)),
                color = Color.White,
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF2F7BD9))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "[No.${selectedPokemon.id.toString().padStart(4, '0')}] ${selectedPokemon.ko} 상세 정보",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        IconButton(onClick = { showDetailDialog = false }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "닫기", tint = Color.White)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(10.dp)
                    ) {
                        PokemonDetailView(
                            pokemon = selectedPokemon,
                            gameState = gameState,
                            repository = repository
                        )
                    }
                }
            }
        }
    }
}

/**
 * 도감 그리드 목록 뷰
 */
@Composable
private fun PokedexGridList(
    pokemonList: List<PokemonDto>,
    selectedId: Int,
    gameState: GameState,
    onSelectPokemon: (Int) -> Unit
) {
    if (pokemonList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("해당 조건의 포켓몬이 없습니다.", color = Color.Gray, fontSize = 12.sp)
        }
        return
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 72.dp),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(pokemonList, key = { it.id }) { mon ->
            val isCaught = (gameState.caught[mon.id] ?: 0) > 0
            val isSeen = (gameState.seen[mon.id] ?: 0) > 0
            val isSelected = selectedId == mon.id
            val inTeamCount = gameState.team.count { it.id == mon.id }
            val inBoxCount = gameState.box.count { it.id == mon.id }
            val isOwnedNow = (inTeamCount + inBoxCount) > 0

            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelectPokemon(mon.id) },
                color = when {
                    isSelected -> Color(0xFFE3F2FD)
                    isOwnedNow -> Color.White
                    isCaught -> Color(0xFFF0F7ED)
                    isSeen -> Color(0xFFFFF9ED)
                    else -> Color(0xFFEBEBEB)
                },
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = when {
                        isSelected -> Color(0xFF2F7BD9)
                        isOwnedNow -> Color(0xFF3CAE5C)
                        isCaught -> Color(0xFF81C784)
                        isSeen -> Color(0xFFFFB74D)
                        else -> Color(0xFFD3DCD0)
                    }
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // 번호 및 소유 상태 뱃지
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#${mon.id}",
                            fontSize = 8.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (isOwnedNow) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFF3CAE5C))
                                    .padding(horizontal = 2.dp, vertical = 0.5.dp)
                            ) {
                                Text("보유", fontSize = 7.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        } else if (isCaught) {
                            Text("✔", fontSize = 7.sp, color = Color(0xFF3CAE5C), fontWeight = FontWeight.Bold)
                        }
                    }

                    // 스프라이트 (미발견 시 실루엣/물음표)
                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        if (isSeen || isCaught) {
                            PokemonSprite(imgBase64 = mon.img, contentDescription = mon.ko, size = 36.dp)
                        } else {
                            Text("?", fontSize = 20.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }

                    // 이름
                    Text(
                        text = if (isSeen || isCaught) mon.ko else "???",
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSeen || isCaught) androidx.compose.material3.MaterialTheme.colorScheme.onSurface else Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * 선택된 포켓몬 상세 정보 및 배울 수 있는 기술 목록 뷰
 */
@Composable
private fun PokemonDetailView(
    pokemon: PokemonDto,
    gameState: GameState,
    repository: PokemonRepository
) {
    val forms = remember(pokemon.id) { repository.getAllFormViews(pokemon.id) }
    var selectedFormIdx by remember(pokemon.id) { mutableIntStateOf(0) }
    var showShiny by remember(pokemon.id) { mutableStateOf(false) }
    val currentForm = forms.getOrNull(selectedFormIdx) ?: forms.first()
    var expandedMoveId by remember(pokemon.id, currentForm.formKey) { mutableIntStateOf(-1) }
    val formSpriteId = when (currentForm.formKey) {
        "necrozma_dusk_mane" -> 10155
        "necrozma_dawn_wings" -> 10156
        else -> currentForm.formKey.substringAfterLast('_').toIntOrNull() ?: pokemon.id
    }
    val shinySprite = repository.getShinySprite(formSpriteId)
        ?: repository.getShinySprite(pokemon.id)
    val isShinyRegistered = (gameState.shinySeen[pokemon.id] ?: 0) > 0

    val isCaught = (gameState.caught[pokemon.id] ?: 0) > 0
    val isSeen = (gameState.seen[pokemon.id] ?: 0) > 0
    val inTeam = gameState.team.filter { it.id == pokemon.id }
    val inBox = gameState.box.filter { it.id == pokemon.id }
    val totalOwnedCount = inTeam.size + inBox.size

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White, RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFFD3DCD0), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 0. 폼 선택 버튼 토글 (울트라 네크로즈마, 메가리자몽 X/Y, 리전폼 등 다양한 폼이 존재할 때)
        if (forms.size > 1) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFFD9E2D6), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "🔄 모습 / 폼 선택 (${forms.size}가지 폼)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        forms.forEachIndexed { idx, f ->
                            val isSel = selectedFormIdx == idx
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { selectedFormIdx = idx },
                                color = if (isSel) Color(0xFFD93A2F) else Color(0xFFE8ECE5),
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = 1.dp,
                                    color = if (isSel) Color(0xFFB71C1C) else Color(0xFFD3DCD0)
                                )
                            ) {
                                Text(
                                    text = f.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSel) Color.White else androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("스프라이트", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface)
                FilterChip(
                    selected = !showShiny,
                    onClick = { showShiny = false },
                    label = { Text("일반", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = showShiny,
                    onClick = { showShiny = true },
                    enabled = pokemon.id !in setOf(1026, 1027) && (shinySprite != null || currentForm.shinySpriteAssetName != null),
                    label = { Text("✨ 이로치", fontSize = 10.sp) }
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = if (pokemon.id in setOf(1026, 1027)) "이로치 없음" else if (isShinyRegistered) "이로치 등록됨" else "이로치 미등록",
                    fontSize = 9.sp,
                    color = if (isShinyRegistered) Color(0xFF8E5BD1) else Color.Gray
                )
            }
        }

        // 1. 헤더: 번호, 현재 폼 이름, 스프라이트, 현재 폼 타입
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PokemonSprite(
                        imgBase64 = if (showShiny) shinySprite ?: currentForm.img else currentForm.img,
                        contentDescription = if (showShiny) "${currentForm.fullName} 이로치" else currentForm.fullName,
                        size = 52.dp,
                        spriteAssetName = when {
                            showShiny -> currentForm.shinySpriteAssetName
                                ?: when (currentForm.formKey) {
                                    "necrozma_dusk_mane" -> "shiny_pokemon/10155.png"
                                    "necrozma_dawn_wings" -> "shiny_pokemon/10156.png"
                                    else -> null
                                }
                            else -> currentForm.spriteAssetName
                        }
                    )
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "No.${pokemon.id.toString().padStart(4, '0')}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF2F7BD9)
                            )
                            Text(
                                text = currentForm.fullName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                            )
                            if (pokemon.en.isNotEmpty() && currentForm.formKey.startsWith("base")) {
                                Text(
                                    text = "(${pokemon.en})",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                        // 분류 및 타입 배지
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            if (pokemon.genus.isNotEmpty()) {
                                Text(pokemon.genus, fontSize = 10.sp, color = Color(0xFF5A665E))
                            }
                            currentForm.types.forEach { tId ->
                                TypeBadge(typeId = tId)
                            }
                            if (currentForm.pw > 0.0) {
                                Surface(
                                    color = Color(0xFFD93A2F).copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "위력 ${currentForm.pw}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD93A2F),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. 소유 포켓몬 상태 박스 (요구사항 3 충족)
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = if (totalOwnedCount > 0) Color(0xFFE8F5E9) else if (isCaught) Color(0xFFF1F8E9) else androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (totalOwnedCount > 0) Color(0xFF81C784) else Color(0xFFD3DCD0)
                )
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📊 소유 상태 현황",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (totalOwnedCount > 0) Color(0xFF2E7D32) else androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (totalOwnedCount > 0) Color(0xFF3CAE5C)
                                    else if (isCaught) Color(0xFF2F7BD9)
                                    else if (isSeen) Color(0xFFE08A1B)
                                    else Color.Gray
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = when {
                                    totalOwnedCount > 0 -> "현재 ${totalOwnedCount}마리 보유 중"
                                    isCaught -> "도감 등록됨 (포획 이력)"
                                    isSeen -> "발견함 (미포획)"
                                    else -> "미발견"
                                },
                                fontSize = 9.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (totalOwnedCount > 0) {
                        val teamSlots = inTeam.map { "파티 ${it.slot + 1}번 (Lv.${it.lvl})" }
                        val boxInfo = if (inBox.isNotEmpty()) "박스 ${inBox.size}마리 (최고 Lv.${inBox.maxOf { it.lvl }})" else null
                        val detailList = (teamSlots + listOfNotNull(boxInfo)).joinToString(" · ")
                        Text(
                            text = "• 보유 상세: $detailList",
                            fontSize = 10.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }
                    val caughtTimes = gameState.caught[pokemon.id] ?: 0
                    val seenTimes = gameState.seen[pokemon.id] ?: 0
                    Text(
                        text = "• 누적 통계: 조우 ${seenTimes}회, 포획 ${caughtTimes}회",
                        fontSize = 10.sp,
                        color = Color(0xFF5A665E)
                    )
                }
            }
        }

        // 3. 종족값 및 기본 스탯
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📈 종족값 (${currentForm.label})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    if (currentForm.pw > 0.0) {
                        Text(
                            text = "배틀 위력: ${currentForm.pw}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD93A2F)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(
                        "HP" to currentForm.hp,
                        "공격" to currentForm.atk,
                        "방어" to currentForm.def,
                        "특공" to currentForm.spa,
                        "특방" to currentForm.sdf,
                        "스피드" to currentForm.spd
                    ).forEach { (statName, valInt) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(statName, fontSize = 9.sp, color = Color.Gray)
                            Text("$valInt", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2F7BD9))
                        }
                    }
                }
            }
        }

        item {
            Text("🧬 특성", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface)
        }
        val abilityIds = pokemon.abil.flatten().distinct()
        if (abilityIds.isEmpty()) {
            item { Text("특성 데이터가 없습니다.", fontSize = 10.sp, color = Color.Gray) }
        } else {
            items(abilityIds) { abilityId ->
                val ability = repository.getAbility(abilityId)
                if (ability != null) {
                    Surface(color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(7.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(ability.ko, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF65439A))
                            if (ability.txt.isNotBlank()) Text(ability.txt, fontSize = 9.sp, color = Color(0xFF5A665E), lineHeight = 12.sp)
                        }
                    }
                }
            }
        }

        // 4. 배울 수 있는 기술 참고 목록 (타입, 위력, 분류, 설명)
        item {
            Text(
                text = "⚔ 배울 수 있는 기술 (${currentForm.moves.size}종)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (currentForm.moves.isEmpty()) {
            item {
                Text("배울 수 있는 기술 데이터가 없습니다.", fontSize = 10.sp, color = Color.Gray)
            }
        } else {
            items(currentForm.moves) { moveId ->
                val moveDto = repository.getMove(moveId)
                if (moveDto != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { expandedMoveId = if (expandedMoveId == moveId) -1 else moveId },
                        color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E7DF))
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    TypeBadge(typeId = moveDto.t)
                                    Text(
                                        text = moveDto.ko,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(
                                                when (moveDto.c) {
                                                    2 -> Color(0xFFE08A1B).copy(alpha = 0.2f)
                                                    3 -> Color(0xFF2F7BD9).copy(alpha = 0.2f)
                                                    else -> Color(0xFF718096).copy(alpha = 0.2f)
                                                }
                                            )
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = when (moveDto.c) {
                                                2 -> "물리"
                                                3 -> "특수"
                                                else -> "변화"
                                            },
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (moveDto.c) {
                                                2 -> Color(0xFFE08A1B)
                                                3 -> Color(0xFF2F7BD9)
                                                else -> Color(0xFF718096)
                                            }
                                        )
                                    }
                                }

                                Text(
                                    text = if (moveDto.p > 0) "위력 ${moveDto.p.toInt()}" else "위력 -",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD93A2F)
                                )
                            }

                            Text(
                                text = if (expandedMoveId == moveId) "설명 접기" else "탭하여 기술 설명 보기",
                                fontSize = 8.sp,
                                color = Color(0xFF78827B),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            if (expandedMoveId == moveId && !moveDto.txt.isNullOrBlank()) {
                                Text(
                                    text = moveDto.txt,
                                    fontSize = 9.sp,
                                    color = Color(0xFF5A665E),
                                    lineHeight = 12.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
