package com.pokeidle.app.data.model

import kotlinx.serialization.Serializable

/**
 * 포켓몬 장착 도구(Held Item) DTO
 */
@Serializable
data class HeldItemDto(
    val id: String,                     // 고유 식별자 (e.g. "charcoal", "choice-band", "firium-z--held")
    val pokeApiId: Int,                // PokéAPI 공식 도구 ID
    val ko: String,                    // 공식 한국어 명칭
    val kind: String,                  // 효과 유형 ("type", "phys", "spec", "scarf", "orb", "belt", "vest", "leftovers", "mega", "zcrystal", "held", ...)
    val type: Int? = null,             // 속성 타입 (1..18, 타입 강화 및 Z크리스탈용)
    val desc: String,                  // 도구 설명문
    val short: String,                 // 배지용 짧은 요약 문구
    val icon: String = "🎒",           // 대표 이모지/아이콘
    val category: String               // 카테고리 (type-enhancement, choice, mega-stones, z-crystals, held-items, etc.)
)

@Serializable
data class HeldItemsDataDto(
    val items: Map<String, HeldItemDto> = emptyMap()
)
