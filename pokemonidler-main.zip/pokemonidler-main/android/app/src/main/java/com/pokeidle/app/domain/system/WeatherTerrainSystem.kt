package com.pokeidle.app.domain.system

import com.pokeidle.app.domain.model.AllyMon

/**
 * 날씨(Weather) 정의 (7종)
 */
enum class WeatherType(
    val ko: String,
    val icon: String,
    val abilityId: Int,
    val desc: String,
    val multipliers: Map<Int, Double>
) {
    SUN("맑음", "☀", 70, "불꽃 기술 ×1.5, 물 기술 ×0.5", mapOf(10 to 1.5, 11 to 0.5)),
    HARD_SUN("강렬한 햇살", "🌞", 190, "불꽃 기술 ×2, 물 기술 ×0.1", mapOf(10 to 2.0, 11 to 0.1)),
    RAIN("비", "🌧", 2, "물 기술 ×1.5, 불꽃 기술 ×0.5", mapOf(11 to 1.5, 10 to 0.5)),
    HARD_RAIN("강한 비", "🌊", 189, "물 기술 ×2, 불꽃 기술 ×0.1", mapOf(11 to 2.0, 10 to 0.1)),
    SNOW("눈", "❄", 117, "얼음 기술 ×1.5", mapOf(15 to 1.5)),
    SAND("모래바람", "🌪", 45, "바위 기술 ×1.5, 땅·강철 기술 ×1.1", mapOf(6 to 1.5, 5 to 1.1, 9 to 1.1)),
    WIND("난기류", "🌀", 191, "비행 기술 ×1.3", mapOf(3 to 1.3));

    companion object {
        fun fromAbilityId(abId: Int): WeatherType? {
            return when (abId) {
                70 -> SUN
                190 -> HARD_SUN
                2 -> RAIN
                189 -> HARD_RAIN
                117 -> SNOW
                45, 245 -> SAND // 245: 모래뿜기
                191 -> WIND
                else -> null
            }
        }
    }
}

/**
 * 필드(Terrain) 정의 (4종)
 */
enum class TerrainType(
    val ko: String,
    val icon: String,
    val abilityId: Int,
    val desc: String,
    val multipliers: Map<Int, Double>,
    val blockedStatuses: Set<String>
) {
    GRASS("그래스필드", "🌿", 229, "풀 기술 ×1.3", mapOf(12 to 1.3), emptySet()),
    ELECTRIC("일렉트릭필드", "⚡", 226, "전기 기술 ×1.3, 동료가 잠들지 않음", mapOf(13 to 1.3), setOf("slp")),
    MISTY("미스트필드", "🌸", 228, "페어리 기술 ×1.3, 동료가 상태이상에 걸리지 않음", mapOf(18 to 1.3), setOf("par", "brn", "psn", "slp", "frz", "cnf")),
    PSYCHIC("사이코필드", "🔮", 227, "에스퍼 기술 ×1.3", mapOf(14 to 1.3), emptySet());

    companion object {
        fun fromAbilityId(abId: Int): TerrainType? {
            return when (abId) {
                229, 269 -> GRASS // 269: 넘치는씨
                226 -> ELECTRIC
                228 -> MISTY
                227 -> PSYCHIC
                else -> null
            }
        }
    }
}

data class ActiveWeather(
    val weather: WeatherType,
    val setter: AllyMon
)

data class ActiveTerrain(
    val terrain: TerrainType,
    val setter: AllyMon
)

object WeatherTerrainSystem {

    /**
     * 현재 활성화된 날씨 판정
     * - 날씨부정(Cloud Nine), 에어록(Air Lock), 제로포밍(Zero Forming)이 파티에 있으면 무효화
     * - 가장 나중에 합류한(joined 시퀀스가 가장 큰) 포켓몬의 특성이 우선 적용
     */
    fun resolveWeather(team: List<AllyMon>, abilityNameProvider: (AllyMon) -> String?): ActiveWeather? {
        // 날씨 무효화 특성 확인
        for (mon in team) {
            val name = abilityNameProvider(mon)
            if (name in setOf("날씨부정", "에어록", "제로포밍")) {
                return null
            }
        }

        var best: ActiveWeather? = null
        for (mon in team) {
            val name = abilityNameProvider(mon) ?: continue
            val w = when (name) {
                "가뭄" -> WeatherType.SUN
                "끝의대지" -> WeatherType.HARD_SUN
                "잔비" -> WeatherType.RAIN
                "시작의바다" -> WeatherType.HARD_RAIN
                "눈퍼뜨리기" -> WeatherType.SNOW
                "모래날림", "모래뿜기" -> WeatherType.SAND
                "델타스트림" -> WeatherType.WIND
                else -> null
            }
            if (w != null) {
                if (best == null || mon.joined > best.setter.joined) {
                    best = ActiveWeather(w, mon)
                }
            }
        }
        return best
    }

    /**
     * 현재 활성화된 필드 판정
     * - 제로포밍(Zero Forming)이 파티에 있으면 무효화
     * - 가장 나중에 합류한(joined 시퀀스가 가장 큰) 포켓몬의 특성이 우선 적용
     */
    fun resolveTerrain(team: List<AllyMon>, abilityNameProvider: (AllyMon) -> String?): ActiveTerrain? {
        for (mon in team) {
            val name = abilityNameProvider(mon)
            if (name == "제로포밍") {
                return null
            }
        }

        var best: ActiveTerrain? = null
        for (mon in team) {
            val name = abilityNameProvider(mon) ?: continue
            val t = when (name) {
                "그래스메이커", "넘치는씨" -> TerrainType.GRASS
                "일렉트릭메이커" -> TerrainType.ELECTRIC
                "미스트메이커" -> TerrainType.MISTY
                "사이코메이커" -> TerrainType.PSYCHIC
                else -> null
            }
            if (t != null) {
                if (best == null || mon.joined > best.setter.joined) {
                    best = ActiveTerrain(t, mon)
                }
            }
        }
        return best
    }

    /**
     * 기술 타입에 대한 날씨 데미지 배율
     */
    fun getWeatherMultiplier(moveType: Int, weather: WeatherType?): Double {
        if (weather == null) return 1.0
        return weather.multipliers[moveType] ?: 1.0
    }

    /**
     * 기술 타입에 대한 필드 데미지 배율
     */
    fun getTerrainMultiplier(moveType: Int, terrain: TerrainType?): Double {
        if (terrain == null) return 1.0
        return terrain.multipliers[moveType] ?: 1.0
    }

    /**
     * 필드가 특정 상태이상을 방어하는지 여부
     */
    fun isStatusBlocked(statusKey: String, terrain: TerrainType?): Boolean {
        if (terrain == null) return false
        return statusKey in terrain.blockedStatuses
    }
}
