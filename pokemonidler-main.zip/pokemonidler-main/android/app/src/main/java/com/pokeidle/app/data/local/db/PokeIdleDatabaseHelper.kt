package com.pokeidle.app.data.local.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.AllyStatus
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.domain.model.Quest
import com.pokeidle.app.domain.model.WildEnemy
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 포켓몬 아이들 배틀의 네이티브 SQLite 데이터베이스 헬퍼.
 * 기본 데이터베이스 파일명은 `.psv` 확장자를 가지는 `pokeidle.psv`이며,
 * WAL 모드 및 트랜잭션을 적용하여 높은 성능과 무결성을 보장합니다.
 */
class PokeIdleDatabaseHelper(
    private val context: Context,
    databaseName: String = DATABASE_NAME
) : SQLiteOpenHelper(context, databaseName, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "pokeidle.psv"
        const val DATABASE_VERSION = 3

        private val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        // WAL(Write-Ahead Logging) 활성화로 쓰기/읽기 동시성 최적화
        db.enableWriteAheadLogging()
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.beginTransaction()
        try {
            // 1. 게임 전역 메타데이터 및 진행도 (단일 행 id = 1)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS game_metadata (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    save_version INTEGER NOT NULL DEFAULT 1,
                    updated_at INTEGER NOT NULL,
                    k INTEGER NOT NULL DEFAULT 0,
                    exp REAL NOT NULL DEFAULT 0.0,
                    total_l REAL NOT NULL DEFAULT 0.0,
                    kills INTEGER NOT NULL DEFAULT 0,
                    region INTEGER NOT NULL DEFAULT 1,
                    balls INTEGER NOT NULL DEFAULT 0,
                    mballs INTEGER NOT NULL DEFAULT 0,
                    pballs INTEGER NOT NULL DEFAULT 0,
                    shinies INTEGER NOT NULL DEFAULT 0,
                    rp_l REAL NOT NULL DEFAULT -300.0,
                    run_exp REAL NOT NULL DEFAULT 0.0,
                    rebirths INTEGER NOT NULL DEFAULT 0,
                    last_prestige_at INTEGER NOT NULL DEFAULT 0,
                    coins INTEGER NOT NULL DEFAULT 0,
                    selected_title TEXT NOT NULL DEFAULT '',
                    max_lvl INTEGER NOT NULL DEFAULT 1,
                    rt REAL NOT NULL DEFAULT 20.0,
                    rt_max REAL NOT NULL DEFAULT 30.0,
                    seq INTEGER NOT NULL DEFAULT 0,
                    tv INTEGER NOT NULL DEFAULT 2
                );
                """.trimIndent()
            )

            // 2. 파티 출전 포켓몬 (슬롯 0 ~ 5)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS team_pokemon (
                    slot INTEGER PRIMARY KEY CHECK (slot >= 0 AND slot <= 5),
                    pokemon_id INTEGER NOT NULL,
                    lvl INTEGER NOT NULL DEFAULT 1,
                    cd REAL NOT NULL DEFAULT 1.0,
                    move_id INTEGER NOT NULL DEFAULT 33,
                    ability_id INTEGER NOT NULL DEFAULT 1,
                    joined INTEGER NOT NULL DEFAULT 0,
                    tb INTEGER NOT NULL DEFAULT 0,
                    mg REAL NOT NULL DEFAULT 0.0,
                    is_mega INTEGER NOT NULL DEFAULT 0,
                    mega_duration REAL NOT NULL DEFAULT 0.0,
                    mega_form_id INTEGER DEFAULT NULL,
                    ultra_revert_form_id INTEGER DEFAULT NULL,
                    status_json TEXT NOT NULL DEFAULT '{}',
                    item_id TEXT DEFAULT NULL,
                    is_shiny INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            // 3. 박스 보관 포켓몬
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS box_pokemon (
                    box_index INTEGER PRIMARY KEY AUTOINCREMENT,
                    pokemon_id INTEGER NOT NULL,
                    lvl INTEGER NOT NULL DEFAULT 1,
                    cd REAL NOT NULL DEFAULT 1.0,
                    move_id INTEGER NOT NULL DEFAULT 33,
                    ability_id INTEGER NOT NULL DEFAULT 1,
                    joined INTEGER NOT NULL DEFAULT 0,
                    tb INTEGER NOT NULL DEFAULT 0,
                    mg REAL NOT NULL DEFAULT 0.0,
                    is_mega INTEGER NOT NULL DEFAULT 0,
                    mega_duration REAL NOT NULL DEFAULT 0.0,
                    mega_form_id INTEGER DEFAULT NULL,
                    ultra_revert_form_id INTEGER DEFAULT NULL,
                    status_json TEXT NOT NULL DEFAULT '{}',
                    item_id TEXT DEFAULT NULL,
                    is_shiny INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            // 4. 보유 증표 (도감ID -> 수량)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS tokens (
                    pokemon_id INTEGER PRIMARY KEY,
                    count INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            // 5. 도감 조우/포획 기록
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS pokedex (
                    pokemon_id INTEGER PRIMARY KEY,
                    seen_count INTEGER NOT NULL DEFAULT 0,
                    caught_count INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS shiny_pokedex (
                    pokemon_id INTEGER PRIMARY KEY,
                    seen_count INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            // 6. 진행 중인 퀘스트 (최대 3개: 인덱스 0~2)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS quests (
                    quest_index INTEGER PRIMARY KEY CHECK (quest_index >= 0 AND quest_index <= 2),
                    type_key TEXT NOT NULL,
                    progress INTEGER NOT NULL DEFAULT 0,
                    target INTEGER NOT NULL DEFAULT 1,
                    is_done INTEGER NOT NULL DEFAULT 0,
                    quest_text TEXT NOT NULL,
                    reward_exp REAL NOT NULL DEFAULT 0.0,
                    region_id INTEGER
                );
                """.trimIndent()
            )

            // 7. 환생 특전 및 토글 ON/OFF 상태
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS perks (
                    perk_id TEXT PRIMARY KEY,
                    level INTEGER NOT NULL DEFAULT 0,
                    is_off INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            // 8. 현재 조우 중인 적 (단일 행 id = 1)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS enemy_state (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    enemy_id INTEGER NOT NULL,
                    lvl INTEGER NOT NULL,
                    hp REAL NOT NULL,
                    max_hp REAL NOT NULL,
                    is_shiny INTEGER NOT NULL DEFAULT 0,
                    is_lure INTEGER NOT NULL DEFAULT 0,
                    is_master INTEGER NOT NULL DEFAULT 0,
                    buffs_json TEXT NOT NULL DEFAULT '{}'
                );
                """.trimIndent()
            )

            // 9. 보유 도구 (도구ID -> 보유 스택 수)
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS game_items (
                    item_id TEXT PRIMARY KEY,
                    count INTEGER NOT NULL DEFAULT 0
                );
                """.trimIndent()
            )

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        try { db.execSQL("ALTER TABLE team_pokemon ADD COLUMN item_id TEXT DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE box_pokemon ADD COLUMN item_id TEXT DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE team_pokemon ADD COLUMN mega_form_id INTEGER DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE box_pokemon ADD COLUMN mega_form_id INTEGER DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE team_pokemon ADD COLUMN ultra_revert_form_id INTEGER DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE box_pokemon ADD COLUMN ultra_revert_form_id INTEGER DEFAULT NULL;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE team_pokemon ADD COLUMN is_shiny INTEGER NOT NULL DEFAULT 0;") } catch (e: Exception) {}
        try { db.execSQL("ALTER TABLE box_pokemon ADD COLUMN is_shiny INTEGER NOT NULL DEFAULT 0;") } catch (e: Exception) {}
        try { db.execSQL("CREATE TABLE IF NOT EXISTS game_items (item_id TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0);") } catch (e: Exception) {}
        try { db.execSQL("CREATE TABLE IF NOT EXISTS shiny_pokedex (pokemon_id INTEGER PRIMARY KEY, seen_count INTEGER NOT NULL DEFAULT 0);") } catch (e: Exception) {}
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) db.execSQL("ALTER TABLE game_metadata ADD COLUMN coins INTEGER NOT NULL DEFAULT 0")
        if (oldVersion < 2) {
            try { db.execSQL("ALTER TABLE game_metadata ADD COLUMN last_prestige_at INTEGER NOT NULL DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE game_metadata ADD COLUMN selected_title TEXT NOT NULL DEFAULT ''") } catch (_: Exception) {}
            try { db.execSQL("UPDATE game_metadata SET rp_l = -300.0 WHERE rp_l = 0.0 AND rebirths = 0") } catch (_: Exception) {}
        }
    }

    /**
     * 현재 데이터베이스에 유효한 세이브 데이터가 존재하는지 확인합니다.
     */
    fun hasSave(): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT 1 FROM game_metadata WHERE id = 1 LIMIT 1", null)
        val exists = cursor.use { it.moveToFirst() }
        return exists
    }

    /**
     * 게임 상태(GameState)를 SQLite 데이터베이스에 원자적(Atomic) 트랜잭션으로 저장합니다.
     */
    fun saveGameState(state: GameState) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // 1. game_metadata 저장
            val metaValues = ContentValues().apply {
                put("id", 1)
                put("save_version", 1)
                put("updated_at", System.currentTimeMillis())
                put("k", state.K)
                put("exp", state.exp)
                put("total_l", state.totalL)
                put("kills", state.kills)
                put("region", state.region)
                put("balls", state.balls)
                put("mballs", state.mballs)
                put("pballs", state.pballs)
                put("shinies", state.shinies)
                put("coins", state.coins)
                put("rp_l", state.rpL)
                put("run_exp", state.runExp)
                put("rebirths", state.rebirths)
                put("last_prestige_at", state.lastPrestigeAt)
                put("selected_title", state.selectedTitle)
                put("max_lvl", state.maxLvl)
                put("rt", state.rt)
                put("rt_max", state.rtMax)
                put("seq", state.seq)
                put("tv", state.tv)
            }
            db.insertWithOnConflict(
                "game_metadata",
                null,
                metaValues,
                SQLiteDatabase.CONFLICT_REPLACE
            )

            // 2. team_pokemon 저장 (기존 팀 데이터 삭제 후 슬롯별 재등록)
            db.delete("team_pokemon", null, null)
            state.team.forEachIndexed { index, mon ->
                val slotIndex = if (mon.slot in 0..5) mon.slot else index
                val monValues = ContentValues().apply {
                    put("slot", slotIndex)
                    put("pokemon_id", mon.id)
                    put("lvl", mon.lvl)
                    put("cd", mon.cd)
                    put("move_id", mon.move)
                    put("ability_id", mon.ab)
                    put("joined", mon.joined)
                    put("tb", mon.tb)
                    put("mg", mon.mg)
                    put("is_mega", if (mon.isMega) 1 else 0)
                    put("mega_duration", mon.megaDuration)
                    put("mega_form_id", mon.megaFormId)
                    put("ultra_revert_form_id", mon.ultraRevertFormId)
                    put("status_json", json.encodeToString(mon.status))
                    put("item_id", mon.item)
                    put("is_shiny", if (mon.isShiny) 1 else 0)
                }
                db.insertWithOnConflict(
                    "team_pokemon",
                    null,
                    monValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            // 3. box_pokemon 저장
            db.delete("box_pokemon", null, null)
            state.box.forEach { mon ->
                val boxValues = ContentValues().apply {
                    put("pokemon_id", mon.id)
                    put("lvl", mon.lvl)
                    put("cd", mon.cd)
                    put("move_id", mon.move)
                    put("ability_id", mon.ab)
                    put("joined", mon.joined)
                    put("tb", mon.tb)
                    put("mg", mon.mg)
                    put("is_mega", if (mon.isMega) 1 else 0)
                    put("mega_duration", mon.megaDuration)
                    put("mega_form_id", mon.megaFormId)
                    put("ultra_revert_form_id", mon.ultraRevertFormId)
                    put("status_json", json.encodeToString(mon.status))
                    put("item_id", mon.item)
                    put("is_shiny", if (mon.isShiny) 1 else 0)
                }
                db.insert("box_pokemon", null, boxValues)
            }

            // 4. tokens 저장
            db.delete("tokens", null, null)
            state.tokens.forEach { (pokemonId, count) ->
                val tokenValues = ContentValues().apply {
                    put("pokemon_id", pokemonId)
                    put("count", count)
                }
                db.insertWithOnConflict(
                    "tokens",
                    null,
                    tokenValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            // 5. pokedex 저장
            db.delete("pokedex", null, null)
            val allPokedexIds = (state.seen.keys + state.caught.keys).distinct()
            allPokedexIds.forEach { pokemonId ->
                val pokedexValues = ContentValues().apply {
                    put("pokemon_id", pokemonId)
                    put("seen_count", state.seen[pokemonId] ?: 0)
                    put("caught_count", state.caught[pokemonId] ?: 0)
                }
                db.insertWithOnConflict(
                    "pokedex",
                    null,
                    pokedexValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            db.delete("shiny_pokedex", null, null)
            state.shinySeen.forEach { (pokemonId, count) ->
                val values = ContentValues().apply {
                    put("pokemon_id", pokemonId)
                    put("seen_count", count)
                }
                db.insertWithOnConflict("shiny_pokedex", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }

            // 6. quests 저장
            db.delete("quests", null, null)
            state.quests.take(3).forEachIndexed { index, quest ->
                val questValues = ContentValues().apply {
                    put("quest_index", index)
                    put("type_key", quest.k)
                    put("progress", quest.p)
                    put("target", quest.n)
                    put("is_done", if (quest.done) 1 else 0)
                    put("quest_text", quest.text)
                    put("reward_exp", quest.rewardExp)
                    if (quest.g != null) {
                        put("region_id", quest.g)
                    } else {
                        putNull("region_id")
                    }
                }
                db.insertWithOnConflict(
                    "quests",
                    null,
                    questValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            // 7. perks 저장
            db.delete("perks", null, null)
            val allPerkKeys = (state.perks.keys + state.offPerk.keys).distinct()
            allPerkKeys.forEach { perkKey ->
                val perkValues = ContentValues().apply {
                    put("perk_id", perkKey)
                    put("level", state.perks[perkKey] ?: 0)
                    put("is_off", if (state.offPerk[perkKey] == true) 1 else 0)
                }
                db.insertWithOnConflict(
                    "perks",
                    null,
                    perkValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            // 8. enemy_state 저장
            db.delete("enemy_state", null, null)
            state.enemy?.let { enemy ->
                val enemyValues = ContentValues().apply {
                    put("id", 1)
                    put("enemy_id", enemy.id)
                    put("lvl", enemy.lvl)
                    put("hp", enemy.hp)
                    put("max_hp", enemy.maxHp)
                    put("is_shiny", if (enemy.isShiny) 1 else 0)
                    put("is_lure", if (enemy.isLure) 1 else 0)
                    put("is_master", if (enemy.isMaster) 1 else 0)
                    put("buffs_json", json.encodeToString(enemy.buffs))
                }
                db.insertWithOnConflict(
                    "enemy_state",
                    null,
                    enemyValues,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
            }

            // 9. game_items 저장
            db.delete("game_items", null, null)
            state.items.forEach { (itemId, count) ->
                if (count > 0) {
                    val itemValues = ContentValues().apply {
                        put("item_id", itemId)
                        put("count", count)
                    }
                    db.insertWithOnConflict(
                        "game_items",
                        null,
                        itemValues,
                        SQLiteDatabase.CONFLICT_REPLACE
                    )
                }
            }

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /**
     * SQLite 데이터베이스로부터 게임 상태(GameState)를 역직렬화하여 로드합니다.
     * 데이터가 없으면 null을 반환합니다.
     */
    fun loadGameState(): GameState? {
        val db = readableDatabase
        val metaCursor = db.rawQuery("SELECT * FROM game_metadata WHERE id = 1 LIMIT 1", null)
        if (!metaCursor.moveToFirst()) {
            metaCursor.close()
            return null
        }

        val state = GameState()
        metaCursor.use { c ->
            state.K = c.getInt(c.getColumnIndexOrThrow("k"))
            state.exp = c.getDouble(c.getColumnIndexOrThrow("exp"))
            state.totalL = c.getDouble(c.getColumnIndexOrThrow("total_l"))
            state.kills = c.getLong(c.getColumnIndexOrThrow("kills"))
            state.region = c.getInt(c.getColumnIndexOrThrow("region"))
            state.balls = c.getInt(c.getColumnIndexOrThrow("balls"))
            state.mballs = c.getInt(c.getColumnIndexOrThrow("mballs"))
            state.pballs = c.getInt(c.getColumnIndexOrThrow("pballs"))
            state.shinies = c.getInt(c.getColumnIndexOrThrow("shinies"))
            state.coins = c.getLong(c.getColumnIndexOrThrow("coins"))
            state.rpL = c.getDouble(c.getColumnIndexOrThrow("rp_l"))
            state.runExp = c.getDouble(c.getColumnIndexOrThrow("run_exp"))
            state.rebirths = c.getInt(c.getColumnIndexOrThrow("rebirths"))
            state.lastSeenAt = c.getLong(c.getColumnIndexOrThrow("updated_at"))
            state.lastPrestigeAt = c.getLong(c.getColumnIndexOrThrow("last_prestige_at"))
            state.selectedTitle = c.getString(c.getColumnIndexOrThrow("selected_title")) ?: ""
            state.maxLvl = c.getInt(c.getColumnIndexOrThrow("max_lvl"))
            state.rt = c.getDouble(c.getColumnIndexOrThrow("rt"))
            state.rtMax = c.getDouble(c.getColumnIndexOrThrow("rt_max"))
            state.seq = c.getLong(c.getColumnIndexOrThrow("seq"))
            state.tv = c.getInt(c.getColumnIndexOrThrow("tv"))
        }

        // team_pokemon 로드
        val teamCursor = db.rawQuery("SELECT * FROM team_pokemon ORDER BY slot ASC", null)
        teamCursor.use { c ->
            while (c.moveToNext()) {
                val statusJson = c.getString(c.getColumnIndexOrThrow("status_json"))
                val status: AllyStatus = runCatching {
                    json.decodeFromString<AllyStatus>(statusJson)
                }.getOrDefault(AllyStatus())

                val mon = AllyMon(
                    id = c.getInt(c.getColumnIndexOrThrow("pokemon_id")),
                    lvl = c.getInt(c.getColumnIndexOrThrow("lvl")),
                    cd = c.getDouble(c.getColumnIndexOrThrow("cd")),
                    move = c.getInt(c.getColumnIndexOrThrow("move_id")),
                    ab = c.getInt(c.getColumnIndexOrThrow("ability_id")),
                    slot = c.getInt(c.getColumnIndexOrThrow("slot")),
                    joined = c.getLong(c.getColumnIndexOrThrow("joined")),
                    tb = c.getInt(c.getColumnIndexOrThrow("tb")),
                    mg = c.getDouble(c.getColumnIndexOrThrow("mg")),
                    isMega = c.getInt(c.getColumnIndexOrThrow("is_mega")) == 1,
                    megaDuration = c.getDouble(c.getColumnIndexOrThrow("mega_duration")),
                    megaFormId = runCatching {
                        val idx = c.getColumnIndex("mega_form_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getInt(idx) else null
                    }.getOrNull(),
                    ultraRevertFormId = runCatching {
                        val idx = c.getColumnIndex("ultra_revert_form_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getInt(idx) else null
                    }.getOrNull(),
                    status = status,
                    isShiny = runCatching { val idx = c.getColumnIndex("is_shiny"); idx >= 0 && c.getInt(idx) == 1 }.getOrDefault(false),
                    item = runCatching {
                        val idx = c.getColumnIndex("item_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getString(idx) else null
                    }.getOrNull()
                )
                state.team.add(mon)
            }
        }

        // box_pokemon 로드
        val boxCursor = db.rawQuery("SELECT * FROM box_pokemon ORDER BY box_index ASC", null)
        boxCursor.use { c ->
            while (c.moveToNext()) {
                val statusJson = c.getString(c.getColumnIndexOrThrow("status_json"))
                val status: AllyStatus = runCatching {
                    json.decodeFromString<AllyStatus>(statusJson)
                }.getOrDefault(AllyStatus())

                val mon = AllyMon(
                    id = c.getInt(c.getColumnIndexOrThrow("pokemon_id")),
                    lvl = c.getInt(c.getColumnIndexOrThrow("lvl")),
                    cd = c.getDouble(c.getColumnIndexOrThrow("cd")),
                    move = c.getInt(c.getColumnIndexOrThrow("move_id")),
                    ab = c.getInt(c.getColumnIndexOrThrow("ability_id")),
                    slot = -1,
                    joined = c.getLong(c.getColumnIndexOrThrow("joined")),
                    tb = c.getInt(c.getColumnIndexOrThrow("tb")),
                    mg = c.getDouble(c.getColumnIndexOrThrow("mg")),
                    isMega = c.getInt(c.getColumnIndexOrThrow("is_mega")) == 1,
                    megaDuration = c.getDouble(c.getColumnIndexOrThrow("mega_duration")),
                    megaFormId = runCatching {
                        val idx = c.getColumnIndex("mega_form_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getInt(idx) else null
                    }.getOrNull(),
                    ultraRevertFormId = runCatching {
                        val idx = c.getColumnIndex("ultra_revert_form_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getInt(idx) else null
                    }.getOrNull(),
                    status = status,
                    isShiny = runCatching { val idx = c.getColumnIndex("is_shiny"); idx >= 0 && c.getInt(idx) == 1 }.getOrDefault(false),
                    item = runCatching {
                        val idx = c.getColumnIndex("item_id")
                        if (idx >= 0 && !c.isNull(idx)) c.getString(idx) else null
                    }.getOrNull()
                )
                state.box.add(mon)
            }
        }

        // tokens 로드
        val tokensCursor = db.rawQuery("SELECT * FROM tokens", null)
        tokensCursor.use { c ->
            while (c.moveToNext()) {
                val pokemonId = c.getInt(c.getColumnIndexOrThrow("pokemon_id"))
                val count = c.getInt(c.getColumnIndexOrThrow("count"))
                state.tokens[pokemonId] = count
            }
        }

        // pokedex 로드
        val pokedexCursor = db.rawQuery("SELECT * FROM pokedex", null)
        pokedexCursor.use { c ->
            while (c.moveToNext()) {
                val pokemonId = c.getInt(c.getColumnIndexOrThrow("pokemon_id"))
                val seenCount = c.getInt(c.getColumnIndexOrThrow("seen_count"))
                val caughtCount = c.getInt(c.getColumnIndexOrThrow("caught_count"))
                if (seenCount > 0) state.seen[pokemonId] = seenCount
                if (caughtCount > 0) state.caught[pokemonId] = caughtCount
            }
        }

        val shinyPokedexCursor = db.rawQuery("SELECT pokemon_id, seen_count FROM shiny_pokedex", null)
        shinyPokedexCursor.use { c ->
            while (c.moveToNext()) {
                val pokemonId = c.getInt(0)
                val count = c.getInt(1)
                if (count > 0) state.shinySeen[pokemonId] = count
            }
        }

        // quests 로드
        val questsCursor = db.rawQuery("SELECT * FROM quests ORDER BY quest_index ASC", null)
        questsCursor.use { c ->
            while (c.moveToNext()) {
                val regionCol = c.getColumnIndexOrThrow("region_id")
                val regionId = if (c.isNull(regionCol)) null else c.getInt(regionCol)
                val quest = Quest(
                    k = c.getString(c.getColumnIndexOrThrow("type_key")),
                    p = c.getInt(c.getColumnIndexOrThrow("progress")),
                    done = c.getInt(c.getColumnIndexOrThrow("is_done")) == 1,
                    n = c.getInt(c.getColumnIndexOrThrow("target")),
                    text = c.getString(c.getColumnIndexOrThrow("quest_text")),
                    rewardExp = c.getDouble(c.getColumnIndexOrThrow("reward_exp")),
                    g = regionId
                )
                state.quests.add(quest)
            }
        }

        // perks 로드
        val perksCursor = db.rawQuery("SELECT * FROM perks", null)
        perksCursor.use { c ->
            while (c.moveToNext()) {
                val perkId = c.getString(c.getColumnIndexOrThrow("perk_id"))
                val level = c.getInt(c.getColumnIndexOrThrow("level"))
                val isOff = c.getInt(c.getColumnIndexOrThrow("is_off")) == 1
                state.perks[perkId] = level
                if (isOff) state.offPerk[perkId] = true
            }
        }

        // enemy_state 로드
        val enemyCursor = db.rawQuery("SELECT * FROM enemy_state WHERE id = 1 LIMIT 1", null)
        enemyCursor.use { c ->
            if (c.moveToFirst()) {
                val buffsJson = c.getString(c.getColumnIndexOrThrow("buffs_json"))
                val buffs: Map<String, Double> = runCatching {
                    json.decodeFromString<Map<String, Double>>(buffsJson)
                }.getOrDefault(emptyMap())

                state.enemy = WildEnemy(
                    id = c.getInt(c.getColumnIndexOrThrow("enemy_id")),
                    lvl = c.getInt(c.getColumnIndexOrThrow("lvl")),
                    hp = c.getDouble(c.getColumnIndexOrThrow("hp")),
                    maxHp = c.getDouble(c.getColumnIndexOrThrow("max_hp")),
                    isShiny = c.getInt(c.getColumnIndexOrThrow("is_shiny")) == 1,
                    isLure = c.getInt(c.getColumnIndexOrThrow("is_lure")) == 1,
                    isMaster = c.getInt(c.getColumnIndexOrThrow("is_master")) == 1,
                    buffs = buffs
                )
            }
        }

        // game_items 로드
        try {
            val itemCursor = db.rawQuery("SELECT item_id, count FROM game_items", null)
            itemCursor.use { c ->
                while (c.moveToNext()) {
                    val itemId = c.getString(0)
                    val count = c.getInt(1)
                    if (count > 0) {
                        state.items[itemId] = count
                    }
                }
            }
        } catch (e: Exception) {
            // 테이블이 아직 없거나 로드 오류 시 무시
        }

        return state
    }

    /**
     * 데이터베이스의 모든 저장 데이터를 초기화합니다.
     */
    fun clearSave() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("game_metadata", null, null)
            db.delete("team_pokemon", null, null)
            db.delete("box_pokemon", null, null)
            db.delete("tokens", null, null)
            db.delete("pokedex", null, null)
            db.delete("quests", null, null)
            db.delete("perks", null, null)
            db.delete("enemy_state", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /**
     * WAL 모드의 체크포인트를 전체 수행하여, WAL 저널의 모든 변경사항을 메인 .psv 파일에 플러시합니다.
     */
    fun checkpointWal() {
        val db = writableDatabase
        val cursor = db.rawQuery("PRAGMA wal_checkpoint(FULL);", null)
        cursor.use {
            if (it.moveToFirst()) {
                // 체크포인트 정상 완료
            }
        }
    }
}
