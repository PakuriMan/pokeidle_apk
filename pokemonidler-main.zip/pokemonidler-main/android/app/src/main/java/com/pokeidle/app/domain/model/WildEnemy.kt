package com.pokeidle.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 야생 포켓몬이 사용하는 방어/특방/회피 버프 및 장막(스크린) 상태
 */
@Serializable
data class EnemyBuffs(
    var def: Int = 0,              // 방어 랭크
    var defLeft: Double = 0.0,     // 방어 버프 지속 시간
    var spd: Int = 0,              // 특수방어 랭크
    var spdLeft: Double = 0.0,     // 특수방어 버프 지속 시간
    var eva: Int = 0,              // 회피 랭크
    var evaLeft: Double = 0.0,     // 회피 버프 지속 시간
    var screen: String? = null,    // "reflect"(리플렉터), "light"(빛의장막), "aurora"(오로라베일)
    var screenLeft: Double = 0.0   // 장막 잔여 지속 시간
) {
    val hasAnyBuff: Boolean
        get() = def > 0 || spd > 0 || eva > 0 || (screen != null && screenLeft > 0.0)
}

/**
 * 아레나 중앙에 등장하는 야생 포켓몬 엔티티
 */
@Serializable
data class WildEnemy(
    val id: Int,                                    // 도감 번호 (1 ~ 1025)
    val lvl: Int,                                   // 적 레벨
    var hp: Double,                                 // 현재 HP (S.K 오프셋 스케일 적용 값)
    var maxHp: Double,                              // 최대 HP (S.K 오프셋 스케일 적용 값)
    val isShiny: Boolean = false,                   // 이로치(Shiny) 출현 여부 (1/256)
    val isLure: Boolean = false,                    // 하이퍼볼 유인 상태 (포획률 5배)
    val isMaster: Boolean = false,                  // 마스터볼 타깃 상태 (100% 포획)
    var buffs: Map<String, Double> = emptyMap(),    // 하위 호환 맵
    var enemyBuffs: EnemyBuffs = EnemyBuffs()       // 정밀 버프 상태
)
