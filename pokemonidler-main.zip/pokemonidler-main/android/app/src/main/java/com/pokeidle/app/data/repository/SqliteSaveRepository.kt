package com.pokeidle.app.data.repository

import com.pokeidle.app.data.local.PsvFileManager
import com.pokeidle.app.data.local.db.PokeIdleDatabaseHelper
import com.pokeidle.app.domain.model.GameState
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream

/**
 * Android 네이티브 SQLite 데이터베이스(pokeidle.psv)를 주 저장소로 사용하는 세이브 리포지토리 구현체.
 */
class SqliteSaveRepository(
    private val dbHelper: PokeIdleDatabaseHelper,
    private val psvFileManager: PsvFileManager,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SaveRepository {

    override suspend fun saveGame(state: GameState): Result<Unit> = withContext(ioDispatcher) {
        runCatching {
            dbHelper.saveGameState(state)
        }
    }

    override suspend fun loadGame(): Result<GameState?> = withContext(ioDispatcher) {
        runCatching {
            dbHelper.loadGameState()
        }
    }

    override suspend fun hasSave(): Boolean = withContext(ioDispatcher) {
        dbHelper.hasSave()
    }

    override suspend fun clearSave(): Result<Unit> = withContext(ioDispatcher) {
        runCatching {
            dbHelper.clearSave()
        }
    }

    override suspend fun exportSaveToPsv(destinationStream: OutputStream): Result<Unit> = withContext(ioDispatcher) {
        psvFileManager.exportToPsv(destinationStream)
    }

    override suspend fun importSaveFromPsv(sourceStream: InputStream): Result<GameState> = withContext(ioDispatcher) {
        psvFileManager.importFromPsv(sourceStream)
    }
}
