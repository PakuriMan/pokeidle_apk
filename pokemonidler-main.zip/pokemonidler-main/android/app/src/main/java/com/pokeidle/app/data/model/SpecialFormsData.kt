package com.pokeidle.app.data.model

/**
 * data.json 원본에 누락되었던 7세대 전설 포켓몬 특수 합체폼(황혼의 갈기, 새벽의 날개) 데이터
 */
object SpecialFormsData {
    const val NECROZMA_DUSK_MANE_IMG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAM1BMVEUAAAD///8ICAgY8BMbICErMjNCSlBT8vJ2gYiJcEuuYgDTiivbzI/zz1X9Kyv9+OH9/Pjcs3rTAAAAAnRSTlMAAHaTzTgAAAaESURBVHja1dmJYqPIDoXh8RlV2bXQlfd/2ls6Ahnl4oCnd/Xebf9fBJhxMv/c/n8E/tuTfzuffw4AyXjdz38PcL0v+LmA5BPgO/s/HZCc3gdO+j8FqBXvAoKLAPPLglf9JyCInYsA81cAyUfA6cqF+aXxHy4D1jkGEPJrv9YLCyTE/gnA/Kis9yGP9OOBMrQ/62NI3sMHQLD4hzOA/VGZV+BwgZTniMj7APs+LxdIj4cSSUSTCbF/BCAnlLVf67CpOFqAQFJCxwDvfwmMUthfVqAu2wJlnTpnA0iwLzonQCEwhl0+de1zAQ2vIK9cGgBoKKB7UGH/GCgDGZrtBLr3Mxj3vA0bJGbzoYus430FQn8DfAHt8xLa+p3jfSMU4PkgIiJHAPsB6Ow3LjDiKIH4clBBRySrJvIVUDpPsfV9gUhoPwAJWz7zF/kMlFoJtDomVa2vB+jxwKi1RgBrWuBAAjT/VD4BetSRkwEi1m98DvySCn1eMA6ID5VDYFFgpkQeWaw/CBz0GWKfgJ7YB0eSbFwEUDdAMi+G1/0C1v2GIFns8lwB8YNkQK0ERq0EJNtI24DaQ79D4tVOzolkx2gHYCGBMRSQrAtQWPuf8h1MWZ/DvhOSkAhMQQEKSqAr4H0VDNjSVcf66VVfq4kCkAhwQEKfK/nbv/dv37IN+x7ny1f7Zc6LPu98WsesOjAfj0UJPT73fxf2HfD4AqBrvPeOoz7zmUIKgH6QUAJyz3XJnPvd+ha3ug+SiHg/5inQB/wQ6b0YCnzkLf9xTwRinQOIdsX7IU8h3uxmXQeQfF/7Hx8fd/bB+uBs+SQWE/Zjnr9Pe6Awb+OXkH78M/PI8DpHzxbvNX6wY551OwMO7J8v9sTE4asRgxMNhkyQJMx7nSN74IZnhIfonp7Art/73ih7IdR9AQeUQNGnV5l57UNHcloB78ZFOCZ4nSMR8LNcF9hYFnOq1UJ17AcZSULdXmQRsLzenhsGCyzxfWkgiOzzetuAhDjrAbC+5oEpFCXKoqOCE4T5c8ir4G3WI+B9zY9Rm4hm6toHArHLA/Db4pouvR8A7Fftb+9ylRCp2p9lI+IR0p62XWCX/QMAAD9UOgSydMmwPnPhVABgdCfIV8CcugDcY6mS+TYN+kP7FgbCElHgnc37hwCwfbKx9g2oZrIZhfEUZOYJoL8GlB8bwPYggDH6Fgb8N34GROuZfYT+EeD9xYEGqgyzPEoBss0jW9wAdPbPgdlvwhuE5AjYbHm+E2Wc/W79U6AC1RYgsGxCD4ImH1vfAbD/ErDXgtaaAxODNmtYQetz4gJg/gzwzzZQNoArUPZBFwJhAeavAJqURGAAynnYB2J9B9DfATAEA8O9KPgKcYHrAPTKfwKvV5CwwHVgsE/gpcAV4gLlClC9r4kxiguO197tIQgLlHJlg7pop3fmdOstC/hv9RXR9TENwP41cBGwRzrQbSMd9BWYUxSotQKwBa5tUBcCWM+GPc2Gf4/enwL4yYT+LcAHXAX4OAdgfQsMpupCgTl0n6sb8GEOoG8JfqyDhAm6QBQKzoFmD3KBBgcgoMScQ6FfAXBzYFkIrAJILIOzkAhC4wpngPUJzEAbGJoGAZ7mxabZIjcXWmt2HZwAuDkwnzJ09Ekg0OagaV7/5flQNJ1+DviIXaccXwFqonRt8ZPwWxD6G4BkBQRDO/YsEJiNzS1hBX3QewB/sk4xwN7ykF0BQQDYPwfYT+BPzAy+MBwwd/TZz0+A8TcA62vGD/b2pjACLrwJhE9q/CkR4J5hhcL+OSA57ft9D7SmgE4AVOBcBLyv+dgnEPvvA9pPCHkO7/8aPgAo1IrbGeB9vl5jgi8mArHPQa1zv0vAg30dfzhdzDGA/c9Am3NlA3svghb7Ikk0QGC2DoA6p58DwnfMPAgc+JfvRUQFBZbQ9w2unOQKHfbtq+jwfkoK2BeMswFAPEKngIist+IxG88PE4AkAsK4rP2E3TV0DohGV0KydjygBoeAqAY8LyTA6l8D6+6yzFm/9IyD/5Ui8ngoPZ6ASBNeAl8CujZ/sJ8O+gSK9nkZSBYCVBONL68iANqFjkDn4MG1rl8C6HaWsPWTqHF2mR5FY5//secXMVojwH5ajYaTN16nU0WWZsPjCL/C9Idy3wmIXgLCs+SAGXMR4Pa9wEzKYgh/sy8y/50ArwEHcJz8LiAB3AKwC/RHAwDX0PbPAThM/1TAym/1CfwPiMazwTLPLgMAAAAASUVORK5CYII="
    const val NECROZMA_DAWN_WINGS_IMG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAMFBMVEX///8ICAgY8BMbICErMjMwX7ZCSlBhl+l2gYh7gH6Cxfev0tq98PT9Kyv+/v7/pvk05i61AAAAAXRSTlMAQObYZgAABpNJREFUeNrt2OF2o7gSBGBqWhIS4or3f9urrhYyCoHgcfbPnu0zwYMN9aUkxzkz0790vM37Nz29cLF5h/D+4R09nfNY4F1PiCGewsN8AHbv7B/lg/NMYH4q69oIf59v6atOwfxMAKZJhQQT7vN5NfPTBDxdJAqpRfjbfF5s+XWeCgQoELjPJ8D8Vv/8Rm4P5wrXgp+H/AZ8f6FP7W9j0FhBBKcCzCdwk7/4nOuLYn+/qiASAy7y7wDmKyARgzDuQo2v+SK4KkDgKp+AI0BhANbkGR9DgHN4v8BMIEsMziqcBYnMr8BfF8jFERiFBkgIN/nPgCLRBTdUEDRAQh0CPR8iXwvkO6DyThMaQEECrAKB6Bzz2yBGEXnlXwBMmzV/1QLhWEHCEYiuzvH7R4hq8ArLvwR8LlVgAauQtAIkxA60fN+BelJREoz/CSiZBaxCKgpICDLtgObzQ3IUuPPS8s8ApAFrFViAAooCErSAgMD4i6QJnkKgcAEEacBaxP9Z/rdXaIBAnAFrXk+fd/DgzjQg3wF5LW75Y/kN4LbqOtT8UhuegfoEuDN3QBACpUjcfOBQ8KLNHfYChcAo8I3gdC6BSVTwSxWEP6fbDiwE4LAD+QKwYb4C1xVcdApsZVPA2Q8WkDNS4RacAJ4j2f6WbHMGVMC8tAKlVID5BFKdXAvkvH4PaD8K9cYjAG3OEQp+bgXKtvH9TkBSqZNSyUWB5K+BLhQKyDlhqMACOpoOz/yQNLxk/VqvgSbktkoNsHgCFLQAs4FciuXHlFyqZ/UP86d7gMMKzE+p7YZQAKfY+AY4fmhwgZ4D2YBUVDpUmJDqlGT5HCGQy17gCqBgQCp6Pd8YRdM6QAHQfM/8Dkxa4THAYGZreFsk2QUamOcGROa/CZiQCXCOFTie+SNA4RlAwVpgALrABeLIDuS3AAq5/nkJ8hI8C4xbwKsfAxQ4KeNUwS/MP63QWwAFAmkEgiS/SIjbtr0AXptVeLPBUEEMiKLAVso2rBC/f1Z4vgdmfK2wiZdwAJjfPykETJzRAcxnoOX3EiNQhMct9hUqAl0gAgF+rnMEeDYCzNdjOgpCIG4u2ByAgKzrky+AGcwffpLtgdIuoKXa77TYt6BoJ9in/R3AMSDtDr9MSKkB/XfOXoAAhUzqR4BDoEIVoJAKczTbgPIC8roLRUIcARNEhyUZ2IHXQSfhBRRushyAyAoSwzeAsDmYfwS4UsUsAo5AqQ8tX8RBCNRTiAirfAUk1vjowPzjEh2PBrj9baT5zolTIK2iEQHOSVQIIkdAn+Ri2iZcDN9ZJgQemK9AEAltDZzUY31AFBmA6O4BCgaIAT2/htX4mtEAa4L4IvhaA+6FnA+CtAUCQgWihBijvQqG6VfP52AdgXImuuA0nzuccwWikGW07ACwF7B4rI8AE5w4G2RBVMDJ8XvXYnLIxz4HoRCQYfiECuJaigIhxiB2auqwQszV9y2fIZIzpAJMd+E4IhLsZrGUIFkC9BXGSs+3FeKIw0yAIsmMIKUIl9WNgN6bTWBM4I/wVwBzi2e+awI0XIwIwvhBYIqA+1AJ22AnIb4WJzSgxXOgQ4BnwYQQmD8Kwk21AdTyHhJdH72yFZjGwQtQQQiMAuN7vveVgJ/rwzE/1uFH0RkwAYy2bRuFng8oUqN9PSiAQzxnzB8rwKKViVHkJYizfNsoZIbPVgBDPlrU9xVqMLNRm9auJPTGnq/XaqYCcwNMCJYO75l0XYHZZLjw9jEoY34T+gJBgqWjB53GtwoxWjYa4Dgy5gMdmEhAxy/zFTBUiJYNGNDzNc3y+VgFn/tT/O8V/xNgQgyIjIbODsDXCIYBUwcsicLsCVzmm+C9dgiAAjZWAxMBCL99ArkDZNW9K9AEViaBoBPriBNMCniodAYGmCG3Agn0NzbqMH9Z2OQMWAfc5594tOFpyw9MOQGcVgGX+fcFfR3+1+IBWJcjgIAfC9xXHPMnrBVYcXwdk/e3+RxclGTAAMwDwAr93nvCz/6bfPlSgMBQAc/y2QI/FUh1hTrg0So8y7/ZAfhX/kxABb/swN/ntwJYfMvXAk3wCwFe81E+ARWS5s8N8Mzn4HOAgq/xnvl6Ug/z50AvD6Yy1ob5w2WfASYM8cz/sIKE8Z/tUhnRB/sV8rvABEjAIpFfM3B54TvAmBJDNfQQxzxW+LQAAQeJBOIvARg5V4FAxTncXPocmL4AoMLj1wqYPh5xGI7j/AIAdIYn/9T8VvJ/83+2bIje26HHdAAAAABJRU5ErkJggg=="

    fun getExtraForms(id: Int, base: PokemonDto): List<FormViewData> {
        val list = mutableListOf<FormViewData>()
        when (id) {
            800 -> { // 네크로즈마: 황혼의 갈기 & 새벽의 날개
                list.add(
                    FormViewData(
                        formKey = "necrozma_dusk_mane",
                        label = "황혼의 갈기",
                        fullName = "네크로즈마 (황혼의 갈기)",
                        types = listOf(14, 9), // 에스퍼 / 강철
                        img = NECROZMA_DUSK_MANE_IMG,
                        hp = 97,
                        atk = 157,
                        def = 127,
                        spa = 113,
                        sdf = 109,
                        spd = 77,
                        moves = base.moves,
                        pw = 113.3
                    )
                )
                list.add(
                    FormViewData(
                        formKey = "necrozma_dawn_wings",
                        label = "새벽의 날개",
                        fullName = "네크로즈마 (새벽의 날개)",
                        types = listOf(14, 8), // 에스퍼 / 고스트
                        img = NECROZMA_DAWN_WINGS_IMG,
                        hp = 97,
                        atk = 113,
                        def = 109,
                        spa = 157,
                        sdf = 127,
                        spd = 77,
                        moves = base.moves,
                        pw = 113.3
                    )
                )
            }
            791 -> { // 솔가레오 (네크로즈마 합체 형태)
                list.add(
                    FormViewData(
                        formKey = "solgaleo_dusk_mane",
                        label = "황혼의 갈기",
                        fullName = "네크로즈마 (황혼의 갈기)",
                        types = listOf(14, 9),
                        img = NECROZMA_DUSK_MANE_IMG,
                        hp = 97,
                        atk = 157,
                        def = 127,
                        spa = 113,
                        sdf = 109,
                        spd = 77,
                        moves = base.moves,
                        pw = 113.3
                    )
                )
            }
            792 -> { // 루나아라 (네크로즈마 합체 형태)
                list.add(
                    FormViewData(
                        formKey = "lunala_dawn_wings",
                        label = "새벽의 날개",
                        fullName = "네크로즈마 (새벽의 날개)",
                        types = listOf(14, 8),
                        img = NECROZMA_DAWN_WINGS_IMG,
                        hp = 97,
                        atk = 113,
                        def = 109,
                        spa = 157,
                        sdf = 127,
                        spd = 77,
                        moves = base.moves,
                        pw = 113.3
                    )
                )
            }
        }
        return list
    }
}
