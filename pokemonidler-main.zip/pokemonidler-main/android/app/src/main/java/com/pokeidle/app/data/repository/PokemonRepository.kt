package com.pokeidle.app.data.repository

import com.pokeidle.app.data.local.PokemonAssetsLoader
import com.pokeidle.app.data.model.AbilityDto
import com.pokeidle.app.data.model.AltFormDto
import com.pokeidle.app.data.model.FormViewData
import com.pokeidle.app.data.model.GameDataDto
import com.pokeidle.app.data.model.MegaDto
import com.pokeidle.app.data.model.MoveDto
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.model.HeldItemDto
import com.pokeidle.app.data.model.CanonicalStatsData
import com.pokeidle.app.domain.model.AllyMon
import java.io.InputStream
import kotlin.random.Random

/**
 * 1,025종 포켓몬, 폼체인지, 기술, 특성, 메가진화 도감 데이터 저장소 인터페이스
 */
interface PokemonRepository {
    fun isLoaded(): Boolean
    fun loadData(
        gameDataStream: InputStream,
        shinyStream: InputStream? = null,
        damagingMovesStream: InputStream? = null,
        heldItemsStream: InputStream? = null,
        pokeApiShinyStream: InputStream? = null,
        pokemonFormsStream: InputStream? = null
    )
    fun getHeldItem(id: String): HeldItemDto?
    fun getAllHeldItems(): List<HeldItemDto>
    fun getHeldItemsByCategory(category: String): List<HeldItemDto>
    fun getRandomDroppableItem(): HeldItemDto?
    fun getPokemon(id: Int): PokemonDto?
    fun getAllPokemon(): List<PokemonDto>
    fun getMove(id: Int): MoveDto?
    fun getAbility(id: Int): AbilityDto?
    fun getBattleMove(ally: AllyMon): MoveDto? = if (ally.isMega && ally.megaFormId == 10301 && ally.move == 687) {
        (getMove(687) ?: MoveDto(t = 16, p = 100.0, c = 3, ko = "코어퍼니셔")).copy(ko = "니힐레이저", txt = "메가지가르데가 코어퍼니셔 대신 사용하는 기술.")
    } else getMove(ally.move)
    fun getBattleAbilityId(ally: AllyMon): Int = if (ally.isMega) {
        com.pokeidle.app.data.model.FormAbilityData.abilities[ally.megaFormId] ?: ally.ab
    } else ally.ab
    fun getMegas(id: Int): List<MegaDto>
    fun getForms(id: Int): List<PokemonDto>
    fun getAltForms(id: Int): Map<String, AltFormDto>
    fun getAllFormViews(id: Int): List<FormViewData>
    fun getTypeName(typeId: Int): String
    fun getTypeEff(attackerType: Int, defenderTypes: List<Int>): Double
    fun getShinySprite(id: Int): String?
    fun getPokemonFormSpriteAsset(pokemonId: Int, isShiny: Boolean = false): String?
    fun getStarters(): List<PokemonDto>
    fun getChainBase(id: Int): Int
    fun rollAbility(pokemon: PokemonDto): Int
    fun carryAbility(fromAlly: AllyMon, toPokemon: PokemonDto): Int
    fun randomMove(pokemon: PokemonDto): Int
}

/**
 * 인메모리 캐싱 기반 PokemonRepository 구현체
 */
class DefaultPokemonRepository : PokemonRepository {

    private var gameData: GameDataDto? = null
    private val pokemonMap = HashMap<Int, PokemonDto>(1200)
    private val moveMap = HashMap<Int, MoveDto>(400)
    private val abilityMap = HashMap<Int, AbilityDto>(350)
    private val megaMap = HashMap<Int, List<MegaDto>>(120)
    private val formsBySpMap = HashMap<Int, MutableList<PokemonDto>>(60)
    private val altFormsMap = HashMap<Int, Map<String, AltFormDto>>(20)
    private val typeMap = HashMap<Int, String>(20)
    private val effMap = HashMap<String, Double>(150)
    private val parentMap = HashMap<Int, Int>(1200)
    private val learnsetMap = HashMap<Int, List<Int>>(1400)
    private val heldItemMap = LinkedHashMap<String, HeldItemDto>(350)
    private var shinyMap: Map<String, String>? = null
    private val apiFormsBySpecies = HashMap<Int, List<com.pokeidle.app.data.model.PokemonFormAssetDto>>(1200)

    // 1~9세대 스타터 및 피카츄 (28종)
    val starterIds = listOf(
        1, 4, 7, 25,
        152, 155, 158,
        252, 255, 258,
        387, 390, 393,
        495, 498, 501,
        650, 653, 656,
        722, 725, 728,
        810, 813, 816,
        906, 909, 912
    )

    override fun isLoaded(): Boolean = gameData != null

    override fun loadData(
        gameDataStream: InputStream,
        shinyStream: InputStream?,
        damagingMovesStream: InputStream?,
        heldItemsStream: InputStream?,
        pokeApiShinyStream: InputStream?,
        pokemonFormsStream: InputStream?
    ) {
        val data = PokemonAssetsLoader.loadGameData(gameDataStream)
        gameData = data

        // 1. 포켓몬 본체 및 폼체인지 매핑
        pokemonMap.clear()
        data.poke.forEach { pokemonMap[it.id] = it }
        data.forms.forEach { pokemonMap[it.id] = it }
        pokemonMap[249]?.let { pokemonMap[1026] = it.copy(id = 1026, sp = null, ko = "다크 루기아", en = "Shadow Lugia", img = "iVBORw0KGgoAAAANSUhEUgAAASAAAAEgCAYAAAAUg66AAAAAAXNSR0IArs4c6QAAFx9JREFUeJzt3V+MVdd1x/E7GJiB6Qxz5+Jh+GcYA26wsFtcKkxNhFwkF1lxVKdK6tIX5PihqixVcUVfbClKFV5ixVUkt/JDi/xSailqHNWRQ5CoiwqZIIhpjYsrx2T4/2fCHYaZzADDH/fB6T5rrs/i7j3nnLvOPff7edq+Pvdy5g9b68faZ++2EtACHlrxlBv3L13sxpfOX/w05HN6F1ba/n88cqUae83Hp/cF31+rmmV9AwBaFxMQADOzrW8AaDQZu55+9pmg97779juxkU1Gs4dKT8VdQjSLQQUEwAwTEAAzbfUvAZqT7Hz1Lqy48ciV6owjmObdt9+JfZ2u2b1RAQEwwwQEwAwRDIUlI1ipVIqNXcPDl9x4aOhi3c8cGIgWMfb19de9nmh2b1RAAMwwAQEww0JEtLSrV28EXS9jmhbZZEzTumzagsb+pYvFP4tEEbKocYwKCIAZJiAAZuiCoVB8Fh9ueOL33es+na+0+HTQarpm7u8nEQwAUsYEBMAMXTAUlvbMl1x82EhaB01Gs1ZDBQTADBMQADNEMLQEGbtCFx9mrZGduLyhAgJghgkIgBkiGJqeXHzY1d3lxuNj47HXj45ezfyeQlQvnHPj2XPb3eLD21M3Te6nkaiAAJhhAgJghgiGQhkfG4995qtZyNhV1Oe/JCogAGaYgACYIYKhJeRt8WFana+ajfeD5CHiUQEBMMMEBMAMEQxNqdkXH0qhnS/5tfcvjbbyuHT+YuxG91LeNr2nAgJghgkIgBkiGJpesyw+HBzc7caL+h52UWjBvGV13+sTu7QzyCR5Hlke4hgVEAAzTEAAzBDBYjT74i58Jm+LD6XLwyeicelE7DXy97BcKbtxaOyS5PV5iGNUQADMMAEBMNPSEUyLWjUL2+ou7ipxxHVDNOPiQ9n56u7ud78nY2PxZ5Npsetq9Wpsp0/bbF/72uUZZHmIY1RAAMwwAQEw03IRzKfElSW9LHdliXvyxPHM7hH1NcviQymt2OUTtTTaGWRaHCtXyi6OPZRBHKMCAmCGCQiAmZaIYElKXFmyyo7Gg6uedKVp76LovZvXbqt7Pwf3vuR34wjufOVh8aFP56uRsUujxTH55x49dER2gVPv9lIBATDDBATATGEjWNYlbt/KdW48e04/ixXvIcmzdZJP5ysPiw+lvMUujYxjcrGiJCOw/FqSdMSogACYYQICYKZQESyLEld2NDZve03+L/eZO3Y+F/veN199y+OuiynJxum9Cysurl67NuZev3PrVuz1ee58zWnrdK/nLXZpZBzLuiNGBQTADBMQADNNH8GyiF33LYg6XDJ2fe8fvuHGx5RFXC9sXeLG2/70FVem/vpar/YlFF6SjdOlypL4zdvz1vm6ezu6/dVf2ODGeY5dodLqiFEBATDDBATATFMujksrdsmoJcmu1nplUZaMYDJ2bdjyJfc9PXrgR9qXUEjy59K7sOLGI1eqM95EXXr37XdiX9eiWdZk56tSHnA/9777V7rX79ycU5jYJRcoHj10RP4v97UTwQA0DSYgAGaapguWReySXS0fxC5/WuySm6hr20FI2ibqkoxmVnGsuyuKnEWKXVmjAgJghgkIgJlcR7DQ2CWlVeISu+7NZ8dC7ewqHzKmaVtG1Gyo7sZZxLFpu2Ku2Ox+B2aX5hc+dvlE5lBUQADMMAEBMJPrCCb5xC6tvJedL23rDI2MXb/9O5uIXffQyB0LPc+3cuO04ljN7o7u61318CPuxSLFrqxRAQEwwwQEwEzuIphPV6Wvr9+NZYdFW3Do82yXj9GLE7H3mURaR9w2Ut7O6sqiO6Npli1B0iK7ftKK5Y+7f45on9U948+nAgJghgkIgJncRTDJp6siZfGc19r12934zsgVn/O/6po9t92Vr6FRLm+RLW9ndTUyjhWJFrW0o6VPn/1ZKn8uFRAAM0xAAMzkOoJJWufrzEi0DYIWuxZ9eZUbX/63k7HXyNi1adPz8TeR0mK26oVzQVGuY35nUGTLIqblrfOlqV4458ZWW3PkWWjUkuMsUAEBMMMEBMBMLiJYaHnvY/DBtW78x2LveZ84JvX0RNuA+HRz5PXlckfsNQMeiyFlhDl54njdyOYT09KKZnnrfOHz8ha1NFRAAMwwAQEwk4sIJvmU91rnS8YrGbt++OFc8fqUG2vHK2sRaXQ0/p59Ylco+Tk+249oMS1JNKPzlX9ZR62sn3mkAgJghgkIgJncRTBJLj5M4sNStI1Gx/cOu7FcfLh9+8sz/nzZ8ZExLYtoJmkxLa1oJtH5spVW1AqNVNoR2z7KlXL0O1aK/lwZx6iAAJhhAgJgJtcRLJTsdsnYtWF/fOxSn/lKiRbNpEZ20EKj2ay26JLJicnYP4vOV7pCo9actk439olXoZFq5ErVjbWjsSX5nObRQ0fk57d9/moqIACGmIAAmGn6CCYXE8pFhlq3S8Yun2ey5A57WnnsQ4t7jeygJYlmdL7Spf0uVcoDUVS5G9UH8zqi34f+8qNu3DE/imA3JicyjVSHDx+re73P3ymJCgiAGSYgAGaaMoLdufahG7/56lvReNmLbnzQI3bt2bOr7jWyVO7srLjyeGIiKmU13d3RQsrBwd2x5XHeopk8YvjkieOx19P5mhn5u9R//zr3u3T3zl33+oIFi9y47e6cupHqxmTU7ZU/O5/fDZ9IlRb5LKFEBQTADBMQADO5jmDyX+Dlc2HT/6U9PgrJaCNL38HB6Jq/KC134zfENQMD8c+F+cQuqeZ5HFdya9HMZ2Hk9K5T+nFMxi46X8nJ2FizUDA+XkVpLDhSyY6ttvA1a/Ie5O+PtiiRCgiAGSYgAGZyF8G6urtceSbLNp+jmSUZu2TUygMZzeQzPnmLY5JV50tqxs5Xknv2eZaw2VEBATDDBATATC4imNwhLckm2EPKJvPSulJn3Wt8PictaZ3HJMv1cjnseZzQzwd8yL9HbEoPIHeYgACYyUUE08hNrWVHTOssyM7XFx/d4t77xgcH3HtfL30h9r0//2W0TurFP//6zG44oSQdsbTULB5z42bsQCH/qIAAmGECAmAmdxFsWkdMnCU0t2OeiyfVC+din6NZsfxxd037sj73+s9/GF3+3Vdeif1z/1nELhnlKpWV0Z9bPVXv9hO5ezvo2KVptJ3o/vrb3459Xfs+AI1EBQTADBMQADOxZ/XkUegCxX957ydu/Pff+aYb737jb+vmnEbGLmnxwmiz8a7OfnefX30xuv9//8E/xb43NIJptGhGRwyh5D9laOeaUQEBMMMEBMBM00SwopLRcs78Xje+NTkSG8EkGcdkBAuNXRoZx7Tz0Rq5SBLNpebsM45mBpAvTEAAzBDBDMjYNbdjnhtP3bjuYlff2m3u9S1bN9b9zK/8yR+kdXuxtOfjiGPFluQ4cp9uMhUQADNMQADM5O5ZsCLRFk/KY2rHx8brbjOSB3/4lSiCye6bdv4acSxdSaJQEtoCQh8+i3ipgACYYQICYIYuWApCo5YkdyA8M1JxY5/O18BjA268XnkWLC0/+Nefxr6uPZtGHPuMPJo5idulSfd39dpo/UMTbt+56cZTtybc+PrNdA4XmN8ebXezcMEjsdecGd5f93OogACYYQICYIYuWIDQqDU+Nu5e146WTnLkcdaxKwm6Y5/x6Wz29JTrXnPyxPGoW9qzKuge5HHn8nfSh3ae1+TNYTf2iVoaKiAAZpiAAJihC/YbPjsuhna1JBm1tGOO71uwzo3z8PyXdExsxzH0/lDsNVpHTGrlOJaEjGnlckfQe+Vulj5CI5sW03xQAQEwwwQEwEwmXbDQDeTzwCdehXa1tKjVjGTHTYtgPrTumM/1rUz+Lo2Ohr131cPRQkGf+CaPQdfIY9Pl+X2hcYwKCIAZJiAAZjKJYLPnTbnx7etzZ37ecAP5xCupqFErCe25J20xnk+8IqYlFxrffH7/a2LajLvpVEAAzDABATCTSQQ78b//4cqz7dtfzuKPcHwWWfmUlBLx6t6+//q3Yl/PekfHefN6XKk/a9Z97vXBwd1BMZ/Idm/yDLisUQEBMMMEBMBMQ7fj8Ik2oTvItXLHSj6flfXWHH/25B+5cSMXYdYsXHRRq3/Z4y6OVRZviHYLHPmkFI1PunF3d3/s56R1b5gZKiAAZpiAAJhpaATziV2t3LE6uPclN96y9VDd6+UzWVlEMC129fX1x11eKpXkuVHR9hFZ/FxWr/tabIxavebrLo598ovo96ommtWNbJq0olwzxje5KHTF8igCt8/qnvFnUgEBMMMEBMBM5hEsdFFTkSKVj7TOjUqrIxYeu+JN3/Yh/Ti2Y+dzbiy/3r/6y7+LjUULelfHjrXIJsloXHM8cdAzUEnim1Vkk7GrUlnpvt7TZ3+WyudTAQEwwwQEwEzuzgVrhdg1rawtD8gyfsZdFW2XQp84dkyJyaGxSyPjWLkc3U9o3JYx5IWtS9z45VejjqEWzTRaZPvdx9aIn8trbiTjWKjQ+NbIyKZteyJjV7V6KugzfVABATDDBATATCbngsnScWzskisdfTarz3pLByuyxF22+Pfc9/36ZLRFXVel141P/TLacU5GjCQGHhuIff07z+9w49DO1/DwpbrXJKHFNPn9TPL9kd+Tmm6avMz9vJJEsKxpf+883+u+xpqomCkqIABmmIAAmMmkC6aVcD7xKq2FeaF/bhI+91wTP115PH9uxb04eb2a6VHZSc7zkrKOXZLWQRscjK45sP+wG/scaS3J70la3x8rSRZJNjJ2SVRAAMwwAQEwk7uFiFnEpdDzqkI/U37Oxo3rgz7n8OFj0X9cKAV1DLPWyKgVSh52sGdP1Jk6uLf+e9PqKiI5KiAAZpiAAJjJXQTzocUfTdZdMLkoTnZn5PM4A8pzSdMjW3x8k+dwffXFb87sJltHbPfngQej7+2unU/UXaT3xae+4T7n01nLU7kxfB4VEAAzTEAAzGS68K1UKpUqlZVuXK2ecqWvz3YBWXSvsiAjWGdnxX1PJyaqsaW+TzTT+BxFnSSmybgXekCAlT17dsn/zPx3GumhAgJghgkIgJnMu2ByFzX5yL/PDm95PjtJ26y7Zte46PjgcrTtg/zaqxeiBYdatJSdsqeffSb2GrloUMYoKQ8dNBmX5GLCtPQve9yNV6/7Wuw1ed5So9VQAQEwwwQEwExDFyJqj/znOWpJPrFLe4arfX7UnKl0r4nGCZ4j057V0rpXu3Y+Efu6fDbq49P7Yu8ttFvnI0kckzslStqRzf3L+9wPYPO21+IuIZoZoAICYIYJCIAZs2fBZISRXaEkcSz0GTEfobGrf2kUVS6dv+i+rpuTUTLQOlmatLbF0GKOjGaNjMPyz/KJYz7niMkdEeWG82+++lZsNFu9Zlns+V8S0Sw7VEAAzDABATCTi+dmkjwvJiNSWvEhNHaVK2U3vlq96u4/rag1pBydLMkuVZLzvLSYk6QLJj/zxz/+rhtn8fPSdjv0PP/LkUcz/9f7v3CvE8fSRQUEwAwTEAAzudgRUUYbrTumaWTs0sjYJRcBJolU8n40Mgb6LGL06abJc7hKpbJ6XQitY5UF2dGTcUw7/2vHzufcuCaayd+9XPxTRRFRAQEwwwQEwEwuIpikbWdRo24002jRJjR2aeSOhfK5qlBatJSLLX225khiehwLoz2rlbWFi6Kfo9x8XuuOFelo5mZEBQTADBMQADO5i2A+QjtlktyVUW4PkiR2lURUHJ+IPrN9brcb35wam/HzbqGxK3ThYlq0RYxZLBbVXLl8yo3XPvpkUBxD41EBATDDBATATFNGMM9OWSxtV8ZQSTpcPrTYlWRxo3Z9T0+04NCn8+WzLUYefPTBe26sxTENRzM3BhUQADNMQADMNGUEaxbd3dG2GD7Rzyd2JXmOTOtAyRg1Olr345uSjGMlj9j+n/vit+lAuqiAAJhhAgJghm0GslV38aGMXdp5Xlrs0qKWXGwpjY1dSmXzfx+NXHyofR9k56smgiEnqIAAmGECAmCGLljKOjsrbjwxUQ16b5KoJbtsWscti7PY8kY+5yUXHG7Y8iX3tR898KMG3xU0VEAAzDABATBDBKtDbvwu3bo74cZDZw+5Ul/GriTbbshnzUKjlvr5Hpv/J4ljjex8+fjH/Rfc+IWtS4hjOUQFBMAMExAAMyxE/A0tas2e2+7Gt6duxm7jUFmyLJV7kBHmt+Yvcj+bX09eTuXzNTXPrJkfjR0q9GjmF7Yukf+LvwOGqIAAmGECAmCmpctPGbvmdsxz46kb1zONWlKSI6EzErTJfx5i1wMr17vv25lTx+puPi+Pby61+N8Ba1RAAMwwAQEw03Llp0/sShK15HlbPs92aYsMcyK3z4vVPB/nvodrH33SvfjRB+/Fxkm26cgPKiAAZpiAAJhpiWfBso5dGzeud+PDh48FvTeHsaup+Ww+T+zKDyogAGaYgACYaYkIJmURu7TjkqUm6nzFksc3+xzH7HPcc7Mc8YzsUAEBMMMEBMBMYSOY7Hz1Low2ih+5Un+j+CRdLR/NErvWDGxxUfHkiePRjoLK+WWhZDQr6pHQuDcqIABmmIAAmClsBJNGrlRdfHj62Wfc6zJehXa1fDR756vtbnv9ixqo2b+f+DwqIABmmIAAmGmJCJaF0JhGTEgX389ioAICYIYJCICZlotgSTpc8uhkufOhJF8fHIxerzl7a8b3ABQJFRAAM0xAAMy0XATTaNFseqTaHXuN9myU3Mh9cHC33CC95Q4DiCO349Cw+LDYqIAAmGECAmCmsBFsfCIq0bs6+2Ov8elqaSamzrs4cPRQKZVdFltN6C6IxK7ioQICYIYJCICZwkawqVsTbvzx6X1urEUkeYyyTxy7cWPSjW/fOefi2MeD+2KPA24WcifJru4uNx4fG7e4HRQcFRAAM0xAAMwUakGcjA+yC9Z2X/RlXrj837ERSb5XW1goY1rNosTCfB/l96FUKqW+Eb3PWWAsPmwdVEAAzDABATBT2C5YV2d/bNQaeGBDVNJfiyLA1KfDbrxnzy73Xvk8V1E1svPF4kNIVEAAzDABATBT2AgmyQ7O0UNHXLxavWqVi2OfnDzqrqlUVrrXa7bRKLzxsfHUO18+6Hy1JiogAGaYgACYaYkIJulxbENsHCsVaJGh1MjOl8/OhxKxq3VQAQEwwwQEwEyh4sU9YkXdzs7RQ0fke933RYskcosPzeZtr9W9xsfBvS/N+L01z3Y5od+fJOQzdBKdL1ABATDDBATATNN3wbSYc/3q2eg/xv6n7udo3TGpd/EKFxM2LP0b93pHd/ym9/3L+9z40tnh0AWNQfE4NGrJaNnI2KUhdrUmKiAAZpiAAJhp+i5YTQSrG3OGP9rrxqHRQ3bK+tZuC3rvjp3Pxb4+9P6QGx/Yf1j+L/ezkfes0aKWlPWzXT6xS3a+5DN31eqpTO4J+UYFBMAMExAAM4WNYFu2bqz73u+//i039oknZ0YqbqxFKknGK42MXZ9ORsc9j/7qvHu9Y/YtN9bilZR11PLZWF4idkFDBQTADBMQADOFimD39/W68a+GR2KjihbNZBxb9fAjblwud8ReP7D+6bAbFWTs8ulwSY3cpTA0aknELvigAgJghgkIgJmmj2CS9lzYgp5okd610fpdJC0WhUazmoWFzgO91Xq30FBpRS2J2AUfVEAAzDABATBTqAim8dmZ8IbYDuKmGLfdibatuDE5ERvfKkuWuXFPT9mNtZjWSEnilaRFLXYyRBJUQADMMAEBMNMSESwJbafBW3cn3Hjo7KG6nbVNm553YxnTkkgSqSQtXklELWSBCgiAGSYgAGaIYBnqFpvVj41dCoppSfhEKol4BStUQADMMAEBMEMEMxYa0zw/k0iFpkAFBMAMExAAAAAAAEDx/R/tpFJae443oQAAAA5lWElmTU0AKgAAAAgAAAAAAAAA0lOTAAAAAElFTkSuQmCC", chain = 1026, evo = emptyList()) }

        pokemonMap[384]?.let { pokemonMap[1027] = it.copy(id = 1027, sp = null, ko = "화이트 레쿠자", en = "White Rayquaza", chain = 1027, evo = emptyList(), hp = 999, atk = 999, def = 999, spa = 999, sdf = 999, spd = 999, pw = 999.0, img = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAAAM5klEQVR4Xu2cT2gb1xbGv0khDlm4cfq88bheBIwRUSkJxKDG4EV25nWhl2qVTTCYvl1pRLIwZBXQIsaFrkoJBG/aTdpqkaKdFwFFAgcaHlWfCIY+cGRvTJs/ixAX2nkLzXd15urekWYs2ZI6PxCWR6OZO+e795xzz9wRkJCQkJCQkJCQYKFQ2vIKpS1P355wBBRrDW//wPP2D7xEhD5wQt8QRmpmCsVaIxGhh0QSYGHWRX1nT9+c0G+kG0pcUW+JNAIGGZEojF7n0EdAsdbwBikWFEpbqm0jKQAMIgyCK2Kv1zrFsbYpKkPrggqlLW/lyiWkZqZQ3t4FANR39lAobem7DjSOvsFGsdbwFmZdfTPubT7B6tJ818c5LBx1K1cuKcOTbHoaUa5pEIjUWPY6naMSgefXDY8hNT565YJSM1Pop++lrx814yOuANII5e3dvk7OTL5eMszGR5yGF0pbnt/jAT/wrS7NI86xwgjz9WTYjY+4I0DSL+OH9XoMacZjIpYApmyoF3Ty9ZLVpfkjCfz9JpYAkkJpS7mLuEjDh/V6Mgquh8S6CD0OHMYgMrXtZHgc8lyDSKwL0d1ENj1t9Md+fCCBc3UKsr6hUaw11DZmW6PgekisC9EF0GNCeXsXtS8+xuv1n9S2tYnWqQqlLavh0d7LPYowar0fcS9G9l7iz4axf9AKB+XtXVRcF+P5i3i9/hMmqk/A75mMH5LS8qD69qGnqwuiwelS7ixfwL+/avXue5tPlBiTY81D3lm+gNfrP2E8fxHvfPI1EGJ4CJfTbZtGhY4XawqSFdfFrdPA3TfARLVlfGlcYVA1KsKMX6w1AjPqUfLzYXS8SN3f13f28CLTNPjahNPRuJ2g8StuK47cOt0cVfgbCNHx4qQA9Z091dtpoDC30gn2eJnSUohbp5v/j7oQoRelux+Z7UyONXu/NL4IoiiUtgKGNcHer0MXJxlVIbqaCbP3E9349Z09ZNPTkYwPfz9bJbW8vRsQd8WfJR921j1odCUARMpZ3t5Vxq/v7KHiuoEJV7HWwMqVS21zAxOpmamOQkkhFmZdrFy5NFIiWAWQ7ofIkcBgvDbh4OaLlj26MXwnxvMXUXHdQGCWQoySCFYBiPT9DMKcdNH4nOWyHKG7Dxs295O+8RAf7e6GCjEqIhgDmin4crJV3t5VtR/peuj3X129BgB4fvm1+ix946F6T+o7ex3dD5ECfLTbEpbtEoF56GbMxoaacn9pfD1zeXX1mjL47ftPAQD5VAZnMm+RvvHQaGyZMenlCxsUwiICNuYW8fOJP7Ber8J2bYNGWyNl7w/L9V9dvYafT/yBM5m3eFk9xYvG5vIaAOD54x/x/PJr1ftDRHDkDf1OYthEmBxzsDG3iHe//2aoinahMYCpHw1RzuWQTU+jnMvh+eXXyujr9So2l9eU8UvVHwLGlymqRKSVDl+TY46qJy3Mum1BnYbX44KpHD4MmHqJp5cXXl29huvPHvFz1WM35hZx/dkjZXhSqv6g3I+ttCwRI0HiIaSOpI8EjgJZUzIcc+AwNdBjnp9NT8PzPDiOA21fL5/K4IO/TuL9y/9UG2l4iMBrcAdtIlgEIG0dglRcN+CKpJsznHcgMbkgZ3LMURdgMv6d5QttxgeApcy/8LJ6Sv1vMYIjK6UIuiITjnRJOtIVrVy5FKjCDgMmASB8Mt8HPmOmQ0rVH1DBt6jgW+V6SD6V8Qyr5pQI9PNxRJC9XzJMItgECMPbmFsM9H7Z86XrKdYaOJN5izvLF2ATgW6lmzKD3FfCUcCsbZgCchwB2nj++Me2nk/SNx7iZfVUqAiSEBHa9oVlFDAO5FMZT770/QYB3b10g3dn+QLefzyuNugpJ7TVDPBT2DOZt5yo6edVgZb4LqdtP97QhxgRFdfFRLU5GeN5mQlNfX5TffnnE3+o92imz/rxj5y4DfD8Hg34vdxmeAhj/Jb/TM0dfALBXZa4s9pSl9WleVX+kKsq5IxaL4PTDRKWSYifWse1QU84zMkDXVbveRJ9BkxMRia6kNx35colNVGjIHLZivye/r9EzG0OY4NDc+iT51MZ7731L9X/NmPbCDOSRAogkXMD/Vj6/5KhF4CBMjUzFchK9MlSN4QZSpJNTwdqRUS6LVKsNUKPOygCxMqCCv7a0BXDnS9T/SYqvAcgJ1lhxoQQZ//AU8YfBuII4K0uzSObnsbkmKNyb50oIkiDsbzAV8V1lXFN8QWGkbEw64aKNUhEEqDQXEaOYq2BQnNZOlaX5nsiAgy1HVjy/MNSzuVUSmqZcxwZXQvA+wR0OyxVm0Qo+7cNTfGgvrMXeEnY4+v+KotselrtYzoWLNvvbT5RQdvEB3+dxHq9KkfJsT103pUA8iaNhDUcYjK6bvDUzBRWm0+3IDUzFRAhm56Wq6gdAA6rpDLfl9B1sQPc23yCVPNndYz767D9HWpRfaOjADbjSzgK6jt7KOdybQaXL/pr+v0/v/tUihAwuo9XrDWUoaTA8j1HIfdbmHWxf+BFCsYU4SiFCBWgk/FpADkKAODP7z5VBpfIYMlAefv+U/yW/wyWdDBw70C6lLJ/v0LC5CAKuqtiu49KBKsAYca/+6b5Ypoo08X31r/Ey+op1L74WHyj5Sr+cbJpvMkxB/WdPRRrDZYn5AV7rPvwe/KvbnwmBfBFkp+FjQKOvNTMVFvae1SjwSqAjbtvmn9lmsgHL8h6vRoQIWuZodIlFUpbHBkea0L7Bx6NQAM69Om6gWUsSvn+n+WK8vZuIM0t53Lq9urq0jzuLF8IpL66CP0eDUYBbL2fxpcLZ1mFZBzge9tI+N9/X6j3FEKeq1hrqGAuAq9yT1JI06xYcm/zierlFEEsWXHg31xam2iORohMTNJPEYwChHHrdMv3SwOt+utypD+lCADwoXMaxVoD586fBXzj//rL7/jQOa1cEo1bDy72DcQG2yTLNOdg2iwzLf14IvBbXRX6KEJkASSagZzrzx4F6u/wRSiUtnDu/Fl86DSHzsbcIjbmFnHu/FmcO39WuZisn/f7WRBfCj2vp5uRZP35gz46eI7AxiAO2zCev6g2ytjQDxHaGmRzP/BdEEdAyAV5G3OL+jagVX+XmL5vhW3j8ngYRNANz1VzEc/lwX/OjTea5CxddJJDc6gRYMG5/uwRTC/Rq9t6d1zojoq1RpvxJ8ecOMYH23f7/lNjbPADfk9HgqIgfgDP9Lr54nh+GE+2C4Dnea33/K04+bt2crt+rIioY9180fptuh4d2zwC9HKCRH906KiRLkcGbmY5k/7SRlOgjokxNggOJUKbAMy1w9CDoURfidDLVQn0/YXSFhwnaGQGXn4O31eHtTUizu37T1VaTdfkHz/2aDD5Rk8+8WLr8dq6fMA3PpcmmmBKGnU1ggy+v/7yO/7jvVF1JmglDiYIYvIV6VxdoIxT8BcBZNPTyKcycsFB1+c07egVaw0szLoq6zGhC0Djm9YGEfYefzm76dwBmPIxK6MAANR8AoDapm+3XF8vaFvfmk1Px3o+oc0FEcYBzn51VoILqDxYnoSRaJ9bhyxrMJxIkf0DL2DgYq2hJnd8+fQsy7JgXCT27vffYOHBA+RTGXTrlmyNjDIKsK89L2xCn6nq+bmc4NjmIfA7BO8Z3HzhqfSQOXqf3I4JD1pphK4Pfs0Jfl0srD22D9QQqxgemobl11G6hX5aBsgwoxPZGSj4MRkf8Cec1589sorAp4jCYoPVBXViVSyIioI0fspfWRHX+JIjNr5CBHvAD8zMkOiSNuYWpVsKYBMg4OP0C+btP92tdIMsjMX5vt6W8fzFYzO+uLEfuLegp/KG2KAIa7RKRznEaTBZi4mCqCGBMUaiB3zp+u6+aV8hITpJ2HX0E08+GEiPIMUwuCHI9tpGAAA4DHasgbBO3w/oYuTr7pvWOeVD27UvPpa9/riMH0C6Io4Crr7T70HI74UJAPhD3ERUIcL21zMtGp0ZTsV1kfafnl+bcGxL3I8d6YqKtYZegDRi/UDg8efH6ALKuRw++Otk4LkAG/KO2PuPx1VJWrogk3shzHIGwN2Y8PKpDBYePFAbpIsV/1vbbP1AQ4kA/5ey+JSk/EkCHT7EwWC18OCBuotWKG2pX96CZQVcxXX1dUKDiIoD2oJfT7gla9utHxjw4N+keOeTr5GamVKTjU7IHgJxK5O9hD9xqd3w4O5R2ngcKAHKuZw+8WKmYr0G6wchqPQnzjyAyJEAcxU2TtuOA+WGOvV2E5F2NtBWlIpDnIYPGJ6ohka6jkg7W/AgSrNhMEMY4t5uo6OrsRH5CwaUD5SzXBNSID4wNwhPqRwnvbpwJUI31Hf2MPX5zb+98dHNRKzXJMYP0ksDWNcD6STGb9FrI3Rboev1eRMSEhISEhISEhISuuf/8qoW5nrYtnoAAAAASUVORK5CYII=") }
        // 2. 리전 및 다른 모습 폼 (sp 기준 매핑)
        formsBySpMap.clear()
        data.forms.forEach { f ->
            f.sp?.let { sp ->
                formsBySpMap.getOrPut(sp) { mutableListOf() }.add(f)
            }
        }

        // 3. 기술 매핑
        moveMap.clear()
        data.moves.forEach { (k, v) -> k.toIntOrNull()?.let { moveMap[it] = v } }

        // 4. 특성 매핑
        abilityMap.clear()
        data.abilities.forEach { (k, v) -> k.toIntOrNull()?.let { abilityMap[it] = v } }
        mapOf(308 to "관통드릴", 309 to "드래곤스킨", 310 to "메가솔라", 311 to "하바네로분출", 312 to "Eelevate", 313 to "Fire Mane").forEach { (id, name) ->
            abilityMap.putIfAbsent(id, AbilityDto(ko = name))
        }
        abilityMap[210] = AbilityDto(ko = "유대변화", txt = "메가스톤 없이 지우개굴닌자로 메가진화한다. 변신 중 물수리검(위력 90)을 사용한다.")
        abilityMap[211] = AbilityDto(ko = "스웜체인지", txt = "기본폼 2마리가 있을 시 합체 가능한 특성")
        pokemonMap[658]?.let { pokemonMap[658] = it.copy(abil = it.abil.filterNot { a -> a.firstOrNull() == 210 } + listOf(listOf(210, 1))) }

        // 5. 메가진화 매핑 (공식 종족값 CanonicalStatsData 보정 주입)
        megaMap.clear()
        data.megas.forEach { (k, v) ->
            k.toIntOrNull()?.let { specId ->
                val enriched = v.map { mega ->
                    val canonical = CanonicalStatsData.getMegaStat(mega.id)
                    if (canonical != null) {
                        mega.copy(
                            hp = canonical.hp,
                            atk = canonical.atk,
                            def = canonical.def,
                            spa = canonical.spa,
                            sdf = canonical.sdf,
                            spd = canonical.spd,
                            pw = canonical.pw
                        )
                    } else {
                        mega
                    }
                }
                megaMap[specId] = enriched
            }
        }

        // 6. 배틀 폼체인지 (altforms) 매핑 (공식 종족값 CanonicalStatsData 보정 주입)
        altFormsMap.clear()
        data.altforms.forEach { (k, v) ->
            k.toIntOrNull()?.let { specId ->
                val enriched = v.mapValues { (formKey, alt) ->
                    val canonical = CanonicalStatsData.getAltStat(specId, formKey)
                    if (canonical != null) {
                        alt.copy(
                            hp = canonical.hp,
                            atk = canonical.atk,
                            def = canonical.def,
                            spa = canonical.spa,
                            sdf = canonical.sdf,
                            spd = canonical.spd,
                            pw = canonical.pw
                        )
                    } else {
                        alt
                    }
                }
                altFormsMap[specId] = enriched
            }
        }

        // 7. 타입 및 상성 매핑
        typeMap.clear()
        data.types.forEach { (k, v) -> k.toIntOrNull()?.let { typeMap[it] = v } }
        effMap.clear()
        effMap.putAll(data.eff)

        // 8. 진화 트리 부모 매핑 (PARENT)
        parentMap.clear()
        (data.poke + data.forms).forEach { p ->
            p.evo.forEach { evoEntry ->
                if (evoEntry.isNotEmpty()) {
                    parentMap[evoEntry[0]] = p.id
                }
            }
        }

        // 9. 이로치 스트림이 제공된 경우 로드
        val originalShinyMap = shinyStream?.let(PokemonAssetsLoader::loadShinyMap).orEmpty()
        val pokeApiShinyMap = pokeApiShinyStream?.let(PokemonAssetsLoader::loadShinyMap).orEmpty()
        shinyMap = originalShinyMap + pokeApiShinyMap
        apiFormsBySpecies.clear()
        pokemonFormsStream?.let(PokemonAssetsLoader::loadPokemonForms)?.groupBy { it.speciesId }
            ?.let(apiFormsBySpecies::putAll)

        // 10. PokéAPI v2 기반 위력 있는(데미지) 기술 및 습득 기술셋 로드 및 재구성
        learnsetMap.clear()
        val moveStream = damagingMovesStream ?: try {
            val testAsset = java.io.File("src/main/assets/damaging_moves.json")
            if (testAsset.exists()) java.io.FileInputStream(testAsset) else null
        } catch (e: Exception) {
            null
        }

        if (moveStream != null) {
            try {
                moveStream.use { stream ->
                    val damagingData = PokemonAssetsLoader.loadDamagingMoves(stream)

                    // 1) 571종 위력 있는(데미지) 기술 목록 moveMap에 등록/덮어쓰기
                    damagingData.moves.forEach { (k, v) ->
                        k.toIntOrNull()?.let { moveMap[it] = v.copy(txt = v.txt?.takeIf { text -> text.isNotBlank() } ?: moveMap[it]?.txt) }
                    }

                    // 2) 포켓몬별 위력 있는 배움 기술셋 매핑
                    damagingData.learnsets.forEach { (k, v) ->
                        k.toIntOrNull()?.let { pid ->
                            if (v.isNotEmpty()) {
                                learnsetMap[pid] = v
                            }
                        }
                    }

                    // 3) 1~1,025종 포켓몬 및 폼체인지 객체의 moves 필드를 오직 위력 있는 기술로 재구성
                    pokemonMap.keys.toList().forEach { pid ->
                        val p = pokemonMap[pid] ?: return@forEach
                        val newMoves = learnsetMap[pid] ?: learnsetMap[p.chain]
                        if (!newMoves.isNullOrEmpty()) {
                            pokemonMap[pid] = p.copy(moves = newMoves)
                        }
                    }
                }
            } catch (e: Exception) {
                // damaging_moves 로드 실패 시 원본 fallback
            }
        }

        // 11. 장착 가능 지닌도구(Held Items) 로드
        mapOf(724 to 662, 727 to 663, 730 to 664, 785 to 717, 786 to 717, 787 to 717, 788 to 717, 802 to 712, 784 to 691, 792 to 714).forEach { (id, move) ->
            pokemonMap[id]?.let { if (move !in it.moves) pokemonMap[id] = it.copy(moves = it.moves + move) }
        }
        heldItemMap.clear()
        val itemStream = heldItemsStream ?: try {
            val testAsset = java.io.File("src/main/assets/held_items.json")
            if (testAsset.exists()) java.io.FileInputStream(testAsset) else null
        } catch (e: Exception) {
            null
        }

        if (itemStream != null) {
            try {
                itemStream.use { stream ->
                    val items = PokemonAssetsLoader.loadHeldItems(stream)
                    heldItemMap.putAll(items)
                }
            } catch (e: Exception) {
                // held_items 로드 실패 시 무시
            }
        }
        heldItemMap["legend-plate"] = HeldItemDto("legend-plate", 0, "레전드 플레이트", "legend", desc = "아르세우스 전용. 멸망의 뭉치는 상성 우위 및 확정 급소로 적중한다.", short = "전용기 상성 우위·확정 급소", category = "held-items")
        heldItemMap.keys.toList().forEach { key ->
            val item = heldItemMap[key]!!
            if (item.category == "z-crystals" && key != "ultranecrozium-z") heldItemMap[key] = item.copy(desc = "대응 기술 사용으로 게이지를 충전하면 10초 동안 Z기술로 변환한다. 전용 Z크리스탈은 해당 포켓몬의 대응 기술이 필요하다.", short = "게이지 100% · 10초 Z기술")
        }
        mapOf("lycanium" to "루가루암", "mimikium" to "따라큐", "kommonium" to "짜랑고우거", "solganium" to "솔가레오", "lunalium" to "루나아라").forEach { (key, name) ->
            val id = "$key-z--held"
            heldItemMap[id] = HeldItemDto(id, 0, "${name}Z", "zcrystal", desc = "대응 전용 기술로 게이지를 충전하면 10초 동안 전용 Z기술로 변환한다.", short = "전용 Z기술", category = "z-crystals")
        }
        heldItemMap["red-orb"] = HeldItemDto("red-orb", 534, "주홍구슬", "primal", desc = "그란돈을 원시회귀시키는 구슬.", short = "그란돈 원시회귀", category = "held-items")
        heldItemMap["blue-orb"] = HeldItemDto("blue-orb", 535, "쪽빛구슬", "primal", desc = "가이오가를 원시회귀시키는 구슬.", short = "가이오가 원시회귀", category = "held-items")    }

    override fun getHeldItem(id: String): HeldItemDto? = heldItemMap[id]

    override fun getAllHeldItems(): List<HeldItemDto> = heldItemMap.values.toList()

    override fun getHeldItemsByCategory(category: String): List<HeldItemDto> =
        heldItemMap.values.filter { it.category == category }

    override fun getRandomDroppableItem(): HeldItemDto? {
        val list = heldItemMap.values.filter { it.id !in setOf("necropluser-sol", "necropluser-luna") }
        return if (list.isNotEmpty()) list.random() else null
    }

    override fun getPokemon(id: Int): PokemonDto? {
        val pokemon = getRawPokemon(id) ?: return null
        if (id == 1027) return pokemonMap[384]?.let { pokemon.copy(moves = it.moves, abil = it.abil) } ?: pokemon
        if (id == 1026) return pokemonMap[249]?.let { pokemon.copy(moves = it.moves, abil = it.abil, hp = it.hp, atk = it.atk, def = it.def, spa = it.spa, sdf = it.sdf, spd = it.spd, pw = it.pw) } ?: pokemon
        val stat = com.pokeidle.app.data.model.OfficialFormStats.all[id] ?: return pokemon
        return pokemon.copy(hp = stat.hp, atk = stat.atk, def = stat.def, spa = stat.spa, sdf = stat.sdf, spd = stat.spd, pw = stat.pw)
    }

    private fun getRawPokemon(id: Int): PokemonDto? = pokemonMap[id] ?: run {
        if (id in setOf(10181, 10118, 10119, 10120)) {
            val base = pokemonMap[718] ?: return@run null
            return@run when (id) {
                10181, 10118 -> base.copy(id = id, ko = "지가르데 10%폼", hp = 54, atk = 100, def = 71, spa = 61, sdf = 85, spd = 115, evo = emptyList(), abil = listOf(listOf(188, 0), listOf(211, 1)))
                10120 -> base.copy(id = id, ko = "지가르데 퍼펙트폼", hp = 216, atk = 100, def = 121, spa = 91, sdf = 95, spd = 85, evo = emptyList(), abil = listOf(listOf(211, 0)))
                else -> base.copy(id = id, ko = "지가르데 50%폼", evo = emptyList(), abil = listOf(listOf(211, 0)))
            }
        }
        if (id == 10117) {
            return@run pokemonMap[658]?.copy(id = id, ko = "지우개굴닌자", en = "greninja-ash")
        }
        val form = apiFormsBySpecies.values.asSequence().flatten().firstOrNull { it.pokemonId == id } ?: return@run null
        val base = pokemonMap[form.speciesId] ?: return@run null
        val koName = when (form.name) {
            "greninja-ash" -> "지우개굴닌자"
            "pikachu-original-cap" -> "지우 모자 피카츄"
            "pikachu-hoenn-cap" -> "호연 모자 피카츄"
            "pikachu-sinnoh-cap" -> "신오 모자 피카츄"
            "pikachu-unova-cap" -> "하나 모자 피카츄"
            "pikachu-kalos-cap" -> "칼로스 모자 피카츄"
            "pikachu-alola-cap" -> "알로라 모자 피카츄"
            "pikachu-partner-cap" -> "파트너 모자 피카츄"
            "pikachu-world-cap" -> "월드 모자 피카츄"
            else -> "${base.ko} (${com.pokeidle.app.data.model.KoreanFormNames.names[form.formId] ?: "특수 모습 ${form.formId}"})"
        }
        base.copy(id = id, ko = koName, en = form.name)
    }

    override fun getAllPokemon(): List<PokemonDto> = (gameData?.poke?.mapNotNull { pokemonMap[it.id] } ?: emptyList()) + listOfNotNull(pokemonMap[1026], getPokemon(1027))

    override fun getMove(id: Int): MoveDto? = moveMap[id] ?: when (id) {
        662 -> MoveDto(t = 8, p = 80.0, c = 2, ko = "그림자꿰매기")
        663 -> MoveDto(t = 17, p = 85.0, c = 2, ko = "DD래리어트")
        664 -> MoveDto(t = 11, p = 90.0, c = 3, ko = "물거품아리아")
        717 -> MoveDto(t = 18, p = 1.0, c = 3, ko = "자연의분노", txt = "상대의 현재 체력 절반을 감소시킨다.")
        712 -> MoveDto(t = 8, p = 90.0, c = 2, ko = "섀도스틸")
        691 -> MoveDto(t = 16, p = 110.0, c = 3, ko = "스케일노이즈")
        714 -> MoveDto(t = 8, p = 100.0, c = 3, ko = "섀도레이")
        594 -> MoveDto(t = 11, p = 90.0, c = 2, ko = "물수리검", en = "water-shuriken")
        else -> null
    }

    override fun getAbility(id: Int): AbilityDto? = abilityMap[id]

    override fun getMegas(id: Int): List<MegaDto> = if (id in com.pokeidle.app.data.model.ZygardeFusionData.allIds) listOf(
        MegaDto(id = 10301, label = "메가지가르데", hp = 216, atk = 70, def = 91, spa = 216, sdf = 85, spd = 100, types = listOf(16, 5), pw = 129.7)
    ) else if (id == 1027) (megaMap[384] ?: emptyList()).map { it.copy(id = 11027, label = "화이트 메가레쿠자", hp = 999, atk = 999, def = 999, spa = 999, sdf = 999, spd = 999, pw = 999.0) } else megaMap[id] ?: emptyList()

    override fun getForms(id: Int): List<PokemonDto> = formsBySpMap[id]?.mapNotNull { pokemonMap[it.id] } ?: emptyList()

    override fun getAltForms(id: Int): Map<String, AltFormDto> = altFormsMap[id] ?: emptyMap()

    /**
     * 포켓몬 도감 상세 조회 시 기본폼, 메가/울트라폼, 리전폼, 배틀변신폼을 통합 제공
     */
    override fun getAllFormViews(id: Int): List<FormViewData> {
        val base = getPokemon(id) ?: return emptyList()
        val result = mutableListOf<FormViewData>()

        // 1. 기본 폼
        result.add(
            FormViewData(
                formKey = "base_${base.id}",
                label = "기본 폼",
                fullName = base.ko,
                types = base.types,
                img = base.img,
                hp = base.hp,
                atk = base.atk,
                def = base.def,
                spa = base.spa,
                sdf = base.sdf,
                spd = base.spd,
                moves = base.moves,
                pw = base.pw,
                spriteAssetName = getPokemonFormSpriteAsset(base.id),
                shinySpriteAssetName = getPokemonFormSpriteAsset(base.id, true)
            )
        )

        // 2. 특수 합체 폼 (황혼의 갈기, 새벽의 날개 등)
        val extraForms = com.pokeidle.app.data.model.SpecialFormsData.getExtraForms(id, base)
        result.addAll(extraForms)

        // 3. 메가진화 / 변신 폼 (울트라 네크로즈마, 메가리자몽 X/Y, 원시회귀, 무한다이맥스 등)
        val megas = getMegas(id)
        megas.forEach { mega ->
            val label: String
            val fullName: String
            if (!mega.label.isNullOrEmpty() && mega.suffix.isNullOrEmpty()) {
                label = "${mega.label}폼"
                fullName = "${mega.label} ${base.ko}"
            } else if (!mega.label.isNullOrEmpty() && !mega.suffix.isNullOrEmpty()) {
                label = mega.suffix
                fullName = "${base.ko} (${mega.suffix})"
            } else if (!mega.suffix.isNullOrEmpty()) {
                label = "메가${mega.suffix}"
                fullName = "메가${base.ko} ${mega.suffix}"
            } else {
                label = "메가폼"
                fullName = "메가${base.ko}"
            }

            val canonical = CanonicalStatsData.getMegaStat(mega.id)
            val hp = canonical?.hp ?: mega.hp ?: base.hp
            val atk = canonical?.atk ?: mega.atk ?: base.atk
            val def = canonical?.def ?: mega.def ?: base.def
            val spa = canonical?.spa ?: mega.spa ?: base.spa
            val sdf = canonical?.sdf ?: mega.sdf ?: base.sdf
            val spd = canonical?.spd ?: mega.spd ?: base.spd
            val pw = canonical?.pw ?: if (mega.pw > 0.0) mega.pw else base.pw

            val megaMoves = learnsetMap[mega.id] ?: base.moves
            result.add(
                FormViewData(
                    formKey = "mega_${mega.id}",
                    label = label,
                    fullName = fullName,
                    types = if (mega.types.isNotEmpty()) mega.types else base.types,
                    img = if (mega.img.isNotEmpty()) mega.img else base.img,
                    hp = hp,
                    atk = atk,
                    def = def,
                    spa = spa,
                    sdf = sdf,
                    spd = spd,
                    moves = megaMoves,
                    pw = pw,
                    spriteAssetName = getPokemonFormSpriteAsset(mega.id),
                    shinySpriteAssetName = if (id in setOf(1026, 1027)) null else getPokemonFormSpriteAsset(mega.id, true)
                )
            )
        }

        // PokéAPI 폼 레지스트리: 메가/거다이맥스/리전/배틀/코스메틱 등 전체 폼.
        val alreadyRepresentedFormIds = buildSet {
            getMegas(id).forEach { add(it.id) }
            getForms(id).forEach { add(it.id) }
            if (id == 800) addAll(setOf(10155, 10156, 10157)) // 수동 합체폼/울트라폼과 중복 방지
        }
        apiFormsBySpecies[id].orEmpty().filter { apiForm ->
            !(id == 718 && apiForm.formId in setOf(10220, 10221)) &&
                !(id == 658 && apiForm.formId == 10218) &&
            (apiForm.pokemonId != id || !apiForm.isDefault) &&
                apiForm.pokemonId !in alreadyRepresentedFormIds && apiForm.formId !in alreadyRepresentedFormIds
        }.forEach { apiForm ->
            val label = com.pokeidle.app.data.model.KoreanFormNames.names[apiForm.formId] ?: when (apiForm.name) {
                "greninja-ash" -> "지우개굴닌자"
                "zygarde-mega" -> "메가지가르데"
                "zygarde-complete" -> "퍼펙트폼"
                "staraptor-mega" -> "메가찌르호크"
                "necrozma-dusk" -> "황혼의 갈기"
                "necrozma-dawn" -> "새벽의 날개"
                else -> if (apiForm.name.endsWith("-gmax")) "거다이맥스" else null
                    ?: apiForm.formName.ifBlank { apiForm.name.substringAfter("${base.en.lowercase().replace(" ", "-")}-", apiForm.name) }
                    .let { raw -> if (raw.any { it in 'a'..'z' || it in 'A'..'Z' }) "특수 모습 ${apiForm.formId}" else raw }
            }
            val apiPokemon = getPokemon(apiForm.pokemonId) ?: base
            val canonical = CanonicalStatsData.getPokemonFormStat(id, apiForm.pokemonId)
            result.add(
                FormViewData(
                    formKey = "api_form_${apiForm.formId}",
                    label = label,
                    fullName = "${base.ko} ($label)",
                    types = if (apiPokemon.types.isNotEmpty()) apiPokemon.types else base.types,
                    img = if (apiPokemon.img.isNotEmpty()) apiPokemon.img else base.img,
                    hp = canonical?.hp ?: apiPokemon.hp,
                    atk = canonical?.atk ?: apiPokemon.atk,
                    def = canonical?.def ?: apiPokemon.def,
                    spa = canonical?.spa ?: apiPokemon.spa,
                    sdf = canonical?.sdf ?: apiPokemon.sdf,
                    spd = canonical?.spd ?: apiPokemon.spd,
                    moves = if (apiPokemon.moves.isNotEmpty()) apiPokemon.moves else base.moves,
                    pw = canonical?.pw ?: apiPokemon.pw,
                    spriteAssetName = apiForm.defaultSprite,
                    shinySpriteAssetName = apiForm.shinySprite
                )
            )
        }

        // 3. 리전 폼 및 다른 모습 폼 (알로라, 가라르, 히스이, 팔데아 등)
        val regionalForms = getForms(id)
        regionalForms.forEach { form ->
            val label = when {
                form.ko.contains("알로라") -> "알로라"
                form.ko.contains("가라르") -> "가라르"
                form.ko.contains("히스이") -> "히스이"
                form.ko.contains("팔데아") -> "팔데아"
                form.ko.contains(" ") -> form.ko.substringBefore(" ")
                else -> "이형"
            }

            result.add(
                FormViewData(
                    formKey = "form_${form.id}",
                    label = label,
                    fullName = form.ko,
                    types = if (form.types.isNotEmpty()) form.types else base.types,
                    img = if (form.img.isNotEmpty()) form.img else base.img,
                    hp = form.hp,
                    atk = form.atk,
                    def = form.def,
                    spa = form.spa,
                    sdf = form.sdf,
                    spd = form.spd,
                    moves = if (form.moves.isNotEmpty()) form.moves else base.moves,
                    pw = form.pw,
                    spriteAssetName = getPokemonFormSpriteAsset(form.id),
                    shinySpriteAssetName = getPokemonFormSpriteAsset(form.id, true)
                )
            )
        }

        // 4. 배틀 폼체인지 (캐스퐁, 모르페코, 불비달마, 돌핀맨, 지가르데 등)
        val altForms = getAltForms(id)
        altForms.forEach { (key, alt) ->
            val label = if (alt.ko.contains("(") && alt.ko.contains(")")) {
                alt.ko.substringAfter("(").substringBefore(")")
            } else {
                key
            }

            val canonical = CanonicalStatsData.getAltStat(id, key)
            val hp = canonical?.hp ?: alt.hp ?: base.hp
            val atk = canonical?.atk ?: alt.atk ?: base.atk
            val def = canonical?.def ?: alt.def ?: base.def
            val spa = canonical?.spa ?: alt.spa ?: base.spa
            val sdf = canonical?.sdf ?: alt.sdf ?: base.sdf
            val spd = canonical?.spd ?: alt.spd ?: base.spd
            val pw = canonical?.pw ?: alt.pw ?: base.pw

            val altPid = when ("${id}_${key}") {
                "351_sun" -> 10013
                "351_rain" -> 10014
                "351_snow" -> 10015
                "555_zen" -> 10017
                "10177_zen" -> 10178
                "877_hangry" -> 10187
                "746_school" -> 10127
                "964_hero" -> 10256
                "718_complete" -> 10120
                "1024_tera" -> 10276
                "1024_stellar" -> 10277
                else -> null
            }
            val altMoves = altPid?.let { learnsetMap[it] } ?: base.moves

            result.add(
                FormViewData(
                    formKey = "alt_${key}",
                    label = label,
                    fullName = alt.ko.ifEmpty { "${base.ko} ($label)" },
                    types = if (alt.types.isNotEmpty()) alt.types else base.types,
                    img = if (alt.img.isNotEmpty()) alt.img else base.img,
                    hp = hp,
                    atk = atk,
                    def = def,
                    spa = spa,
                    sdf = sdf,
                    spd = spd,
                    moves = altMoves,
                    pw = pw


                )
            )
        }

        return if (id == 718) result.filterNot { it.formKey in setOf("alt_complete", "alt_718_complete") } else result
    }

    override fun getTypeName(typeId: Int): String = typeMap[typeId] ?: "노말"

    /**
     * 공격 타입 vs 방어 타입 상성 배율 계산 (src.html eff() 공식)
     * 무효 상성(0.0)은 게임 밸런스를 위해 0.1배로 변환
     */
    override fun getTypeEff(attackerType: Int, defenderTypes: List<Int>): Double {
        var multiplier = 1.0
        for (defType in defenderTypes) {
            val key = "$attackerType-$defType"
            val e = effMap[key] ?: 1.0
            multiplier *= e
        }
        return if (multiplier == 0.0) 0.1 else multiplier
    }

    override fun getShinySprite(id: Int): String? {
        return if (id in setOf(1026, 1027, 11027)) null else shinyMap?.get(id.toString())
    }

    override fun getPokemonFormSpriteAsset(pokemonId: Int, isShiny: Boolean): String? =
        if (pokemonId == 1027) "white_rayquaza.png" else if (pokemonId == 11027) "white_rayquaza_mega.png" else if (pokemonId == 1026) "shadow_lugia.png" else
        apiFormsBySpecies.values.asSequence().flatten().firstOrNull { it.pokemonId == pokemonId }
            ?.let { if (isShiny) it.shinySprite else it.defaultSprite }

    override fun getStarters(): List<PokemonDto> {
        return starterIds.mapNotNull { pokemonMap[it] }
    }

    /**
     * 해당 진화 라인의 가장 기초 단계 포켓몬 도감 번호 탐색 (baseOf)
     */
    override fun getChainBase(id: Int): Int {
        var current = id
        while (parentMap.containsKey(current)) {
            current = parentMap[current]!!
        }
        return current
    }

    /**
     * 포켓몬 특성 무작위 부여 (숨겨진 특성 10% 확률)
     */
    override fun rollAbility(pokemon: PokemonDto): Int {
        val list = pokemon.abil
        if (list.isEmpty()) return 1
        val hidden = list.filter { it.size > 1 && it[1] == 1 }
        val normal = list.filter { it.size > 1 && it[1] == 0 }

        val pool = if (hidden.isNotEmpty() && Random.nextDouble() < 0.1) {
            hidden
        } else if (normal.isNotEmpty()) {
            normal
        } else {
            hidden
        }
        return if (pool.isNotEmpty()) pool.random()[0] else list.first()[0]
    }

    /**
     * 진화 시 특성 슬롯 계승 (carryAbility)
     */
    override fun carryAbility(fromAlly: AllyMon, toPokemon: PokemonDto): Int {
        val from = getPokemon(fromAlly.id) ?: return rollAbility(toPokemon)
        val toList = toPokemon.abil
        if (toList.isEmpty()) return 1

        val fromIndex = from.abil.indexOfFirst { it.isNotEmpty() && it[0] == fromAlly.ab }
        if (fromIndex >= 0 && fromIndex < toList.size) {
            return toList[fromIndex][0]
        }
        if (toList.any { it.isNotEmpty() && it[0] == fromAlly.ab }) {
            return fromAlly.ab
        }
        return rollAbility(toPokemon)
    }

    /**
     * 포켓몬이 배울 수 있는 4개 기술 중 무작위 1개 선정
     */
    override fun randomMove(pokemon: PokemonDto): Int {
        if (pokemon.moves.isEmpty()) return 33 // 몸통박치기
        return pokemon.moves.random()
    }
}
