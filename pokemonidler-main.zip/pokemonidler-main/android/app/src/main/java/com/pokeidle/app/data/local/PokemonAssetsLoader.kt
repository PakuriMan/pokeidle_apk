package com.pokeidle.app.data.local

import com.pokeidle.app.data.model.GameDataDto
import kotlinx.serialization.json.Json
import java.io.InputStream

/**
 * Android assets 디렉토리의 data.json 및 shiny.json 파싱 로더
 */
object PokemonAssetsLoader {

    val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    /**
     * data.json 스트림을 읽어 GameDataDto 객체로 역직렬화
     */
    fun loadGameData(inputStream: InputStream): GameDataDto {
        val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return jsonParser.decodeFromString<GameDataDto>(jsonText)
    }

    /**
     * shiny.json 스트림을 읽어 (도감ID -> Base64 이미지) 매핑 파싱
     */
    fun loadShinyMap(inputStream: InputStream): Map<String, String> {
        val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return jsonParser.decodeFromString<Map<String, String>>(jsonText)
    }

    /**
     * damaging_moves.json 스트림을 읽어 위력 있는 기술 목록 및 포켓몬별 습득 기술셋 파싱
     */
    fun loadDamagingMoves(inputStream: InputStream): com.pokeidle.app.data.model.DamagingMovesDataDto {
        val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return jsonParser.decodeFromString<com.pokeidle.app.data.model.DamagingMovesDataDto>(jsonText)
    }

    /**
     * held_items.json 스트림을 읽어 도구 목록(HeldItemDto 매핑) 파싱
     */
    fun loadHeldItems(inputStream: InputStream): Map<String, com.pokeidle.app.data.model.HeldItemDto> {
        val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val payload = jsonParser.decodeFromString<com.pokeidle.app.data.model.HeldItemsDataDto>(jsonText)
        return payload.items
    }

    fun loadPokemonForms(inputStream: InputStream): List<com.pokeidle.app.data.model.PokemonFormAssetDto> {
        val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return jsonParser.decodeFromString<com.pokeidle.app.data.model.PokemonFormAssetsDataDto>(jsonText).forms
    }
}
