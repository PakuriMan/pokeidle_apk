package com.pokeidle.app.domain.system

import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.EnemyBuffs
import com.pokeidle.app.domain.model.WildEnemy
import kotlin.random.Random

/**
 * 야생 포켓몬의 저항(Resist) 기술 정의 및 효과 적용 시스템
 */
data class ResistMove(
    val name: String,
    val type: Int,
    val text: String,
    val weight: Double = 1.0,
    val isSelf: Boolean = false,
    val action: (enemy: WildEnemy, team: List<AllyMon>, weather: WeatherType?, terrain: TerrainType?, repo: PokemonRepository) -> String
)

object ResistSystem {

    /**
     * 야생 포켓몬의 방어/특방 버프에 따른 피해 감소 배율
     * buffMult(n) = 2 / (2 + n)
     */
    fun getEnemyMitigation(
        moveCategory: Int, // 3: 특수, 2: 물리
        buffs: EnemyBuffs,
        ignoreScreens: Boolean,
        ignoreRanks: Boolean
    ): Double {
        if (!buffs.hasAnyBuff) return 1.0

        var m = if (ignoreRanks) 1.0 else {
            val rank = if (moveCategory == 3) buffs.spd else buffs.def
            2.0 / (2.0 + rank.coerceAtLeast(0))
        }

        if (!ignoreScreens && buffs.screen != null && buffs.screenLeft > 0.0) {
            when (buffs.screen) {
                "aurora" -> m *= 0.5
                "reflect" -> if (moveCategory != 3) m *= 0.5
                "light" -> if (moveCategory == 3) m *= 0.5
            }
        }
        return m
    }

    /**
     * 야생 포켓몬의 회피율 계산 (enemyEvasion)
     */
    fun getEnemyEvasion(
        enemy: WildEnemy,
        attackingAlly: AllyMon?,
        team: List<AllyMon>,
        repo: PokemonRepository
    ): Double {
        // 동료 특성으로 적 회피 무시
        if (AbilitySystem.teamHas(team, repo, "감미로운꿀", "개미지옥", "그림자밟기", "노가드", "발광", "승리의별")) {
            return 0.0
        }
        if (attackingAlly != null && AbilitySystem.has(attackingAlly, team, repo, "복안", "심안")) {
            return 0.0
        }
        val eva = enemy.enemyBuffs.eva
        return if (eva > 0) (eva * 0.15).coerceAtMost(0.6) else 0.0
    }

    /**
     * 매 틱 적의 버프 및 스크린 지속 시간 감소
     */
    fun tickEnemyBuffs(enemy: WildEnemy, dt: Double) {
        val b = enemy.enemyBuffs
        if (!b.hasAnyBuff) return

        if (b.def > 0) { b.defLeft -= dt; if (b.defLeft <= 0.0) b.def = 0 }
        if (b.spd > 0) { b.spdLeft -= dt; if (b.spdLeft <= 0.0) b.spd = 0 }
        if (b.eva > 0) { b.evaLeft -= dt; if (b.evaLeft <= 0.0) b.eva = 0 }
        if (b.screen != null) {
            b.screenLeft -= dt
            if (b.screenLeft <= 0.0) {
                b.screen = null
            }
        }
    }

    /**
     * 적 저항 공격 발동 후 카운터 데미지 처리 (까칠한피부, 독가시, 독치장, 철가시)
     */
    fun handleAfterEnemyResist(team: List<AllyMon>, enemy: WildEnemy, repo: PokemonRepository): Double {
        var totalCounterDmg = 0.0
        for (ally in team) {
            if (AbilitySystem.has(ally, team, repo, "까칠한피부", "독가시", "독치장", "철가시")) {
                val d = enemy.maxHp / 32.0
                enemy.hp = (enemy.hp - d).coerceAtLeast(0.0)
                totalCounterDmg += d
            }
        }
        return totalCounterDmg
    }

    /**
     * 야생 포켓몬의 타입에 맞는 저항 기술 1개를 가중치 추첨하여 실행
     */
    fun executeEnemyResist(
        enemy: WildEnemy,
        team: List<AllyMon>,
        weather: WeatherType?,
        terrain: TerrainType?,
        repo: PokemonRepository
    ): String {
        if (team.isEmpty()) return ""

        val enemyPokemon = repo.getPokemon(enemy.id)
        val enemyTypes = enemyPokemon?.types ?: listOf(1)

        // 적 타입 기술 가중치 4배, 노말 기술은 1배 기본 풀
        val candidates = ALL_RESIST_MOVES.filter { m ->
            m.type in enemyTypes || m.type == 1
        }
        if (candidates.isEmpty()) return ""

        val weightedList = candidates.map { m ->
            val w = m.weight * (if (m.type in enemyTypes) 4.0 else 1.0)
            Pair(m, w)
        }
        val totalWeight = weightedList.sumOf { it.second }
        var r = Random.nextDouble() * totalWeight
        var selectedMove = weightedList.first().first

        for (item in weightedList) {
            r -= item.second
            if (r <= 0.0) {
                selectedMove = item.first
                break
            }
        }

        val effectMsg = selectedMove.action(enemy, team, weather, terrain, repo)
        return "${enemyPokemon?.ko ?: "야생 포켓몬"}의 [${selectedMove.name}]! $effectMsg"
    }

    // 헬퍼 타깃 셀렉터
    private fun pickOne(team: List<AllyMon>): AllyMon? = team.randomOrNull()
    private fun pickTwo(team: List<AllyMon>): List<AllyMon> = team.shuffled().take(2)

    val ALL_RESIST_MOVES: List<ResistMove> = listOf(
        // === 노말 (1) - 상태이상 / 디버프 ===
        ResistMove("울음소리", 1, "동료 전체의 위력이 1단계 떨어졌다!") { _, team, w, _, r ->
            team.forEach { StatusSystem.addRank(it, -1, team, listOf(1), w, r) }
            "동료 전체의 위력이 1단계 떨어졌다!"
        },
        ResistMove("꼬리흔들기", 1, "동료의 위력이 1단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -1, team, listOf(1), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 1단계 떨어졌다!"
            } ?: ""
        },
        ResistMove("싫은소리", 1, "동료의 위력이 2단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -2, team, listOf(1), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 2단계 떨어졌다!"
            } ?: ""
        },
        ResistMove("노래하기", 1, "동료가 잠들어 버렸다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "slp", null, team, listOf(1), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 잠들어 버렸다!"
            } ?: ""
        },
        ResistMove("초음파", 1, "동료가 혼란에 빠졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "cnf", null, team, listOf(1), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 혼란에 빠졌다!"
            } ?: ""
        },
        ResistMove("플래시", 1, "동료의 명중률이 떨어졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "acc", null, team, listOf(1), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 명중률이 떨어졌다!"
            } ?: ""
        },
        ResistMove("겁나는얼굴", 1, "동료가 겁에 질려 느려졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(1), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 겁에 질려 느려졌다!"
            } ?: ""
        },

        // === 노말 (1) - 적 자가 버프 ===
        ResistMove("단단해지기", 1, "자신의 방어가 1단계 올라갔다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.def = (enemy.enemyBuffs.def + 1).coerceAtMost(6)
            enemy.enemyBuffs.defLeft = 40.0
            "자신의 방어가 1단계 올라갔다!"
        },
        ResistMove("비축하기", 1, "자신의 방어와 특수방어가 1단계 올라갔다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.def = (enemy.enemyBuffs.def + 1).coerceAtMost(6)
            enemy.enemyBuffs.spd = (enemy.enemyBuffs.spd + 1).coerceAtMost(6)
            enemy.enemyBuffs.defLeft = 40.0
            enemy.enemyBuffs.spdLeft = 40.0
            "자신의 방어와 특수방어가 1단계 올라갔다!"
        },
        ResistMove("그림자분신", 1, "자신의 회피율이 1단계 올라갔다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.eva = (enemy.enemyBuffs.eva + 1).coerceAtMost(6)
            enemy.enemyBuffs.evaLeft = 40.0
            "자신의 회피율이 1단계 올라갔다!"
        },
        ResistMove("작아지기", 1, "자신의 회피율이 2단계 올라갔다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.eva = (enemy.enemyBuffs.eva + 2).coerceAtMost(6)
            enemy.enemyBuffs.evaLeft = 40.0
            "자신의 회피율이 2단계 올라갔다!"
        },
        ResistMove("리플렉터", 1, "물리 공격을 줄이는 리플렉터를 둘렀다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.screen = "reflect"
            enemy.enemyBuffs.screenLeft = 25.0
            "물리 공격을 줄이는 리플렉터를 둘렀다!"
        },
        ResistMove("빛의장막", 1, "특수 공격을 줄이는 빛의장막을 둘렀다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.screen = "light"
            enemy.enemyBuffs.screenLeft = 25.0
            "특수 공격을 줄이는 빛의장막을 둘렀다!"
        },
        ResistMove("오로라베일", 1, "모든 공격을 반감하는 오로라베일을 둘렀다!", isSelf = true) { enemy, _, _, _, _ ->
            enemy.enemyBuffs.screen = "aurora"
            enemy.enemyBuffs.screenLeft = 25.0
            "모든 공격을 반감하는 오로라베일을 둘렀다!"
        },

        // === 불꽃 (10) ===
        ResistMove("도깨비불", 10, "동료가 화상을 입었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "brn", null, team, listOf(10), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 화상을 입었다!"
            } ?: ""
        },
        ResistMove("열풍", 10, "동료 2마리가 화상을 입었다!") { _, team, w, t, r ->
            pickTwo(team).forEach { StatusSystem.addStatus(it, "brn", null, team, listOf(10), w, t, r) }
            "동료 2마리가 화상을 입었다!"
        },

        // === 물 (11) ===
        ResistMove("찬물끼얹기", 11, "동료의 위력이 2단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -2, team, listOf(11), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 2단계 떨어졌다!"
            } ?: ""
        },
        ResistMove("거품", 11, "동료가 거품에 휘감겨 느려졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(11), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 거품에 휘감겨 느려졌다!"
            } ?: ""
        },
        ResistMove("탁류", 11, "동료 전체의 명중률이 떨어졌다!") { _, team, w, t, r ->
            team.forEach { StatusSystem.addStatus(it, "acc", null, team, listOf(11), w, t, r) }
            "동료 전체의 명중률이 떨어졌다!"
        },

        // === 풀 (12) ===
        ResistMove("수면가루", 12, "동료 2마리가 잠들어 버렸다!") { _, team, w, t, r ->
            pickTwo(team).forEach { StatusSystem.addStatus(it, "slp", null, team, listOf(12), w, t, r) }
            "동료 2마리가 잠들어 버렸다!"
        },
        ResistMove("저리가루", 12, "동료가 마비되었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(12), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 마비되었다!"
            } ?: ""
        },

        // === 전기 (13) ===
        ResistMove("전기자석파", 13, "동료가 마비되었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(13), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 마비되었다!"
            } ?: ""
        },
        ResistMove("방전", 13, "동료 2마리가 마비되었다!") { _, team, w, t, r ->
            pickTwo(team).forEach { StatusSystem.addStatus(it, "par", null, team, listOf(13), w, t, r) }
            "동료 2마리가 마비되었다!"
        },
        ResistMove("괴전파", 13, "동료의 위력이 2단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -2, team, listOf(13), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 2단계 떨어졌다!"
            } ?: ""
        },

        // === 얼음 (15) ===
        ResistMove("얼어붙은바람", 15, "동료 전체가 얼어붙어 느려졌다!") { _, team, w, t, r ->
            team.forEach { StatusSystem.addStatus(it, "par", null, team, listOf(15), w, t, r) }
            "동료 전체가 얼어붙어 느려졌다!"
        },
        ResistMove("절대영도", 15, "동료 2마리가 얼어붙었다!", weight = 0.4) { _, team, w, t, r ->
            pickTwo(team).forEach { StatusSystem.addStatus(it, "frz", null, team, listOf(15), w, t, r) }
            "동료 2마리가 얼어붙었다!"
        },

        // === 격투 (2) ===
        ResistMove("로킥", 2, "동료가 넘어져 느려졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(2), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 넘어져 느려졌다!"
            } ?: ""
        },

        // === 독 (4) ===
        ResistMove("독가루", 4, "동료가 독에 중독되었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "psn", null, team, listOf(4), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 독에 중독되었다!"
            } ?: ""
        },
        ResistMove("맹독", 4, "동료가 맹독에 중독되었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "psn", 40.0, team, listOf(4), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 맹독에 중독되었다!"
            } ?: ""
        },

        // === 땅 (5) ===
        ResistMove("진흙뿌리기", 5, "동료의 명중률이 떨어졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "acc", null, team, listOf(5), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 명중률이 떨어졌다!"
            } ?: ""
        },

        // === 바위 (6) ===
        ResistMove("암석봉인", 6, "동료가 바위에 눌려 느려졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(6), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 바위에 눌려 느려졌다!"
            } ?: ""
        },

        // === 비행 (3) ===
        ResistMove("깃털댄스", 3, "동료의 위력이 2단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -2, team, listOf(3), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 2단계 떨어졌다!"
            } ?: ""
        },

        // === 에스퍼 (14) ===
        ResistMove("최면술", 14, "동료가 잠들어 버렸다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "slp", null, team, listOf(14), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 잠들어 버렸다!"
            } ?: ""
        },

        // === 고스트 (8) ===
        ResistMove("이상한빛", 8, "동료가 혼란에 빠졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "cnf", null, team, listOf(8), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 혼란에 빠졌다!"
            } ?: ""
        },

        // === 벌레 (7) ===
        ResistMove("실뿜기", 7, "동료가 실에 묶여 느려졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(7), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 실에 묶여 느려졌다!"
            } ?: ""
        },

        // === 강철 (9) ===
        ResistMove("금속음", 9, "동료 전체의 위력이 1단계 떨어졌다!") { _, team, w, _, r ->
            team.forEach { StatusSystem.addRank(it, -1, team, listOf(9), w, r) }
            "동료 전체의 위력이 1단계 떨어졌다!"
        },

        // === 드래곤 (16) ===
        ResistMove("용의숨결", 16, "동료가 마비되었다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "par", null, team, listOf(16), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 마비되었다!"
            } ?: ""
        },

        // === 악 (17) ===
        ResistMove("도발", 17, "동료가 도발에 넘어가 혼란해졌다!") { _, team, w, t, r ->
            pickOne(team)?.let {
                StatusSystem.addStatus(it, "cnf", null, team, listOf(17), w, t, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}이(가) 도발에 넘어가 혼란해졌다!"
            } ?: ""
        },

        // === 페어리 (18) ===
        ResistMove("애교부리기", 18, "동료의 위력이 2단계 떨어졌다!") { _, team, w, _, r ->
            pickOne(team)?.let {
                StatusSystem.addRank(it, -2, team, listOf(18), w, r)
                "${r.getPokemon(it.id)?.ko ?: "동료"}의 위력이 2단계 떨어졌다!"
            } ?: ""
        }
    )
}
