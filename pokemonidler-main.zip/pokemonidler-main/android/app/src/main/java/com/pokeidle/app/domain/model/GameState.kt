package com.pokeidle.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 게임의 전체 런타임 및 세이브 상태 (GameState S)
 */
@Serializable
data class GameState(
    var exp: Double = 0.0,                              // 현재 보유 경험치
    var totalL: Double = 0.0,                           // 누적 획득 경험치 (log10)
    var kills: Long = 0L,                               // 처치한 야생 포켓몬 총 수
    var region: Int = 1,                                // 현재 선택된 모험 지역 (1 ~ 9)
    var coins: Long = 0L,
    var balls: Int = 0,                                 // 보유 일반 몬스터볼 개수
    var mballs: Int = 0,                                // 보유 마스터볼 개수
    var pballs: Int = 0,                                // 보유 하이퍼/파크볼 개수
    var shinies: Int = 0,                               // 조우한 이로치 수
    var rpL: Double = -300.0,                           // 보유 환생 포인트 (log10 스케일, -300은 0P)
    var runExp: Double = 0.0,                           // 이번 회차(환생 이후) 누적 경험치
    var rebirths: Int = 0,                              // 총 환생 횟수
    var lastSeenAt: Long = 0L,                          // 마지막 저장 시각(휴면 보상 계산)
    var lastPrestigeAt: Long = 0L,                      // 마지막 환생 시각
    var selectedTitle: String = "",                    // 업적 칭호 선택
    var readingSeconds: Int = 0,                        // 도감/도움말 열람 시간(업적)
    val regionKills: MutableMap<Int, Long> = mutableMapOf(), // 세대별 처치 수(업적)
    var K: Int = 0,                                     // 큰 수 지수 스케일링 오프셋 (10^K)
    var maxLvl: Int = 1,                                // 역대 도달한 최고 적 레벨
    var rt: Double = 20.0,                              // 야생 포켓몬 저항 발동 타이머 잔여 시간(초)
    var rtMax: Double = 30.0,                           // 야생 포켓몬 저항 주기
    var seq: Long = 0L,                                 // 포켓몬 획득 일련번호 시퀀스
    var tv: Int = 2,                                    // 토큰 시스템 버전 (기본 2)
    val team: MutableList<AllyMon> = mutableListOf(),   // 현재 출전 파티 (최대 6마리, slot 0~5)
    val box: MutableList<AllyMon> = mutableListOf(),    // 박스 보관 포켓몬
    val tokens: MutableMap<Int, Int> = mutableMapOf(),  // 도감 번호 -> 보유 증표 개수
    val seen: MutableMap<Int, Int> = mutableMapOf(),    // 도감 번호 -> 조우 횟수
    val caught: MutableMap<Int, Int> = mutableMapOf(),  // 도감 번호 -> 포획 횟수
    val shinySeen: MutableMap<Int, Int> = mutableMapOf(), // 도감 번호 -> 이로치 발견/해금 횟수
    val quests: MutableList<Quest> = mutableListOf(),   // 현재 진행 중인 퀘스트 3종
    val perks: MutableMap<String, Int> = mutableMapOf(),// 환생 특전 레벨 (exp, tok, ball 등)
    val offPerk: MutableMap<String, Boolean> = mutableMapOf(), // 특전 일시 비활성화 토글
    val items: MutableMap<String, Int> = mutableMapOf(), // 보유 도구 (도구 ID -> 보유 스택 수)
    var enemy: WildEnemy? = null                        // 현재 출현한 야생 포켓몬
) {
    /**
     * 특정 도구의 보유 스택 수
     */
    fun getItemStack(itemId: String): Int = items[itemId] ?: 0

    /**
     * 특정 도구를 현재 지니고 있는 포켓몬 탐색
     */
    fun getItemHolder(itemId: String): AllyMon? = (team + box).firstOrNull { it.item == itemId }

    /**
     * 특정 포켓몬의 보유 증표 개수
     */
    fun getTokenCount(pokemonId: Int): Int = tokens[pokemonId] ?: 0

    /**
     * 특정 특전의 유효 레벨 (토글 OFF 상태이면 0 반환)
     */
    fun getEffectivePerk(key: String): Int {
        if (offPerk[key] == true) return 0
        return perks[key] ?: 0
    }

    /**
     * 신규 세이브 시작용 기본 상태 팩토리
     */
    companion object {
        fun createInitial(starterId: Int = 25): GameState {
            val starter = AllyMon(
                id = starterId,
                lvl = 1,
                cd = 1.0,
                move = 33, // 몸통박치기
                ab = 1,
                slot = 0,
                joined = 1L
            )
            return GameState(
                exp = 0.0,
                totalL = 0.0,
                kills = 0L,
                region = 1,
                balls = 5,
                mballs = 0,
                pballs = 0,
                shinies = 0,
                rpL = -300.0,
                runExp = 0.0,
                rebirths = 0,
                K = 0,
                maxLvl = 1,
                rt = 20.0,
                rtMax = 30.0,
                seq = 1L,
                tv = 2,
                team = mutableListOf(starter),
                seen = mutableMapOf(starterId to 1),
                caught = mutableMapOf(starterId to 1),
                enemy = WildEnemy(id = 16, lvl = 1, hp = 100.0, maxHp = 100.0) // 구구
            )
        }
    }
}
