package com.pokeidle.app.presentation.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.pokeidle.app.R

/**
 * Galmuri (갈무리) 폰트 패밀리
 * - 한국어 레트로 픽셀/비트맵 스타일 폰트 (11,172자 완성형 한글, 영문, 특수문자 완벽 지원)
 */
val GalmuriFontFamily = FontFamily(
    Font(R.font.galmuri11, FontWeight.Normal),
    Font(R.font.galmuri11_bold, FontWeight.Bold),
    Font(R.font.galmuri11_bold, FontWeight.SemiBold),
    Font(R.font.galmuri11_bold, FontWeight.ExtraBold),
    Font(R.font.galmuri11, FontWeight.Medium)
)

val Galmuri9FontFamily = FontFamily(
    Font(R.font.galmuri9, FontWeight.Normal),
    Font(R.font.galmuri9, FontWeight.Bold)
)

val Galmuri14FontFamily = FontFamily(
    Font(R.font.galmuri14, FontWeight.Normal),
    Font(R.font.galmuri14, FontWeight.Bold)
)

val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp
    ),
    displayMedium = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp
    ),
    displaySmall = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
    ),
    titleLarge = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
    ),
    titleMedium = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp
    ),
    titleSmall = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp
    ),
    bodySmall = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 10.sp
    ),
    labelLarge = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp
    ),
    labelMedium = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    ),
    labelSmall = TextStyle(
        fontFamily = GalmuriFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 9.sp
    )
)
