package com.pokeidle.app.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val TYPE_COLORS = mapOf(
    1 to Color(0xFF8A8A59),  // 노말
    2 to Color(0xFFB4422A),  // 격투
    3 to Color(0xFF7A93D6),  // 비행
    4 to Color(0xFF8C4A9C),  // 독
    5 to Color(0xFFC9A24D),  // 땅
    6 to Color(0xFF9A8A44),  // 바위
    7 to Color(0xFF8DAD29),  // 벌레
    8 to Color(0xFF5E5B7B),  // 고스트
    9 to Color(0xFF8A8AA4),  // 강철
    10 to Color(0xFFDF6B2C), // 불꽃
    11 to Color(0xFF4A86D8), // 물
    12 to Color(0xFF5AA33C), // 풀
    13 to Color(0xFFD9A81F), // 전기
    14 to Color(0xFFE05A7A), // 에스퍼
    15 to Color(0xFF5FB3C9), // 얼음
    16 to Color(0xFF6A3EC9), // 드래곤
    17 to Color(0xFF5C4A3B), // 악
    18 to Color(0xFFD98AC9)  // 페어리
)

val TYPE_NAMES = mapOf(
    1 to "노말", 2 to "격투", 3 to "비행", 4 to "독",
    5 to "땅", 6 to "바위", 7 to "벌레", 8 to "고스트",
    9 to "강철", 10 to "불꽃", 11 to "물", 12 to "풀",
    13 to "전기", 14 to "에스퍼", 15 to "얼음", 16 to "드래곤",
    17 to "악", 18 to "페어리"
)

@Composable
fun TypeBadge(
    typeId: Int,
    modifier: Modifier = Modifier
) {
    val bgColor = TYPE_COLORS[typeId] ?: Color.Gray
    val typeName = TYPE_NAMES[typeId] ?: "노말"
    val textColor = when (typeId) {
        5, 7, 13, 15, 18 -> Color(0xFF222222)
        else -> Color.White
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = typeName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
