package com.pokeidle.app.data.model

import com.pokeidle.app.domain.model.AllyMon

object ZygardeFusionData {
    const val TEN = 10181
    const val FIFTY = 718
    const val COMPLETE = 10120
    const val SWARM = 211
    val tenIds = setOf(TEN, 10118, 10180)
    val fiftyIds = setOf(FIFTY, 10119)
    val allIds = tenIds + fiftyIds + setOf(COMPLETE, 10301)
    fun resultId(id: Int): Int? = when (id) { in tenIds -> FIFTY; in fiftyIds -> COMPLETE; else -> null }
    fun materials(target: AllyMon, box: List<AllyMon>): List<AllyMon>? {
        val selected = box.firstOrNull { it.joined == target.joined && it.id == target.id } ?: return null
        if (selected.isMega) return null
        val candidates = box.filter { it.joined != selected.joined && !it.isMega }
        return when (selected.id) {
            in tenIds -> candidates.filter { it.id in tenIds }.take(4).takeIf { it.size == 4 }
            in fiftyIds -> candidates.filter { it.id in fiftyIds }.firstOrNull { selected.ab == SWARM || it.ab == SWARM }?.let { listOf(it) }
            else -> null
        }
    }
}
