package com.pokeidle.app.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import kotlinx.coroutines.delay
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.data.model.ZMoveData
import com.pokeidle.app.data.model.CanonicalStatsData
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.presentation.modal.ItemManageDialog
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

@Composable
private fun BriefInfoLabel(
    text: String,
    description: String,
    fontSize: androidx.compose.ui.unit.TextUnit,
    color: Color,
    fontWeight: FontWeight = FontWeight.Normal
) {
    var showTip by remember(text, description) { mutableStateOf(false) }
    LaunchedEffect(showTip) {
        if (showTip) {
            delay(2200)
            showTip = false
        }
    }
    Box {
        Text(
            text = text,
            fontSize = fontSize,
            color = color,
            fontWeight = fontWeight,
            modifier = Modifier.clickable(enabled = description.isNotBlank()) { showTip = true }
        )
        if (showTip && description.isNotBlank()) {
            Popup(alignment = Alignment.TopCenter, onDismissRequest = { showTip = false }) {
                Surface(color = Color(0xFF263238), shape = RoundedCornerShape(6.dp), shadowElevation = 6.dp) {
                    Text(description, color = Color.White, fontSize = 10.sp, modifier = Modifier.widthIn(max = 240.dp).padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun BottomPanel(
    selectedSlot: Int,
    onSelectSlot: (Int) -> Unit,
    gameState: GameState,
    repository: PokemonRepository,
    onLevelUp: (AllyMon, Int) -> Unit,
    onEvolveAlly: (AllyMon, Int) -> Unit,
    onMegaEvolveAlly: (AllyMon) -> Unit,
    onRelieveAlly: (AllyMon) -> Unit,
    onRerollMove: (AllyMon) -> Unit,
    onRerollAbility: (AllyMon) -> Unit,
    onUpgradeTokenSpeed: (AllyMon) -> Unit,
    onFormatAlly: (AllyMon) -> Unit,
    onEquipItem: (AllyMon, String?) -> Boolean,
    onReleaseBoxMon: (AllyMon) -> Unit,
    onSwapParty: (Int, AllyMon) -> Unit,
    recentLogs: List<String>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var allyToFormat by remember { mutableStateOf<AllyMon?>(null) }
    var allyToRelease by remember { mutableStateOf<AllyMon?>(null) }
    var allyToManageItem by remember { mutableStateOf<AllyMon?>(null) }

    val tabs = listOf(
        "동료 팀 (${gameState.team.size}/6)",
        "보관 박스 (${gameState.box.size})",
        "전투 로그"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(androidx.compose.material3.MaterialTheme.colorScheme.surface)
            .border(1.dp, Color(0xFFD3DCD0), RoundedCornerShape(12.dp))
    ) {
        // 1. 탭 메뉴 (동료 팀 / 보관 박스 / 전투 로그)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFFF3F5F0),
            contentColor = Color(0xFF2F7BD9)
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        // 2. 탭 본문 내용
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(8.dp)
        ) {
            when (selectedTab) {
                0 -> TeamTabContent(
                    selectedSlot = selectedSlot,
                    onSelectSlot = onSelectSlot,
                    team = gameState.team,
                    gameState = gameState,
                    repository = repository,
                    onLevelUp = onLevelUp,
                    onEvolveAlly = onEvolveAlly,
                    onMegaEvolveAlly = onMegaEvolveAlly,
                    onRelieveAlly = onRelieveAlly,
                    onRerollMove = onRerollMove,
                    onRerollAbility = onRerollAbility,
                    onUpgradeTokenSpeed = onUpgradeTokenSpeed,
                    onFormatAlly = { allyToFormat = it },
                    onManageItem = { allyToManageItem = it }
                )
                1 -> BoxTabContent(
                    selectedSlot = selectedSlot,
                    box = gameState.box,
                    gameState = gameState,
                    repository = repository,
                    onSwap = onSwapParty,
                    onEvolveAlly = onEvolveAlly,
                    onFormatAlly = { allyToFormat = it },
                    onReleaseBoxMon = { allyToRelease = it }
                )
                2 -> LogTabContent(recentLogs = recentLogs)
            }
        }
    }

    allyToManageItem?.let { ally ->
        ItemManageDialog(
            ally = ally,
            gameState = gameState,
            repository = repository,
            onEquip = { itemId -> onEquipItem(ally, itemId) },
            onDismiss = { allyToManageItem = null }
        )
    }

    // 포맷 확인 팝업 다이얼로그 (재정의: 포켓몬 삭제 및 성장 재화 80% 환급) (요구사항 4 충족)
    if (allyToFormat != null) {
        val ally = allyToFormat!!
        val monDto = repository.getPokemon(ally.id)
        val monName = monDto?.ko ?: "포켓몬"
        val expPerk = gameState.getEffectivePerk("exp")
        val totalExpSpent = BattleMath.calculateTotalExpSpent(ally.lvl, ally.tb, expPerk, gameState.K)
        val refundExp = totalExpSpent * 0.8
        val totalTokensSpent = BattleMath.calculateTotalTokensSpent(ally.tb)
        val refundTokens = (totalTokensSpent * 0.8).toInt()
        val expRefundText = if (refundExp > 0) BattleMath.fmtL(kotlin.math.log10(refundExp) + gameState.K) else "0"

        AlertDialog(
            onDismissRequest = { allyToFormat = null },
            title = {
                Text(
                    text = "⚠ 포켓몬 포맷(환원) 확인",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFFD93A2F)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "[${monName} (Lv.${ally.lvl})]을(를) 정말로 포맷하시겠습니까?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "• 해당 포켓몬은 영구 삭제(방생)됩니다.\n• 지금까지 소모된 성장 재화의 80%가 즉시 환급됩니다:\n  📈 경험치 환급: +${expRefundText} EXP\n  💎 증표 환급: +${refundTokens}개",
                        fontSize = 12.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onFormatAlly(ally)
                        allyToFormat = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F))
                ) {
                    Text("포맷 실행 (삭제 & 80% 환급)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { allyToFormat = null }) {
                    Text("취소")
                }
            }
        )
    }

    // 박스 포켓몬 방생 확인 팝업 다이얼로그
    if (allyToRelease != null) {
        val ally = allyToRelease!!
        val monDto = repository.getPokemon(ally.id)
        val monName = monDto?.ko ?: "포켓몬"
        AlertDialog(
            onDismissRequest = { allyToRelease = null },
            title = {
                Text(
                    text = "방생 확인",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFFD93A2F)
                )
            },
            text = {
                Text(
                    text = "정말로 [${monName} (Lv.${ally.lvl})]을(를) 박스에서 방생(삭제)하시겠습니까?\n방생된 포켓몬은 복구할 수 없습니다.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReleaseBoxMon(ally)
                        allyToRelease = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F))
                ) {
                    Text("방생", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { allyToRelease = null }) {
                    Text("취소")
                }
            }
        )
    }
}

@Composable
fun TeamTabContent(
    selectedSlot: Int,
    onSelectSlot: (Int) -> Unit,
    team: List<AllyMon>,
    gameState: GameState,
    repository: PokemonRepository,
    onLevelUp: (AllyMon, Int) -> Unit,
    onEvolveAlly: (AllyMon, Int) -> Unit,
    onMegaEvolveAlly: (AllyMon) -> Unit,
    onRelieveAlly: (AllyMon) -> Unit,
    onRerollMove: (AllyMon) -> Unit,
    onRerollAbility: (AllyMon) -> Unit,
    onUpgradeTokenSpeed: (AllyMon) -> Unit,
    onFormatAlly: (AllyMon) -> Unit,
    onManageItem: (AllyMon) -> Unit
) {
    val selectedAlly = team.find { it.slot == selectedSlot }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // 상단 슬롯 빠른 전환 칩 버튼 (1번~6번 슬롯)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (i in 0..5) {
                val mon = team.find { it.slot == i }
                val monDto = mon?.let { repository.getPokemon(it.id) }
                val activeMegaForm = mon?.takeIf { it.isMega }?.let { ally ->
                    if (com.pokeidle.app.data.model.GigantamaxFormsData.isForm(ally.megaFormId) || ally.megaFormId == -1) null
                    else repository.getMegas(ally.id).firstOrNull { it.id == ally.megaFormId }
                        ?: if (ally.megaFormId == null) repository.getMegas(ally.id).firstOrNull() else null
                }
                val fusionForm = mon?.takeIf { it.isMega && it.id == 800 }?.let { ally ->
                    repository.getAllFormViews(800).firstOrNull {
                        (ally.megaFormId == 10155 && it.formKey == "necrozma_dusk_mane") ||
                            (ally.megaFormId == 10156 && it.formKey == "necrozma_dawn_wings")
                    }
                }
                val slotSprite = fusionForm?.img ?: activeMegaForm?.img?.takeIf { it.isNotEmpty() } ?: monDto?.img
                val isCurrent = selectedSlot == i

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 60.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onSelectSlot(i) },
                    color = if (isCurrent) Color(0xFF2F7BD9) else Color(0xFFF0F3EC),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (monDto != null && slotSprite != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                PokemonSprite(
                                    imgBase64 = if (mon?.isShiny == true && !mon.isMega) repository.getShinySprite(mon.id) ?: slotSprite else slotSprite,
                                    contentDescription = fusionForm?.fullName ?: if (activeMegaForm != null) "${monDto.ko} 변신 폼" else monDto.ko,
                                    size = if (mon?.item == "max-mushroom" && mon.isMega) 36.dp else 28.dp,
                                    spriteAssetName = mon?.let { ally ->
                                        if (ally.isMega) com.pokeidle.app.data.model.GigantamaxFormsData.getSpriteAssetPathForFormId(ally.megaFormId ?: -1, ally.isShiny)
                                            ?: ally.megaFormId?.let { repository.getPokemonFormSpriteAsset(it, ally.isShiny) }
                                            ?: fusionForm?.let { if (ally.isShiny) it.shinySpriteAssetName else it.spriteAssetName }
                                            ?: activeMegaForm?.let { repository.getPokemonFormSpriteAsset(it.id, ally.isShiny) }
                                        else repository.getPokemonFormSpriteAsset(ally.id, ally.isShiny)
                                    }
                                )
                                Text(
                                    text = "${i + 1}:${monDto.ko.take(2)}",
                                    fontSize = 9.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) Color.White else Color(0xFF5A665E)
                                )
                            }
                        } else {
                            Text(
                                text = "${i + 1}:-",
                                fontSize = 10.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrent) Color.White else Color(0xFF5A665E)
                            )
                        }
                    }
                }
            }
        }

        // 선택된 동료 상세 카드 및 강화/기술/특성 액션
        if (selectedAlly != null) {
            val p = repository.getPokemon(selectedAlly.id)
            val activeMegaForm = if (selectedAlly.isMega) {
                if (com.pokeidle.app.data.model.GigantamaxFormsData.isForm(selectedAlly.megaFormId) || selectedAlly.megaFormId == -1) null
                else repository.getMegas(selectedAlly.id).firstOrNull { it.id == selectedAlly.megaFormId }
                    ?: if (selectedAlly.megaFormId == null) repository.getMegas(selectedAlly.id).firstOrNull() else null
            } else null
            val fusionForm = if (selectedAlly.isMega && selectedAlly.id == 800) repository.getAllFormViews(800).firstOrNull {
                (selectedAlly.megaFormId == 10155 && it.formKey == "necrozma_dusk_mane") ||
                    (selectedAlly.megaFormId == 10156 && it.formKey == "necrozma_dawn_wings")
            } else null
            val selectedSprite = fusionForm?.img ?: activeMegaForm?.img?.takeIf { it.isNotEmpty() } ?: p?.img
            val liveStats = CanonicalStatsData.getActiveFormStat(selectedAlly)
            val statHp = liveStats?.hp ?: fusionForm?.hp ?: activeMegaForm?.hp ?: p?.hp ?: 0
            val dynamaxMultiplier = if (selectedAlly.isMega && com.pokeidle.app.data.model.GigantamaxFormsData.isForm(selectedAlly.megaFormId)) 1.5 else 1.0
            val statAtk = ((liveStats?.atk ?: fusionForm?.atk ?: activeMegaForm?.atk ?: p?.atk ?: 0) * dynamaxMultiplier).toInt()
            val statDef = liveStats?.def ?: fusionForm?.def ?: activeMegaForm?.def ?: p?.def ?: 0
            val statSpa = ((liveStats?.spa ?: fusionForm?.spa ?: activeMegaForm?.spa ?: p?.spa ?: 0) * dynamaxMultiplier).toInt()
            val statSdf = liveStats?.sdf ?: fusionForm?.sdf ?: activeMegaForm?.sdf ?: p?.sdf ?: 0
            val statSpd = liveStats?.spd ?: fusionForm?.spd ?: activeMegaForm?.spd ?: p?.spd ?: 0
            val activeFormLabel = when {
                com.pokeidle.app.data.model.GigantamaxFormsData.isForm(selectedAlly.megaFormId) -> "거다이맥스"
                selectedAlly.isMega && selectedAlly.megaFormId == 10301 -> "메가폼"
                fusionForm != null -> fusionForm.label
                activeMegaForm != null -> activeMegaForm.label ?: "메가폼"
                selectedAlly.id == 10120 -> "퍼펙트폼"
                selectedAlly.id in com.pokeidle.app.data.model.ZygardeFusionData.fiftyIds -> "50%폼"
                selectedAlly.id in com.pokeidle.app.data.model.ZygardeFusionData.tenIds -> "10%폼"
                else -> "기본폼"
            }
            val ultraBurstZMoveActive = selectedAlly.item == "ultranecrozium-z" && selectedAlly.id == 800 && selectedAlly.isMega && selectedAlly.megaFormId == 10157 && selectedAlly.move == 722
            val move = if (ultraBurstZMoveActive) com.pokeidle.app.data.model.MoveDto(t = 14, p = 200.0, c = 3, ko = "하늘을 태우는 멸망의 빛")
            else if (selectedAlly.id == 10117 || (selectedAlly.isMega && selectedAlly.megaFormId == 10117)) com.pokeidle.app.data.model.MoveDto(t = 11, p = 90.0, c = 3, ko = "물수리검") else repository.getBattleMove(selectedAlly)
            val activeZMove = if ((selectedAlly.status.zMoveDuration > 0.0 || ultraBurstZMoveActive) && move != null) {
                selectedAlly.item?.let { itemId -> ZMoveData.resolve(itemId, selectedAlly.id, selectedAlly.move, move.t, move.p, selectedAlly.megaFormId) }
            } else null
            val hasZCrystal = selectedAlly.item?.let { repository.getHeldItem(it)?.category == "z-crystals" } == true
            val ab = repository.getAbility(repository.getBattleAbilityId(selectedAlly))
            val chainId = p?.chain ?: selectedAlly.id
            val tokens = gameState.getTokenCount(chainId)
            val tkCost = BattleMath.tkCost(selectedAlly.tb)

            // 레벨업 비용 계산
            val expPerk = gameState.getEffectivePerk("exp")
            val costL1 = BattleMath.levelUpCostL(selectedAlly.lvl, selectedAlly.tb, expPerk)
            val cost1 = 10.0.pow(min(300.0, max(0.0, costL1) - gameState.K))
            val canLvl1 = gameState.exp >= cost1

            val costL10 = BattleMath.levelUpCostL(selectedAlly.lvl + 9, selectedAlly.tb, expPerk)
            val cost10 = 10.0.pow(min(300.0, max(0.0, costL10) - gameState.K))
            val canLvl10 = gameState.exp >= cost10 || canLvl1

            // 진화 가능 옵션 판정
            val evoOptions = p?.evo?.filter { it.size >= 2 && selectedAlly.lvl >= it[1] } ?: emptyList()

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFD9E2D6), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                // 포켓몬 정보 헤더
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selectedSprite != null) {
                            PokemonSprite(
                                imgBase64 = if (selectedAlly.isShiny && !selectedAlly.isMega) repository.getShinySprite(selectedAlly.id) ?: selectedSprite else selectedSprite,
                                contentDescription = fusionForm?.fullName ?: if (activeMegaForm != null) "${p?.ko ?: "포켓몬"} 변신 폼" else p?.ko ?: "동료 포켓몬",
                                size = 46.dp,
                                spriteAssetName = if (selectedAlly.isMega) {
                                    com.pokeidle.app.data.model.GigantamaxFormsData.getSpriteAssetPathForFormId(selectedAlly.megaFormId ?: -1, selectedAlly.isShiny)
                                        ?: selectedAlly.megaFormId?.let { repository.getPokemonFormSpriteAsset(it, selectedAlly.isShiny) }
                                        ?: fusionForm?.let { if (selectedAlly.isShiny) it.shinySpriteAssetName else it.spriteAssetName }
                                        ?: activeMegaForm?.let { repository.getPokemonFormSpriteAsset(it.id, selectedAlly.isShiny) }
                                } else repository.getPokemonFormSpriteAsset(selectedAlly.id, selectedAlly.isShiny)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            // 이름, 레벨, 타입 배지 (선명한 다크 색상 지정)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = p?.ko ?: "동료 포켓몬",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Lv.${selectedAlly.lvl}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF2F7BD9),
                                    fontWeight = FontWeight.Bold
                                )
                                (fusionForm?.types ?: activeMegaForm?.types?.takeIf { it.isNotEmpty() } ?: p?.types)?.forEach { typeId ->
                                    TypeBadge(typeId = typeId)
                                }
                            }

                            // 기술 이름 및 기술 타입 배지
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                if (move != null) {
                                    TypeBadge(typeId = move.t)
                                }
                                BriefInfoLabel(
                                    text = if (activeZMove != null && move != null) {
                                        "${activeZMove.name} (위력 ${activeZMove.power.toInt()}${if (ultraBurstZMoveActive) ", 울트라버스트 중" else ", ${selectedAlly.status.zMoveDuration.toInt()}초"})"
            } else if (com.pokeidle.app.data.model.GigantamaxFormsData.isForm(selectedAlly.megaFormId) && move != null) {
                "${com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMoveName(move.t)} (위력 ${com.pokeidle.app.data.model.GigantamaxFormsData.getTransformedMovePower(move.t, move.p).toInt()})"
                                    } else {
                                        "${move?.ko ?: "몸통박치기"} (위력 ${move?.p?.toInt() ?: 40})"
                                    },
                                    description = move?.txt.orEmpty(),
                                    fontSize = 11.sp,
                                    color = Color(0xFF5A665E)
                                )
                                if (move != null && move.c in 2..3) {
                                    Surface(
                                        color = if (move.c == 2) Color(0xFFE8ECE5) else Color(0xFFE7E9FA),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (move.c == 2) "물리" else "특수",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (move.c == 2) Color(0xFF49534B) else Color(0xFF555AA4),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            if (hasZCrystal && selectedAlly.item != "ultranecrozium-z") {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.fillMaxWidth().padding(top = 3.dp)
                                ) {
                                    Text(
                                        text = if (selectedAlly.status.zMoveDuration > 0.0) "Z기술 ${selectedAlly.status.zMoveDuration.toInt()}초" else "Z게이지 ${selectedAlly.mg.toInt()}%",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF8E5BD1)
                                    )
                                    LinearProgressIndicator(
                                        progress = { (if (selectedAlly.status.zMoveDuration > 0.0) selectedAlly.status.zMoveDuration / 10.0 else selectedAlly.mg / 100.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(3.dp)),
                                        color = Color(0xFF8E5BD1),
                                        trackColor = Color(0xFFE7DFF2)
                                    )
                                }
                            }

                            // 특성 및 보유 증표 배지
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Surface(
                                    color = Color(0xFF8E5BD1).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    BriefInfoLabel(
                                        text = "특성: ${ab?.ko ?: "없음"}",
                                        description = ab?.txt.orEmpty(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF8E5BD1)
                                    )
                                }
                                Surface(
                                    color = Color(0xFF2F7BD9).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "💎 증표: ${tokens}개",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2F7BD9),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                if (selectedAlly.tb > 0) {
                                    Text(
                                        text = "◆${selectedAlly.tb}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF8E5BD1)
                                    )
                                }
                                if (selectedAlly.rb > 0) {
                                    Text(
                                        text = "★${selectedAlly.rb}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE08A1B)
                                    )
                                }
                            }
                        }
                    }

                    // 상태 치료 및 메가진화 버튼
                    Column(horizontalAlignment = Alignment.End) {
                        if (selectedAlly.status.hasAilment || selectedAlly.status.rank < 0) {
                            Button(
                                onClick = { onRelieveAlly(selectedAlly) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.heightIn(min = 30.dp)
                            ) {
                                Text("🩹 상태 치료", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                        }
                        val canMega = (selectedAlly.id in setOf(384, 1027) && selectedAlly.move == 620) || (selectedAlly.id == 383 && selectedAlly.item == "red-orb") || (selectedAlly.id == 382 && selectedAlly.item == "blue-orb") || (selectedAlly.id == 658 && selectedAlly.ab == 210) || (selectedAlly.item == "max-mushroom" && com.pokeidle.app.data.model.GigantamaxFormsData.canGigantamax(selectedAlly.id)) ||
                                (selectedAlly.item == "ultranecrozium-z" && selectedAlly.id == 800) ||
                                (selectedAlly.id !in setOf(382, 383) && selectedAlly.item?.let { repository.getHeldItem(it)?.category == "mega-stones" } == true &&
                                        repository.getMegas(selectedAlly.id).isNotEmpty())
                        val ultraBurstReady = selectedAlly.item == "ultranecrozium-z" && selectedAlly.id == 800 &&
                                selectedAlly.isMega && selectedAlly.megaFormId in setOf(10155, 10156)
                        if ((canMega && !selectedAlly.isMega && selectedAlly.mg >= 100.0) || ultraBurstReady) {
                            Button(
                                onClick = { onMegaEvolveAlly(selectedAlly) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.heightIn(min = 30.dp)
                            ) {
                                val transformLabel = when (selectedAlly.item) {
                                    "max-mushroom" -> if (selectedAlly.id == 890) "🍄 무한다이맥스!" else "🍄 거다이맥스!"
                                    "ultranecrozium-z" -> "🌟 울트라버스트!"
                                    "red-orb", "blue-orb" -> "✨ 원시회귀!"
                                    else -> "✨ 메가진화!"
                                }
                                Text(transformLabel, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // 현재 폼을 기준으로 종족치를 실시간 표시한다.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("종족치 · $activeFormLabel", fontSize = 9.sp, color = Color(0xFF5A665E), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatValueCell("HP", statHp, Modifier.weight(1f))
                            StatValueCell("공격", statAtk, Modifier.weight(1f), highlighted = statAtk >= statSpa)
                            StatValueCell("DEF", statDef, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatValueCell("특공", statSpa, Modifier.weight(1f), highlighted = statSpa >= statAtk)
                            StatValueCell("특방", statSdf, Modifier.weight(1f))
                            StatValueCell("스피드", statSpd, Modifier.weight(1f))
                        }
                    }
                }

                // 진화 가능 옵션 버튼 행 (진화 레벨 도달 시 노출)
                if (evoOptions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        evoOptions.forEach { evoPair ->
                            val toId = evoPair[0]
                            val toDto = repository.getPokemon(toId)
                            Button(
                                onClick = { onEvolveAlly(selectedAlly, toId) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1)),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = "✨ 진화 → ${toDto?.ko ?: "진화"}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 도구 및 레벨업 동작을 시안처럼 4열 첫 행에 정렬
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { onManageItem(selectedAlly) },
                        modifier = Modifier.weight(1.05f).heightIn(min = 38.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                    ) {
                        Text(selectedAlly.item?.let { repository.getHeldItem(it)?.ko } ?: "🎒 도구", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    Button(
                        onClick = { onLevelUp(selectedAlly, 1) },
                        enabled = canLvl1,
                        modifier = Modifier
                            .weight(0.95f)
                            .heightIn(min = 38.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))
                    ) {
                        Text(
                            text = "레벨업 1",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onLevelUp(selectedAlly, 10) },
                        enabled = canLvl10,
                        modifier = Modifier
                            .weight(0.95f)
                            .heightIn(min = 38.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))
                    ) {
                        Text(
                            text = "+10 Lv",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onLevelUp(selectedAlly, 999999) },
                        enabled = canLvl1,
                        modifier = Modifier
                            .weight(1.1f)
                            .heightIn(min = 40.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3CAE5C))
                    ) {
                        Text(
                        text = "레벨업 MAX",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 특성/기술 변경, 강화, 판매를 두 번째 행에 정렬
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // 영구 강화 ◆
                    Button(
                        onClick = { onUpgradeTokenSpeed(selectedAlly) },
                        enabled = tokens >= tkCost,
                        modifier = Modifier.weight(1f).heightIn(min = 36.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))
                    ) {
                        Text("강화 ◆${tkCost}", fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    // 특성 바꾸기 💎1
                    Button(
                        onClick = { onRerollAbility(selectedAlly) },
                        enabled = tokens >= 1 && (p?.abil?.size ?: 0) > 1,
                        modifier = Modifier.weight(1f).heightIn(min = 36.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                    ) {
                        Text("특성 변경", fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    // 기술 바꾸기 💎1
                    Button(
                        onClick = { onRerollMove(selectedAlly) },
                        enabled = tokens >= 1 && (p?.moves?.size ?: 0) > 1,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 36.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                    ) {
                        Text("기술 변경", fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    // 포맷 (영구 삭제 및 성장 재화 80% 환급)
                    OutlinedButton(
                        onClick = { onFormatAlly(selectedAlly) },
                        enabled = selectedAlly.id !in setOf(1026, 1027),
                        modifier = Modifier
                            .weight(0.85f)
                            .heightIn(min = 36.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD93A2F))
                    ) {
                        Text("포맷", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "슬롯 ${selectedSlot + 1}이 비어 있습니다.\n보관 박스 탭에서 동료를 선택하여 배치하세요.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun StatValueCell(name: String, value: Int, modifier: Modifier = Modifier, highlighted: Boolean = false) {
    Surface(
        modifier = modifier,
        color = Color.White,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD9E2D6))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val textColor = if (highlighted) Color(0xFFD93025) else androidx.compose.material3.MaterialTheme.colorScheme.onSurface
            Text(name, fontSize = 8.sp, color = textColor, fontWeight = FontWeight.Bold)
            Text(value.toString(), fontSize = 10.sp, color = textColor, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * 보관 박스 탭 (요구사항 1, 2, 4 충족)
 * - 자동으로 도감 번호(id) 순으로 오름차순 정렬
 * - 돋보기 아이콘을 통한 실시간 포켓몬 이름/도감번호 검색
 * - 컴팩트하고 깔끔한 카드 레이아웃으로 텍스트 수직 나열 및 세로 확장 버그 원천 해결
 */
@Composable
fun BoxTabContent(
    selectedSlot: Int,
    box: List<AllyMon>,
    gameState: GameState,
    repository: PokemonRepository,
    onSwap: (Int, AllyMon) -> Unit,
    onEvolveAlly: (AllyMon, Int) -> Unit,
    onFormatAlly: (AllyMon) -> Unit,
    onReleaseBoxMon: (AllyMon) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var fusionTarget by remember { mutableStateOf<AllyMon?>(null) }
    fusionTarget?.let { target ->
        AlertDialog(onDismissRequest = { fusionTarget = null }, title = { Text("지가르데 합체") },
            text = { Text("선택한 개체를 유지하고 나머지 재료 개체를 소모합니다. 선택한 개체의 이로치 여부·레벨·기술이 유지됩니다. 합체 후 되돌릴 수 없습니다.") },
            confirmButton = { TextButton(onClick = { com.pokeidle.app.data.model.ZygardeFusionData.resultId(target.id)?.let { onEvolveAlly(target, it) }; fusionTarget = null }) { Text("합체") } },
            dismissButton = { TextButton(onClick = { fusionTarget = null }) { Text("취소") } })
    }

    // 1. 도감 번호별 자동 정렬 + 실시간 이름/번호 검색 필터 (요구사항 1, 2 충족)
    val sortedAndFilteredBox = remember(box, searchQuery) {
        box.sortedBy { it.id }.filter { ally ->
            if (searchQuery.isBlank()) true
            else {
                val p = repository.getPokemon(ally.id)
                val m = repository.getMove(ally.move)
                val ab = repository.getAbility(repository.getBattleAbilityId(ally))
                val q = searchQuery.trim().lowercase()
                (p?.ko?.lowercase()?.contains(q) == true) ||
                (p?.en?.lowercase()?.contains(q) == true) ||
                (p?.id?.toString() == q) ||
                (m?.ko?.lowercase()?.contains(q) == true) ||
                (ab?.ko?.lowercase()?.contains(q) == true)
            }
        }
    }

    if (box.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("보관 박스가 비어 있습니다. 야생 포켓몬을 쓰러뜨려 포획해보세요!", color = Color.Gray, fontSize = 12.sp)
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // 상단 안내 & 돋보기 포켓몬 검색창 (요구사항 2 충족)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text("포켓몬 이름 또는 도감 번호 검색...", fontSize = 11.sp, color = Color.Gray)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "돋보기 검색",
                        tint = Color(0xFF2F7BD9),
                        modifier = Modifier.size(16.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "지우기", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2F7BD9),
                    unfocusedBorderColor = Color(0xFFD3DCD0),
                    focusedContainerColor = Color(0xFFF9FAF7),
                    unfocusedContainerColor = Color(0xFFF9FAF7)
                )
            )

            Text(
                text = "${sortedAndFilteredBox.size} / ${box.size}마리",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF5A665E)
            )
        }

        Text(
            text = "선택된 슬롯: ${selectedSlot + 1}번 자리 (원하는 포켓몬의 [출전]을 누르세요 · 도감 번호순 정렬됨)",
            fontSize = 10.sp,
            color = Color(0xFF2F7BD9),
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        if (sortedAndFilteredBox.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("검색 결과가 없습니다.", color = Color.Gray, fontSize = 12.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                itemsIndexed(sortedAndFilteredBox, key = { index, mon ->
                    if (mon.joined > 0L) "${mon.id}_${mon.joined}_$index" else "${mon.id}_$index"
                }) { _, ally ->
                    val p = repository.getPokemon(ally.id)
                    val move = repository.getMove(ally.move)
                    val ab = repository.getAbility(repository.getBattleAbilityId(ally))
                    val chainId = p?.chain ?: ally.id
                    val tokens = gameState.getTokenCount(chainId)
                    val evoOptions = p?.evo?.filter { it.size >= 2 && ally.lvl >= it[1] } ?: emptyList()

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFE2E7DF), RoundedCornerShape(8.dp))
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // 좌측: 스프라이트 + [이름 / 타입 / 기술 / 특성] 4단 개행 및 횡스크롤
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (p != null) {
                                PokemonSprite(imgBase64 = if (ally.isShiny) repository.getShinySprite(ally.id) ?: p.img else p.img, contentDescription = p.ko, size = 42.dp,
                                    spriteAssetName = repository.getPokemonFormSpriteAsset(if (ally.isMega) ally.megaFormId ?: ally.id else ally.id, ally.isShiny))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                // 1. 포켓몬 이름 & 레벨 & 배지 (길면 횡스크롤)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = p?.ko ?: "포켓몬",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                        softWrap = false
                                    )
                                    Text(
                                        text = "Lv.${ally.lvl}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF2F7BD9),
                                        fontWeight = FontWeight.Bold,
                                        softWrap = false
                                    )
                                    if (tokens > 0) {
                                        Text("💎${tokens}", fontSize = 9.sp, color = Color(0xFF8E5BD1), fontWeight = FontWeight.Bold, softWrap = false)
                                    }
                                    if (ally.tb > 0) {
                                        Text("◆${ally.tb}", fontSize = 9.sp, color = Color(0xFF2F7BD9), fontWeight = FontWeight.Bold, softWrap = false)
                                    }
                                    if (ally.rb > 0) {
                                        Text("★${ally.rb}", fontSize = 9.sp, color = Color(0xFFE08A1B), fontWeight = FontWeight.Bold, softWrap = false)
                                    }
                                }

                                // 2. 타입 배지 행 (이름 아래칸에 단독 개행)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    p?.types?.forEach { typeId ->
                                        TypeBadge(typeId = typeId)
                                    }
                                }

                                // 3. 기술 (길면 횡스크롤)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "기술: ${move?.ko ?: "몸통박치기"}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF5A665E),
                                        softWrap = false
                                    )
                                }

                                // 4. 특성 (길면 횡스크롤)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "특성: ${ab?.ko ?: "없음"}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF8E5BD1),
                                        softWrap = false
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(4.dp))

                        // 우측: 박스 액션 버튼군 (출전, 진화, 포맷, 방생)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { onSwap(selectedSlot, ally) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3CAE5C))
                            ) {
                                Text("출전", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            // 진화 버튼 (진화 레벨 도달 시)
                            if (com.pokeidle.app.data.model.ZygardeFusionData.resultId(ally.id) != null) {
                                Button(onClick = { fusionTarget = ally }, enabled = com.pokeidle.app.data.model.ZygardeFusionData.materials(ally, box) != null,
                                    contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.heightIn(min = 30.dp)) {
                                    Text(if (ally.id in com.pokeidle.app.data.model.ZygardeFusionData.tenIds) "5마리 합체" else "2마리 합체", fontSize = 10.sp)
                                }
                            }
                            if (evoOptions.isNotEmpty()) {
                                evoOptions.forEach { evoPair ->
                                    val toId = evoPair[0]
                                    val toDto = repository.getPokemon(toId)
                                    Button(
                                        onClick = { onEvolveAlly(ally, toId) },
                                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                                    ) {
                                        Text(
                                            text = if (evoOptions.size > 1) "진화(${toDto?.ko?.take(2) ?: ""})" else "진화",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = { onFormatAlly(ally) },
                                enabled = ally.id !in setOf(1026, 1027),
                                contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE08A1B))
                            ) {
                                Text("포맷", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogTabContent(recentLogs: List<String>) {
    if (recentLogs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("전투 기록이 없습니다.", color = Color.Gray)
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        reverseLayout = true
    ) {
        items(recentLogs.reversed()) { logMsg ->
            Text(
                text = logMsg,
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            )
        }
    }
}
