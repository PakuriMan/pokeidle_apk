package com.pokeidle.app.domain.system

import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.WildEnemy
import kotlin.math.pow
import kotlin.random.Random

/**
 * 100+종 구현 특성(IMPL) 및 효과 연산 시스템
 */
object AbilitySystem {

    // 특성 효과 완전 무효화 특성 (최우선 적용: 파티 내 다른 동료의 모든 특성을 무효화)
    val SUPPRESSORS = setOf("가시지않는향기", "미라", "떠도는영혼", "화학변화가스")

    /**
     * 동료의 유효 특성명 조회
     * - 파티에 SUPPRESSORS 특성을 가진 다른 동료가 있으면 null 반환 (무효화)
     * - 리시버 / 과학의힘인 경우 다음 슬롯 동료의 특성을 복사
     */
    fun getEffectiveAbilityName(
        ally: AllyMon,
        team: List<AllyMon>,
        repo: PokemonRepository
    ): String? {
        val rawName = repo.getAbility(repo.getBattleAbilityId(ally))?.ko ?: return null

        // 무효화 특성 보유 동료가 있는지 확인 (자신 제외)
        val hasSuppressor = team.any { other ->
            if (other === ally) false
            else {
                val otherRaw = repo.getAbility(repo.getBattleAbilityId(other))?.ko
                otherRaw in SUPPRESSORS
            }
        }
        if (hasSuppressor) return null

        // 리시버 / 과학의힘 (다음 자리 동료의 특성 복사)
        if (rawName == "리시버" || rawName == "과학의힘") {
            val others = team.filter { it !== ally }
            if (others.isEmpty()) return rawName
            // 원형 슬롯 기준 바로 다음 슬롯 탐색
            val next = others.minByOrNull { (it.slot - ally.slot + 6) % 6 } ?: return rawName
            val nextRaw = repo.getAbility(repo.getBattleAbilityId(next))?.ko
            return if (nextRaw == "리시버" || nextRaw == "과학의힘") null else nextRaw
        }

        return rawName
    }

    /**
     * 특정 포켓몬이 지정된 특성 중 하나를 보유하고 있는지 확인
     */
    fun has(
        ally: AllyMon,
        team: List<AllyMon>,
        repo: PokemonRepository,
        vararg abilityNames: String
    ): Boolean {
        val effective = getEffectiveAbilityName(ally, team, repo) ?: return false
        return effective in abilityNames
    }

    /**
     * 파티원 중 누군가가 지정된 특성 중 하나를 보유하고 있는지 확인
     */
    fun teamHas(
        team: List<AllyMon>,
        repo: PokemonRepository,
        vararg abilityNames: String
    ): Boolean {
        return team.any { has(it, team, repo, *abilityNames) }
    }

    /**
     * 공격 주기 배율 계산 (abilityIvMult)
     * 값이 작을수록 더 빠르게 공격함
     */
    fun getSpeedMultiplier(
        ally: AllyMon,
        team: List<AllyMon>,
        weather: WeatherType?,
        terrain: TerrainType?,
        repo: PokemonRepository
    ): Double {
        var m = 1.0
        val ab = getEffectiveAbilityName(ally, team, repo)

        if (ab in setOf("가속", "곡예")) m *= 2.0 / 3.0
        if (ab in setOf("게으름", "슬로스타트")) m *= 2.0
        if (ab == "균사의힘") m *= 1.5

        if (ab == "건조피부") {
            if (weather == WeatherType.SUN || weather == WeatherType.HARD_SUN) m *= 1.5
            else if (weather == WeatherType.RAIN || weather == WeatherType.HARD_RAIN) m *= 2.0 / 3.0
        }

        if (ab == "눈치우기" && weather == WeatherType.SNOW) m *= 0.5
        if (ab == "모래헤치기" && weather == WeatherType.SAND) m *= 0.5

        // 상태이상 / 버프에 따른 주기 변화
        val s = ally.status
        if (s.wb > 0) m *= 0.5 // 깨어진갑옷
        if (s.shell > 0) m *= 2.0 / 3.0 // 분노의껍질
        if (ab == "불굴의마음" && s.rank < 0) m *= 2.0 / 3.0
        if (ab == "서핑테일" && terrain == TerrainType.ELECTRIC) m *= 0.5
        if (ab == "속보" && s.hasAilment) m *= 0.5
        if (ab == "쓱쓱" && (weather == WeatherType.RAIN || weather == WeatherType.HARD_RAIN)) m *= 0.5

        // 어써러셔(968) + 사령탑
        if (ally.id == 968) {
            if (team.any { it !== ally && has(it, team, repo, "사령탑") }) {
                m *= 0.5
            }
        }

        // 다른 동료의 솜털
        if (team.any { it !== ally && has(it, team, repo, "솜털") }) {
            m *= 1.5
            if (team.any { it !== ally && it.item == "ability-patch" && has(it, team, repo, "솜털") }) m *= 1.1
        }

        if (ab == "엽록소" && (weather == WeatherType.SUN || weather == WeatherType.HARD_SUN)) m *= 0.5
        if (s.steamEngine) m *= 0.15 // 증기기관
        if (s.quickDraw) m *= 0.1   // 퀵드로

        // 특성패치: 해당 포켓몬의 특성 효과 배율을 1.1배 (페널티 포함)
        if (ally.item == "ability-patch" && ab != null && m != 1.0) m *= 1.1

        return m
    }

    /**
     * 기술 위력 및 공격 데미지 배율 계산 (abilityDmgMult)
     */
    fun getDamageMultiplier(
        ally: AllyMon,
        moveType: Int,
        team: List<AllyMon>,
        weather: WeatherType?,
        terrain: TerrainType?,
        repo: PokemonRepository
    ): Double {
        var m = 1.0
        val ab = getEffectiveAbilityName(ally, team, repo)
        val s = ally.status
        val isSunny = weather == WeatherType.SUN || weather == WeatherType.HARD_SUN

        if (ab == "강철술사" && moveType == 9) m *= 1.5
        if (moveType == 9 && teamHas(team, repo, "강철정신")) {
            m *= 1.5
            if (team.any { it.item == "ability-patch" && has(it, team, repo, "강철정신") }) m *= 1.1
        }
        if (ab == "고대활성" && isSunny) m *= 1.3
        if (team.any { it !== ally && has(it, team, repo, "공생") }) m *= 1.1
        if (ab == "그대로꿀꺽미사일") m *= 1.1
        if (ab == "근성" && s.hasAilment) m *= 2.0
        if (ab == "급류" && moveType == 11) m *= 1.2
        if (ab == "노말스킨") m *= 1.2
        if (ab in setOf("다운로드", "단단한발톱")) m *= 1.2
        if (moveType == 17 && teamHas(team, repo, "다크오라")) {
            m *= 1.33
            if (team.any { it.item == "ability-patch" && has(it, team, repo, "다크오라") }) m *= 1.1
        }
        if (teamHas(team, repo, "대접")) {
            m *= 1.1
            if (team.any { it.item == "ability-patch" && has(it, team, repo, "대접") }) m *= 1.1
        }
        if (ab == "독폭주" && s.psn > 0) m *= 2.0

        // 플러스 & 마이너스 시너지
        if (ab in setOf("플러스", "마이너스") && team.any { it !== ally && has(it, team, repo, "플러스", "마이너스") }) {
            m *= 1.5
        }

        if (ab in setOf("매직미러", "미러아머")) m *= 1.1
        if (ab == "맹화" && moveType == 10) m *= 1.2
        if (ab == "모래의힘" && weather == WeatherType.SAND) m *= 1.3
        if (ab == "무기력") m *= 0.66
        if (ab in setOf("무아지경", "의욕")) m *= 1.5
        if (ab == "바위나르기" && moveType == 6) m *= 1.5

        if (s.angerPoint || s.rage > 0) m *= 1.5
        if (s.shell > 0) m *= 1.5
        if (s.kill > 0) m *= 1.5 // 백의울음/흑의울음/자기과신 등
        if (teamHas(team, repo, "배터리")) m *= 1.3
        if (ab == "벌레의알림" && moveType == 7) m *= 1.2
        if (ab == "심록" && moveType == 12) m *= 1.2
        if (ab == "부자유친") m *= 1.5
        if (ab == "선파워" && isSunny) m *= 1.3
        if (ab == "수포" && moveType == 11) m *= 2.0
        if (ab in setOf("순수한힘", "천하장사")) m *= 2.0
        if (ab == "스카이스킨" && moveType == 3) m *= 1.2
        if (ab in setOf("승기", "오기") && s.rank < 0) m *= 2.0

        if (ally.id == 968 && team.any { it !== ally && has(it, team, repo, "사령탑") }) {
            m *= 2.0
        }
        if (team.any { it !== ally && has(it, team, repo, "솜털") }) {
            m *= 0.85
            if (team.any { it !== ally && it.item == "ability-patch" && has(it, team, repo, "솜털") }) m *= 1.1
        }
        if (ab == "열폭주" && s.brn > 0) m *= 2.0
        if (ab in setOf("예리함", "옹골찬턱", "우격다짐")) m *= 1.3
        if (ab == "용의턱" && moveType == 16) m *= 1.5
        if (ab == "트랜지스터" && moveType == 13) m *= 1.3
        if (ab in setOf("이판사판", "철주먹")) m *= 1.2
        if (ab == "일렉트릭스킨" && moveType == 13) m *= 1.2
        if (ab == "초상투영" && ally.id == 1017) m *= 1.5
        if (ab == "총대장") {
            val emptySlots = (6 - team.size).coerceAtLeast(0)
            m *= 1.2.pow(emptySlots.toDouble())
        }
        if (ab == "쿼크차지" && terrain == TerrainType.ELECTRIC) m *= 1.3
        if (teamHas(team, repo, "파워스폿")) m *= 1.2
        if (moveType == 18 && teamHas(team, repo, "페어리오라")) m *= 1.33
        if (isSunny && teamHas(team, repo, "플라워기프트")) m *= 1.3

        // 특성패치: 해당 포켓몬의 특성 효과 배율을 1.1배 (페널티 포함)
        if (ally.item == "ability-patch" && ab != null && m != 1.0) m *= 1.1

        return m
    }

    /**
     * 기술 변환 특성(노말스킨, 스카이스킨, 일렉트릭스킨) 적용 후 최종 기술 타입
     */
    fun getEffectiveMoveType(
        ally: AllyMon,
        baseMoveType: Int,
        team: List<AllyMon>,
        repo: PokemonRepository
    ): Int {
        val ab = getEffectiveAbilityName(ally, team, repo)
        return when {
            ab == "노말스킨" -> 1 // 노말 타입
            ab == "스카이스킨" && baseMoveType == 1 -> 3 // 비행 타입
            ab == "일렉트릭스킨" && baseMoveType == 1 -> 13 // 전기 타입
            else -> baseMoveType
        }
    }

    /**
     * 야생 적의 저항 공격에 대해 동료가 완전 무효화(면역) 판정을 받는지 여부
     */
    fun isResistImmune(
        ally: AllyMon,
        enemyTypes: List<Int>,
        team: List<AllyMon>,
        weather: WeatherType?,
        repo: PokemonRepository
    ): String? {
        val ab = getEffectiveAbilityName(ally, team, repo) ?: return null

        if (ab == "꾸덕꾸덕굳기" && 11 in enemyTypes) return ab
        if (ab in setOf("내열", "노릇노릇바디", "타오르는불꽃") && 10 in enemyTypes) return ab
        if (ab == "두꺼운지방" && (10 in enemyTypes || 15 in enemyTypes)) return ab
        if (ab in setOf("눈숨기", "아이스바디") && weather == WeatherType.SNOW) return ab
        if (ab == "마중물" && 11 in enemyTypes) return ab
        if (ab == "리프가드" && (weather == WeatherType.SUN || weather == WeatherType.HARD_SUN)) return ab
        if (ab == "모래숨기" && weather == WeatherType.SAND) return ab
        if (ab in setOf("매직미러", "미러아머")) return ab
        if (ab == "미라클스킨" && Random.nextDouble() < 0.5) return ab
        if (ab == "부유" && 5 in enemyTypes) return ab
        if (ab in setOf("불가사의부적", "황금몸")) return ab
        if (ab == "저수" && 11 in enemyTypes) return ab
        if (ab in setOf("전기엔진", "피뢰침") && 13 in enemyTypes) return ab
        if (ab == "초식" && 12 in enemyTypes) return ab
        if (ab == "흙먹기" && 5 in enemyTypes) return ab

        // 플라워베일 (다른 풀 타입 동료 보호)
        val allyPokemon = repo.getPokemon(ally.id)
        if (allyPokemon != null && 12 in allyPokemon.types) {
            if (team.any { it !== ally && has(it, team, repo, "플라워베일") }) {
                return "플라워베일"
            }
        }

        return null
    }

    /**
     * 야생 포켓몬의 저항 공격 발동 주기 배율 (resistIntervalMult)
     */
    fun getResistIntervalMultiplier(team: List<AllyMon>, resPerk: Int, repo: PokemonRepository): Double {
        var m = 1.0
        if (teamHas(team, repo, "긴장감", "위협", "프레셔")) {
            m *= 1.25
            if (team.any { it.item == "ability-patch" && has(it, team, repo, "긴장감", "위협", "프레셔") }) m *= 1.1
        }
        if (teamHas(team, repo, "솜털")) {
            m *= 1.5
            if (team.any { it.item == "ability-patch" && has(it, team, repo, "솜털") }) m *= 1.1
        }
        m *= 1.1.pow(resPerk.toDouble())
        if (team.any { it.item == "assault-vest" }) m *= 1.1
        return m
    }

    /**
     * 경험치 획득 배율 (expAbilityMult)
     */
    fun getExpMultiplier(team: List<AllyMon>, repo: PokemonRepository): Double {
        val expAbilityHolder = team.firstOrNull { has(it, team, repo, "꿀모으기", "픽업") }
        val base = if (expAbilityHolder != null) 1.1 else 1.0
        return if (base != 1.0 && expAbilityHolder?.item == "ability-patch") base * 1.1 else base
    }
}
