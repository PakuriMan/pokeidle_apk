package com.pokeidle.app.presentation.modal

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.presentation.OfflineReward

@Composable
fun OfflineProgressDialog(reward: OfflineReward, onDismiss: () -> Unit) {
    val hours = reward.elapsedSeconds / 3600
    val minutes = (reward.elapsedSeconds % 3600) / 60
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🌙 휴면 보상") },
        text = {
            Text("자리를 비운 ${hours}시간 ${minutes}분 동안 포켓몬이 사냥했습니다.\n경험치 +${BattleMath.fmtL(reward.expL)} · 처치 약 ${BattleMath.formatNumber(reward.kills.toDouble())}마리\n휴면 보상은 최대 6시간, 온라인 효율의 10%로 계산됩니다.")
        },
        confirmButton = { Button(onClick = onDismiss) { Text("확인") } }
    )
}
