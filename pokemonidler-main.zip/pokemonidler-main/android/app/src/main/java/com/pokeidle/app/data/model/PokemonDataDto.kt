package com.pokeidle.app.data.model

import kotlinx.serialization.Serializable

/**
 * data.json 전체 구조를 매핑하는 루트 DTO
 */
@Serializable
data class GameDataDto(
    val poke: List<PokemonDto> = emptyList(),
    val forms: List<PokemonDto> = emptyList(),
    val types: Map<String, String> = emptyMap(),
    val eff: Map<String, Double> = emptyMap(),
    val moves: Map<String, MoveDto> = emptyMap(),
    val megas: Map<String, List<MegaDto>> = emptyMap(),
    val abilities: Map<String, AbilityDto> = emptyMap(),
    val altforms: Map<String, Map<String, AltFormDto>> = emptyMap()
)

/**
 * 포켓몬 개별 도감 정보 DTO (본체 및 폼체인지 공통)
 */
@Serializable
data class PokemonDto(
    val id: Int,
    val ko: String,
    val en: String = "",
    val genus: String = "",
    val gen: Int = 1,
    val hp: Int = 1,
    val atk: Int = 1,
    val def: Int = 1,
    val spd: Int = 1,
    val cap: Int = 1,
    val types: List<Int> = emptyList(),
    val moves: List<Int> = emptyList(),
    val img: String = "",
    val min: Int = 1,
    val evo: List<List<Int>> = emptyList(),
    val chain: Int = id,
    val pw: Double = 0.0,
    val abil: List<List<Int>> = emptyList(),
    val sdf: Int = 1,
    val spa: Int = 1,
    val sp: Int? = null
)

/**
 * 기술(Move) DTO
 */
@Serializable
data class MoveDto(
    val t: Int,                     // 타입 ID (1 ~ 18)
    val p: Double = 0.0,            // 위력 (Power)
    val c: Int = 2,                 // 공격 분류 (3: 특수공격, 2: 물리공격)
    val ko: String,                 // 기술 한국어 명칭
    val en: String? = null,         // 기술 영어 명칭
    val txt: String? = null         // 설명 텍스트
)

/**
 * PokéAPI v2 기반 위력 있는(데미지) 기술 목록 및 포켓몬별 습득 기술셋 DTO
 */
@Serializable
data class DamagingMovesDataDto(
    val moves: Map<String, MoveDto> = emptyMap(),
    val learnsets: Map<String, List<Int>> = emptyMap()
)

/**
 * 특성(Ability) DTO
 */
@Serializable
data class AbilityDto(
    val ko: String,                 // 특성 한국어 명칭
    val en: String? = null,         // 특성 영어 명칭
    val txt: String = ""            // 원작 설명 텍스트
)

/**
 * 메가진화 / 원시회귀 / 폼체인지 DTO
 */
@Serializable
data class MegaDto(
    val id: Int,
    val suffix: String? = null,
    val label: String? = null,      // 원시, 울트라, 무한, 스텔라, 기승, 왕 등
    val pw: Double = 0.0,
    val hp: Int? = null,
    val atk: Int? = null,
    val def: Int? = null,
    val spa: Int? = null,
    val sdf: Int? = null,
    val spd: Int? = null,
    val types: List<Int> = emptyList(),
    val img: String = "",
    val boost: Double? = null       // 지속 중 위력 보정 배율 (예: 1.5)
)

/**
 * 캐스퐁/모르페코/불비달마 등 배틀 대체 폼체인지 DTO
 */
@Serializable
data class AltFormDto(
    val img: String = "",
    val types: List<Int> = emptyList(),
    val ko: String = "",
    val hp: Int? = null,
    val atk: Int? = null,
    val def: Int? = null,
    val spa: Int? = null,
    val sdf: Int? = null,
    val pw: Double? = null,
    val spd: Int? = null
)

/**
 * 도감 상세 화면에서 기본폼/메가/리전/변신폼을 일관되게 토글하여 보여주기 위한 UI 모델
 */
data class FormViewData(
    val formKey: String,
    val label: String,
    val fullName: String,
    val types: List<Int>,
    val img: String,
    val hp: Int,
    val atk: Int,
    val def: Int,
    val spa: Int,
    val sdf: Int,
    val spd: Int,
    val moves: List<Int>,
    val pw: Double = 0.0,
    val spriteAssetName: String? = null,
    val shinySpriteAssetName: String? = null
)

@kotlinx.serialization.Serializable
data class PokemonFormAssetDto(
    val speciesId: Int,
    val pokemonId: Int,
    val formId: Int,
    val name: String,
    val formName: String = "",
    val isDefault: Boolean = false,
    val defaultSprite: String? = null,
    val shinySprite: String? = null
)

@kotlinx.serialization.Serializable
data class PokemonFormAssetsDataDto(val forms: List<PokemonFormAssetDto> = emptyList())
