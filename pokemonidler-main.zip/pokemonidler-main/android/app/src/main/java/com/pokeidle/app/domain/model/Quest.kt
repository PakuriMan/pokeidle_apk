package com.pokeidle.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 게임 내 일일 및 지역 퀘스트 엔티티
 */
@Serializable
data class Quest(
    val k: String,              // 퀘스트 종류 (se: 효과 굉장 공격, heal: 회복 돕기, region: 특정 지역 처치)
    var p: Int = 0,             // 현재 진행도
    var done: Boolean = false,  // 완료 여부
    val n: Int,                 // 목표 진행도
    val text: String,           // 유저 표시 텍스트
    var rewardExp: Double,      // 보상 경험치 (K 시프트 시 스케일링)
    val g: Int? = null          // 지역 한정 퀘스트의 대상 지역 ID (1~9)
)
