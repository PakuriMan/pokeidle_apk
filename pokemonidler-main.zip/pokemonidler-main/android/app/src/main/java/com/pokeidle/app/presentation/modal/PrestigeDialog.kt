package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.domain.model.PrestigePerks

@Composable
fun PrestigeDialog(
    gameState: GameState,
    now: Long,
    onBuyPerk: (String) -> Boolean,
    onTogglePerk: (String, Boolean) -> Unit,
    onPrestige: () -> Boolean,
    onUpgradeAlly: (com.pokeidle.app.domain.model.AllyMon) -> Unit,
    onMakeShiny: (com.pokeidle.app.domain.model.AllyMon) -> Unit,
    pokemonName: (Int) -> String,
    onDismiss: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val enemyLevel = gameState.enemy?.lvl ?: (1L + gameState.kills / 4L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    val cooldownLeft = (gameState.lastPrestigeAt + 300_000L - now).coerceAtLeast(0L)
    val canPrestige = enemyLevel >= 100 && cooldownLeft == 0L && gameState.runExp > 0.0
    val runPointsL = BattleMath.runPointsL(gameState.runExp, gameState.K)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🌀 환생 · 상점") },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("적 레벨 100부터 환생 가능 · 환생하면 팀/박스 레벨과 이번 회차 EXP가 초기화됩니다.", style = MaterialTheme.typography.bodySmall)
                Text("이번 환생 보상: +${BattleMath.fmtL(runPointsL)}P · 보유 RP: ${if (gameState.rpL <= -299.0) "0" else BattleMath.fmtL(gameState.rpL)}P", fontWeight = FontWeight.Bold)
                when {
                    enemyLevel < 100 -> Text("현재 적 레벨 $enemyLevel / 100")
                    cooldownLeft > 0 -> Text("다음 환생까지 ${cooldownLeft / 60_000}분 ${(cooldownLeft / 1_000) % 60}초")
                    else -> Text("환생할 수 있습니다.", color = MaterialTheme.colorScheme.primary)
                }
                Button(onClick = { if (onPrestige()) onDismiss() }, enabled = canPrestige, modifier = Modifier.fillMaxWidth()) {
                    Text("환생하기 (+${BattleMath.fmtL(runPointsL)}P)")
                }
                Text("포켓몬 강화 · 1회당 데미지 ×1.3", fontWeight = FontWeight.Bold)
                OutlinedTextField(value = search, onValueChange = { search = it }, placeholder = { Text("팀·박스 이름 또는 도감 번호 검색") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black), modifier = Modifier.fillMaxWidth())
                (gameState.team + gameState.box).filter { search.isBlank() || pokemonName(it.id).contains(search.trim(), ignoreCase = true) || it.id.toString() == search.trim() }.forEach { ally ->
                    val cost = BattleMath.rbCostL(ally.rb)
                    OutlinedButton(onClick = { onUpgradeAlly(ally) }, enabled = gameState.rpL >= cost, modifier = Modifier.fillMaxWidth()) {
                        Text("${if (ally.slot >= 0) "팀" else "박스"} · ${pokemonName(ally.id)} Lv.${ally.lvl} ★${ally.rb} → ★${ally.rb + 1} · ${BattleMath.fmtL(cost)}P")
                    }
                }
                Text("마스터볼 50개 · 이로치 변환 (보유 ${gameState.mballs}개)", fontWeight = FontWeight.Bold)
                (gameState.team + gameState.box).filter { !it.isShiny && it.id !in setOf(1026, 1027) && (search.isBlank() || pokemonName(it.id).contains(search.trim(), true) || it.id.toString() == search.trim()) }.forEach { ally ->
                    OutlinedButton(onClick = { onMakeShiny(ally) }, enabled = gameState.mballs >= 50, modifier = Modifier.fillMaxWidth()) { Text("${pokemonName(ally.id)} Lv.${ally.lvl} → 이로치 · 마스터볼 50") }
                }
                Text("환생 포인트 상점", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                PrestigePerks.all.forEach { perk ->
                    val level = gameState.perks[perk.key] ?: 0
                    val costL = BattleMath.perkCostL(perk.baseCost, level)
                    val canBuy = gameState.rpL >= costL && (perk.maxLevel == null || level < perk.maxLevel)
                    Column(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("${perk.name} Lv.$level${perk.maxLevel?.let { "/$it" } ?: ""}", fontWeight = FontWeight.Bold)
                                Text(perk.description, style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { onBuyPerk(perk.key) }, enabled = canBuy) {
                                Text(if (perk.maxLevel != null && level >= perk.maxLevel) "최대" else "${BattleMath.fmtL(costL)}P")
                            }
                        }
                        if (level > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("효과 켜기", style = MaterialTheme.typography.bodySmall)
                                Switch(checked = gameState.offPerk[perk.key] != true, onCheckedChange = { onTogglePerk(perk.key, it) })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("닫기") } }
    )
}



