package com.pokeidle.app.data.model

/** Max Mushroom form whitelist, mapped to PokéAPI form IDs and bundled sprite assets. */
object GigantamaxFormsData {
    private val formIdsByPokemonId = mapOf(
        3 to 10195,    // Venusaur
        6 to 10196,    // Charizard
        9 to 10197,    // Blastoise
        12 to 10198,   // Butterfree
        25 to 10199,   // Pikachu
        52 to 10200,   // Meowth
        68 to 10201,   // Machamp
        94 to 10202,   // Gengar
        99 to 10203,   // Kingler
        131 to 10204,  // Lapras
        133 to 10205,  // Eevee
        143 to 10206,  // Snorlax
        569 to 10207,  // Garbodor
        809 to 10208,  // Melmetal
        812 to 10209,  // Rillaboom
        815 to 10210,  // Cinderace
        818 to 10211,  // Inteleon
        823 to 10212,  // Corviknight
        826 to 10213,  // Orbeetle
        834 to 10214,  // Drednaw
        839 to 10215,  // Coalossal
        841 to 10216,  // Flapple
        842 to 10217,  // Appletun
        844 to 10218,  // Sandaconda
        849 to 10219,  // Toxtricity (Amped)
        851 to 10220,  // Centiskorch
        858 to 10221,  // Hatterene
        861 to 10222,  // Grimmsnarl
        869 to 10223,  // Alcremie
        879 to 10224,  // Copperajah
        884 to 10225,  // Duraludon
        890 to 10190,  // Eternatus (Eternamax)
        892 to 10226   // Urshifu (Single Strike)
    )

    fun getFormId(pokemonId: Int): Int? = formIdsByPokemonId[pokemonId]
    fun canGigantamax(pokemonId: Int): Boolean = pokemonId in formIdsByPokemonId
    fun isForm(formId: Int?): Boolean = formIdsByPokemonId.values.any { it == formId }
    fun getSpriteAssetPath(pokemonId: Int): String? = getFormId(pokemonId)?.let { getSpriteAssetPathForFormId(it) }
    fun getSpriteAssetPathForFormId(formId: Int, isShiny: Boolean = false): String? {
        if (!isForm(formId)) return null
        val apiFormId = if (formId == 10190) 10359 else formId + 169
        val suffix = if (isShiny) "shiny/" else ""
        return "pokemon_forms/${suffix}${apiFormId}.png"
    }

    fun getTransformedMoveName(typeId: Int): String {
        val suffix = when (typeId) {
            1 -> "어택"
            2 -> "너클"
            3 -> "제트"
            4 -> "애시드"
            5 -> "어스"
            6 -> "록"
            7 -> "웜"
            8 -> "할로우"
            9 -> "스틸"
            10 -> "플레어"
            11 -> "스트림"
            12 -> "그래스"
            13 -> "썬더"
            14 -> "사이코"
            15 -> "아이스"
            16 -> "드라군"
            17 -> "아크"
            18 -> "페어리"
            else -> "맥스"
        }
        return "다이$suffix"
    }

    /** Max Move power conversion; Fighting and Dark use their lower power table. */
    fun getTransformedMovePower(typeId: Int, movePower: Double): Double {
        val power = when {
            movePower <= 0.0 -> if (typeId == 2 || typeId == 17) 100.0 else 130.0 // 위력 보정 기술/일격기
            movePower <= 40.0 -> 90.0
            movePower <= 50.0 -> 100.0
            movePower <= 60.0 -> 110.0
            movePower <= 70.0 -> 120.0
            movePower <= 100.0 -> 130.0
            movePower <= 140.0 -> 140.0
            else -> 150.0
        }
        if (typeId != 2 && typeId != 17) return power
        return when (power) {
            90.0 -> 70.0
            100.0 -> 75.0
            110.0 -> 80.0
            120.0 -> 85.0
            130.0 -> 90.0
            140.0 -> 95.0
            else -> 100.0
        }
    }
}
