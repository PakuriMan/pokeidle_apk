package com.pokeidle.app.domain.engine

import com.pokeidle.app.data.model.MegaDto
import com.pokeidle.app.data.model.MoveDto
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.model.GigantamaxFormsData
import com.pokeidle.app.data.model.NecrozmaFusionData
import com.pokeidle.app.data.model.CanonicalStatsData
import com.pokeidle.app.data.model.ZygardeFusionData
import com.pokeidle.app.data.model.ZMoveData
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.domain.model.WildEnemy
import com.pokeidle.app.domain.system.AbilitySystem
import com.pokeidle.app.domain.system.ActiveTerrain
import com.pokeidle.app.domain.system.ActiveWeather
import com.pokeidle.app.domain.system.ResistSystem
import com.pokeidle.app.domain.system.StatusSystem
import com.pokeidle.app.domain.system.WeatherTerrainSystem
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * 100ms(TICK=0.1s) 주기 포켓몬 자동 전투 루프 및 전투 엔진
 */
class BattleEngine(
    val gameState: GameState,
    val repository: PokemonRepository
) {
    companion object {
        const val TICK = 0.1 // 100ms 틱
        const val MEGA_DURATION = 30.0 // 메가진화 30초 지속
        const val MEGA_GAIN_PER_HIT = 4.0 // 타격당 메가게이지 +4%
        const val SHINY_RATE = 1.0 / 256.0
        const val SHINY_EXP_MULT = 25.0

    }

    private var chainKills = 0
    private var inChain = false
    private val eventListeners = mutableListOf<(BattleEvent) -> Unit>()
    private val highCriticalMoves = setOf(163, 314, 342, 348, 400, 421, 427, 440, 444, 895)
    private val sureCriticalMoves = setOf(870, 871, 872)

    init {
        gameState.team.forEach { if (it.joined <= 0L) it.joined = ++gameState.seq }
        gameState.box.forEach { if (it.joined <= 0L) it.joined = ++gameState.seq }
    }

    fun addEventListener(listener: (BattleEvent) -> Unit) {
        eventListeners.add(listener)
    }

    private fun emit(event: BattleEvent) {
        eventListeners.forEach { it(event) }
    }

    // --- 기후 및 필드 상태 ---
    var forcedWeather: ActiveWeather? = null
    var forcedTerrain: ActiveTerrain? = null

    val currentWeather: ActiveWeather?
        get() = forcedWeather ?: WeatherTerrainSystem.resolveWeather(gameState.team) {
            AbilitySystem.getEffectiveAbilityName(it, gameState.team, repository)
        }

    val currentTerrain: ActiveTerrain?
        get() = forcedTerrain ?: WeatherTerrainSystem.resolveTerrain(gameState.team) {
            AbilitySystem.getEffectiveAbilityName(it, gameState.team, repository)
        }

    /**
     * 메인 100ms 전투 틱
     */
    fun tick(dt: Double = TICK) {
        // 1. 적 포켓몬 확인 및 출현
        if (gameState.enemy == null) {
            spawnEnemy()
        }

        // 2. 야생 포켓몬 저항 타이머 감쇠 및 발동
        gameState.rt -= dt
        if (gameState.rt <= 0.0) {
            val enemy = gameState.enemy
            if (enemy != null) {
                val rankBefore = gameState.team.map { it.joined to it.status.rank }.toMap()
                val msg = ResistSystem.executeEnemyResist(
                    enemy = enemy,
                    team = gameState.team,
                    weather = currentWeather?.weather,
                    terrain = currentTerrain?.terrain,
                    repo = repository
                )
                emit(BattleEvent.EnemyResist("저항", msg))

                // 하양허브: 능력 랭크가 실제로 떨어진 장착 포켓몬은 랭크를 모두 회복하고 1개 소모.
                gameState.team.forEach { ally ->
                    if (ally.status.rank < (rankBefore[ally.joined] ?: ally.status.rank) && ally.item == "white-herb") {
                        ally.status.rank = 0
                        ally.status.rankLeft = 0.0
                        consumeHeldItem(ally, "white-herb")
                    }
                }

                // 카운터 데미지 처리 (까칠한피부/철가시 등)
                val counterDmg = ResistSystem.handleAfterEnemyResist(gameState.team, enemy, repository)
                if (enemy.hp <= 0.0) {
                    defeat()
                }
            }
            // 다음 저항 주기 재설정
            val perkRes = gameState.getEffectivePerk("res")
            val baseInterval = 20.0 + Random.nextDouble() * 20.0 // 20 ~ 40초
            val mult = AbilitySystem.getResistIntervalMultiplier(gameState.team, perkRes, repository)
            gameState.rtMax = baseInterval * mult
            gameState.rt = gameState.rtMax
        }

        // 3. 동료 상태이상 및 버프 감쇠 처리
        StatusSystem.tickStatus(gameState.team, dt, repository) { ally, statusName ->
            emit(BattleEvent.LogMessage("${repository.getPokemon(ally.id)?.ko ?: "동료"}의 ${statusName}이(가) 풀렸다."))
        }

        // 4. 적 포켓몬 버프 감쇠 처리
        gameState.enemy?.let { ResistSystem.tickEnemyBuffs(it, dt) }

        // 5. 동료 포켓몬 개별 공격 쿨다운 및 공격 실행
        val readyAttacks = mutableListOf<Pair<AllyMon, Double>>()
        for (ally in gameState.team) {
            // 메가진화 잔여 지속 시간 감쇠
            if (ally.isMega && ally.megaFormId !in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID)) {
                ally.megaDuration = (ally.megaDuration - dt).coerceAtLeast(0.0)
                if (ally.megaDuration == 0.0) {
                    megaRevert(ally)
                }
            }

            // 행동 불능 상태이상(잠듦/얼음) 시 스킵
            if (ally.status.isAsleepOrFrozen) continue

            // 사령탑 어써러셔 명령 상태인 경우 스킵 (어써러셔가 대신 2배 공격)
            if (AbilitySystem.has(ally, gameState.team, repository, "사령탑") &&
                gameState.team.any { it !== ally && it.id == 968 }
            ) {
                continue
            }

            // 생명의구슬은 공격 10회 뒤 10초간 쉬며, 휴식 중에는 쿨다운도 진행하지 않는다.
            if (ally.item == "life-orb") {
                if (ally.status.lifeOrbRest > 0.0) {
                    ally.status.lifeOrbRest = (ally.status.lifeOrbRest - dt).coerceAtLeast(0.0)
                    continue
                }
            } else {
                ally.status.lifeOrbAttackCount = 0
                ally.status.lifeOrbRest = 0.0
            }

            // 도우미(Helping Hand 270)는 직접 공격하지 않고 다른 팀원을 상시 버프
            if (ally.move == 270) continue

            ally.cd -= dt

            // 드래곤옐 / 코칭 (913, 811): 다른 동료를 응원
            if (ally.move == 913 || ally.move == 811) {
                if (ally.cd <= 0.0) {
                    dragonCheer(ally)
                    ally.cd += getAllyInterval(ally)
                }
                continue
            }

            // 공격 주기 도달 시 타격
            if (ally.cd <= 0.0) {
                val iv0 = getAllyInterval(ally)
                // 틱보다 주기가 짧은 경우 단일 틱에 여러 타격 압축
                val nAtk = min(1e9, 1.0 + floor(-ally.cd / iv0))
                readyAttacks.add(ally to nAtk)
                countLifeOrbAttack(ally)

                // 전기로바꾸기 충전 해제
                if (ally.status.charge && getEffectiveMoveType(ally) == 13) {
                    ally.status.charge = false
                }
                // 퀵드로 소진 및 10% 재발동 체크
                ally.status.quick = AbilitySystem.has(ally, gameState.team, repository, "퀵드로") && Random.nextDouble() < 0.1

                // 변덕쟁이 다음 버프 갱신
                if (AbilitySystem.has(ally, gameState.team, repository, "변덕쟁이")) {
                    ally.status.whim = com.pokeidle.app.domain.model.WhimBuff(
                        iv = 10.0.pow(Random.nextDouble(-1.0, 1.0)),
                        d = 10.0.pow(Random.nextDouble(-1.0, log10(15.0)))
                    )
                }

                ally.cd += iv0 * nAtk

            }
        }

        readyAttacks.forEach { (ally, count) -> hit(ally, count) }
        // 같은 틱에 준비된 다른 동료들도 첫 공격과 함께 처리한 뒤 적을 격파한다.
        // 루프 중간에 defeat()를 호출하면 새 적이 즉시 생성되어 나머지 공격이
        // 누락되거나 새 적에게 잘못 전달될 수 있다.
        val enemy = gameState.enemy
        if (enemy != null && enemy.hp <= 0.0) {
            gameState.team.filter {
                AbilitySystem.has(it, gameState.team, repository, "백의울음", "흑의울음", "자기과신", "비스트부스트", "소울하트")
            }.forEach { it.status.kill = 15.0 }
            defeat()
        }
    }

    /**
     * 포켓몬 1마리의 적 타격 실행
     */
    fun hit(ally: AllyMon, nAtk: Double = 1.0) {
        val enemy = gameState.enemy ?: return

        // 빗나감 판정
        val missRate = getMissChance(ally) + ResistSystem.getEnemyEvasion(enemy, ally, gameState.team, repository)
        if (!(ally.id == 493 && ally.item == "legend-plate" && ally.move == 449) && Random.nextDouble() < missRate) {
            emit(BattleEvent.Miss(ally.slot))
            return
        }

        var (baseDmg, effMult) = calculateDamage(ally, enemy)
        val fold = BattleMath.speedFold(nAtk)
        var dmg = min(1e300, baseDmg * fold)

        // 원본 급소 단계: 기본 1/24, 급소율 상승 기술/대운으로 단계 상승.
        val isSureCritical = (ally.id == 493 && ally.item == "legend-plate" && ally.move == 449) || ally.move in sureCriticalMoves
        val criticalStage = (if (ally.item == "pikashunium-z--held" && ally.status.zMoveDuration > 0.0) 2 else if (ally.move in highCriticalMoves) 1 else 0) +
                (if (AbilitySystem.has(ally, gameState.team, repository, "대운")) 1 else 0)
        val criticalRate = when (criticalStage.coerceAtMost(3)) {
            0 -> 1.0 / 24.0
            1 -> 1.0 / 8.0
            2 -> 1.0 / 2.0
            else -> 1.0
        }
        var isCritical = false
        if (isSureCritical || Random.nextDouble() < criticalRate) {
            val criticalMultiplier = if (AbilitySystem.has(ally, gameState.team, repository, "스나이퍼")) 2.25 else 1.5
            val scopeMultiplier = if (ally.item == "scope-lens") 1.1 else 1.0
            dmg = min(1e300, dmg * criticalMultiplier * scopeMultiplier)
            isCritical = true
        }

        // 오버킬 연쇄 처치 계산 (만피 적에게 최대 HP의 10배 이상 초과 데미지)
        if (enemy.hp >= enemy.maxHp && dmg >= 10.0 * enemy.maxHp) {
            val r = dmg / max(enemy.maxHp, 1e-300)
            val isUnderMax = getEnemyLevel() < gameState.maxLvl
            val extra = BattleMath.calcOverkillExtra(r, isUnderMax)
            chainKills = max(chainKills, extra)
        }

        enemy.hp = (enemy.hp - dmg).coerceAtLeast(0.0)

        // 독사슬 (1/32) / 독수 (1/64) 추가 독 데미지
        if (AbilitySystem.has(ally, gameState.team, repository, "독사슬", "독수") && Random.nextDouble() < 0.3) {
            val divisor = if (AbilitySystem.has(ally, gameState.team, repository, "독사슬")) 32.0 else 64.0
            val extraPoisonDmg = enemy.maxHp / divisor
            enemy.hp = (enemy.hp - extraPoisonDmg).coerceAtLeast(0.0)
        }

        // 메가 게이지 충전
        val zMoveReady = ally.item?.let { itemId ->
            val item = repository.getHeldItem(itemId)
            val move = repository.getMove(ally.move)
            item?.category == "z-crystals" && itemId != "ultranecrozium-z" && move != null &&
                ZMoveData.resolve(itemId, ally.id, ally.move, getEffectiveMoveType(ally), move.p, ally.megaFormId) != null
        } == true
        if ((canMegaEvolve(ally) || zMoveReady) && !ally.isMega) {
            ally.mg = min(100.0, ally.mg + MEGA_GAIN_PER_HIT * nAtk)
            if (zMoveReady && ally.mg >= 100.0 && ally.status.zMoveDuration <= 0.0) {
                ally.mg = 0.0
                if (ally.item == "lycanium-z--held") forcedTerrain = null
                if (ally.item == "primarium-z--held") ally.status.brn = 0.0
                if (ally.item == "mewnium-z--held") forcedTerrain = ActiveTerrain(com.pokeidle.app.domain.system.TerrainType.PSYCHIC, ally)
                ally.status.zMoveDuration = 10.0
                if (ally.item in setOf("eevium-z--held", "kommonium-z--held")) { ally.status.rank = (ally.status.rank + if (ally.item == "eevium-z--held") 2 else 1).coerceAtMost(6); ally.status.rankLeft = 10.0 }
                emit(BattleEvent.LogMessage("💎 ${repository.getPokemon(ally.id)?.ko ?: "포켓몬"}의 Z크리스탈이 빛난다! 10초 동안 Z기술을 사용한다."))
            }
        }

        emit(
            BattleEvent.Hit(
                slot = ally.slot,
                damage = dmg,
                isSuperEffective = effMult > 1.0,
                isNotVeryEffective = effMult < 1.0,
                isCritical = isCritical,
                moveType = getEffectiveMoveType(ally)
            )
        )
    }

    /**
     * 유저가 화면 중앙의 적을 탭했을 때 수동 타격 실행
     */
    fun tapAttack() {
        val enemy = gameState.enemy ?: return
        val leader = gameState.team.firstOrNull() ?: return
        hit(leader, 1.0)
        countLifeOrbAttack(leader)
        if (enemy.hp <= 0.0) {
            defeat()
        }
    }

    private fun countLifeOrbAttack(ally: AllyMon) {
        if (ally.item != "life-orb") return
        ally.status.lifeOrbAttackCount++
        if (ally.status.lifeOrbAttackCount >= 10) {
            ally.status.lifeOrbAttackCount = 0
            ally.status.lifeOrbRest = 10.0
        }
    }

    private fun consumeHeldItem(ally: AllyMon, itemId: String) {
        if (ally.item != itemId) return
        val count = gameState.getItemStack(itemId)
        if (count <= 0) {
            ally.item = null
            return
        }
        if (count == 1) {
            gameState.items.remove(itemId)
            ally.item = null
        } else {
            gameState.items[itemId] = count - 1
        }
        val itemName = repository.getHeldItem(itemId)?.ko ?: itemId
        emit(BattleEvent.LogMessage("${repository.getPokemon(ally.id)?.ko ?: "동료"}의 $itemName 효과로 능력 저하를 회복했다. (남은 ${gameState.getItemStack(itemId)}개)"))
    }

    /**
     * 적 격파 처리 (경험치 보상, 증표 획득, 볼 포획, 오버킬 연쇄)
     */
    fun defeat() {
        val extra = chainKills
        chainKills = 0

        val enemy = gameState.enemy ?: return
        val enemyPokemon = repository.getPokemon(enemy.id) ?: return

        // 1. 경험치 보상 계산
        val baseReward = getExpReward(enemy)
        val shinyMult = if (enemy.isShiny) SHINY_EXP_MULT else 1.0
        val abilityExpMult = AbilitySystem.getExpMultiplier(gameState.team, repository)
        val luckyEggHolder = gameState.team.find { it.item == "lucky-egg" }
        val luckyEggMult = if (luckyEggHolder != null) 1.1 else 1.0
        val expGain = baseReward * shinyMult * abilityExpMult * luckyEggMult

        gameState.exp += expGain
        gameState.runExp += expGain
        gameState.totalL = BattleMath.logAdd(gameState.totalL, log10(expGain))
        gameState.coins = (gameState.coins + enemy.lvl / 100L).coerceAtMost(Long.MAX_VALUE / 2)
        gameState.kills++

        // 2. 처치 킬수 비례 볼 보상
        if (gameState.kills % 100L == 0L) {
            gameState.pballs++
            emit(BattleEvent.BallRewarded("poke", gameState.pballs))
        }
        if (gameState.kills % 200L == 0L) {
            gameState.balls++
            emit(BattleEvent.BallRewarded("ultra", gameState.balls))
        }
        if (gameState.kills % 1000L == 0L) {
            gameState.mballs++
            emit(BattleEvent.BallRewarded("master", gameState.mballs))
        }

        if (enemy.isShiny) {
            gameState.shinies++
        }

        emit(BattleEvent.EnemyDefeated(enemy.id, enemy.isShiny, expGain))

        // 3. 다중 티어(Tier) 증표 획득 공식
        var p = enemy.lvl / 1000.0 + 0.001 * gameState.getEffectivePerk("tok")
        var sure = 0
        var tier = 1.0
        while (p >= tier && sure < 50) {
            p -= tier
            sure++
            tier *= 10.0
        }
        val rest = p / tier

        val coinHolder = gameState.team.find { it.item == "amulet-coin" }
        val hasAmuletCoin = coinHolder != null

        for (ally in gameState.team) {
            val baseN = sure + (if (Random.nextDouble() < rest) 1 else 0)
            val n = if (baseN > 0 && hasAmuletCoin) max(baseN, (baseN * 1.1).toInt()) else baseN
            if (n > 0) {
                val chain = repository.getPokemon(ally.id)?.chain ?: ally.id
                gameState.tokens[chain] = (gameState.tokens[chain] ?: 0) + n
                if (!inChain) {
                    emit(BattleEvent.TokenGained(ally.id, n))
                }
            }
        }

        // 4. 포켓몬 동료 합류 판정. 이로치는 일반 포획 확률의 0.01%만 적용한다.
        val joinBaseChance = 0.08 + 0.25 * (enemyPokemon.cap / 255.0)
        val lureMult = if (enemy.isLure) 5.0 else 1.0
        val perkJoinMult = 1.1.pow(gameState.getEffectivePerk("join").toDouble())
        val normalJoinChance = (joinBaseChance * lureMult * perkJoinMult).coerceIn(0.0, 1.0)
        val joinRoll = Random.nextDouble() < normalJoinChance
        val shinyJoinRoll = enemy.isShiny && Random.nextDouble() < normalJoinChance * 0.0001

        val isCaptured = if (enemy.isShiny) shinyJoinRoll else enemy.isMaster || joinRoll
        if (isCaptured && enemy.id != 1027) {
            if (enemy.isShiny) gameState.shinySeen[-enemy.id] = 1
            val chainId = enemyPokemon.chain
            val isOwned = isPokemonOwned(enemy.id)

            if (isOwned && !enemy.isShiny && enemy.id !in com.pokeidle.app.data.model.ZygardeFusionData.allIds) {
                // 이미 보유한 진화 라인이면 증표 10개 획득
                gameState.tokens[chainId] = (gameState.tokens[chainId] ?: 0) + 10
                emit(BattleEvent.TokenGained(enemy.id, 10))
            } else {
                // 신규 동료 합류
                val avgLvl = if (gameState.team.isEmpty()) 1 else gameState.team.map { it.lvl }.average().toInt()
                val newLvl = max(1, floor(avgLvl * 0.7).toInt())
                val newMon = AllyMon(
                    id = enemy.id,
                    lvl = newLvl,
                    cd = 0.3 + Random.nextDouble() * 0.9,
                    move = repository.randomMove(enemyPokemon),
                    ab = repository.rollAbility(enemyPokemon),
                    isShiny = enemy.isShiny
                )

                // 도감 등록
                gameState.caught[enemy.id] = (gameState.caught[enemy.id] ?: 0) + 1
                val openSlot = (0..5).firstOrNull { slotIdx -> gameState.team.none { it.slot == slotIdx } }
                newMon.joined = ++gameState.seq
                if (openSlot != null) {
                    newMon.slot = openSlot
                    gameState.team.add(newMon)
                    emit(BattleEvent.PokemonCaught(enemy.id, isSentToBox = false, slot = openSlot, isShiny = enemy.isShiny))
                } else {
                    newMon.slot = -1
                    synchronized(gameState.box) {
                        gameState.box.add(newMon)
                    }
                    emit(BattleEvent.PokemonCaught(enemy.id, isSentToBox = true, slot = -1, isShiny = enemy.isShiny))
                }
            }
        }

        // 5. 10레벨 단위 적 처치에서 30% 확률로 도구 획득
        if (enemy.lvl % 10 == 0 && Random.nextDouble() < 0.30) {
            val dropped = repository.getRandomDroppableItem()
            if (dropped != null) {
                val current = gameState.items[dropped.id] ?: 0
                val newStack = current + 1
                gameState.items[dropped.id] = newStack
                emit(BattleEvent.ItemDropped(dropped.id, dropped.ko, newStack))
            }
        }

        // 네크로즈마 처치 전용 융합 도구: 각각 0.1% 확률로 독립 판정
        if (enemy.id == 800) {
            listOf("necropluser-sol", "necropluser-luna").filter { Random.nextDouble() < 0.001 }.forEach { itemId ->
                val item = repository.getHeldItem(itemId)
                val newStack = (gameState.items[itemId] ?: 0) + 1
                gameState.items[itemId] = newStack
                emit(BattleEvent.ItemDropped(itemId, item?.ko ?: itemId, newStack))
            }
        }

        gameState.enemy = null

        // 5. 큰 수 스케일링 정규화
        normalizeScale()

        // 6. 다음 적 스폰
        spawnEnemy()

        // 7. 오버킬 연쇄 처치 루프 실행
        if (extra > 0) {
            emit(BattleEvent.Overkill(extra))
            inChain = true
            try {
                for (i in 0 until extra) {
                    val currentEnemy = gameState.enemy ?: break
                    currentEnemy.hp = 0.0
                    defeat()
                }
            } finally {
                inChain = false
            }
        }
    }

    /**
     * 야생 적 포켓몬 스폰
     */
    fun spawnEnemy(
        forceId: Int? = null,
        isMaster: Boolean = false,
        isPlain: Boolean = false,
        forceShiny: Boolean = false
    ) {
        val lvl = getEnemyLevel()
        val allPokemon = repository.getAllPokemon().filter { it.id !in setOf(1026, 1027) }

        val pickedPokemon = if (forceId != null) {
            repository.getPokemon(forceId)?.takeIf { it.id !in setOf(1026, 1027) } ?: allPokemon.first()
        } else {
            var pool = allPokemon.filter { it.min <= lvl && (it.cap >= 45 || Random.nextDouble() < 0.15) }
            if (pool.isEmpty()) pool = allPokemon.filter { it.min <= lvl }

            val localPool = pool.filter { it.gen == gameState.region }

            // 가중치 추첨: 도감 미발견 x3, 만남 x2, 잡음 x1
            val weightedPick: (List<PokemonDto>) -> PokemonDto = { list ->
                val weights = list.map { mon ->
                    if (gameState.caught.containsKey(mon.id)) 1.0
                    else if (gameState.seen.containsKey(mon.id)) 2.0
                    else 3.0
                }
                val total = weights.sum()
                var r = Random.nextDouble() * total
                var picked = list.first()
                for (i in list.indices) {
                    r -= weights[i]
                    if (r <= 0.0) {
                        picked = list[i]
                        break
                    }
                }
                picked
            }

            if (localPool.isNotEmpty() && Random.nextDouble() < 0.8) {
                weightedPick(localPool)
            } else {
                weightedPick(pool)
            }
        }

        val p = if (pickedPokemon.id in com.pokeidle.app.data.model.ZygardeFusionData.allIds) repository.getPokemon(10181) ?: pickedPokemon else pickedPokemon
        val hpL = BattleMath.enemyHpL(p.hp.toDouble(), lvl)
        val maxHp = 10.0.pow(hpL - gameState.K)
        val isShiny = forceShiny || (forceId == null && Random.nextDouble() < SHINY_RATE)

        val enemy = WildEnemy(
            id = p.id,
            lvl = lvl,
            hp = maxHp,
            maxHp = maxHp,
            isShiny = isShiny,
            isLure = forceId != null && !isPlain,
            isMaster = isMaster
        )
        gameState.enemy = enemy

        // 도감 발견 카운트 갱신
        gameState.seen[p.id] = (gameState.seen[p.id] ?: 0) + 1

        if (isShiny) {
            gameState.shinySeen[p.id] = (gameState.shinySeen[p.id] ?: 0) + 1
            emit(BattleEvent.ShinyEncounter(p.id))
        }
    }

    /**
     * UI 상태나 외부에서 넘어온 동료 인스턴스의 실제 gameState 내부 원본 인스턴스를 탐색
     */
    fun resolveAlly(ally: AllyMon): AllyMon? {
        if (ally.slot in 0..5) {
            val found = gameState.team.find { it.slot == ally.slot }
            if (found != null) return found
        }
        if (ally.joined > 0L) {
            val found = gameState.team.find { it.joined == ally.joined }
                ?: gameState.box.find { it.joined == ally.joined }
            if (found != null) return found
        }
        return gameState.team.find { it === ally }
            ?: gameState.box.find { it === ally }
            ?: ally
    }

    /**
     * 포켓몬의 진화 트리 중 최소 요구 진화 레벨 (진화가 없으면 null)
     */
    fun getMinEvoLevel(pokemonId: Int): Int? {
        val p = repository.getPokemon(pokemonId) ?: return null
        if (p.evo.isEmpty()) return null
        return p.evo.mapNotNull { if (it.size >= 2) it[1] else null }.minOrNull()
    }

    /**
     * 현재 레벨에서 진화 가능한 진화체 목록 반환 ([toId, reqLevel])
     */
    fun getEvoOptions(ally: AllyMon): List<List<Int>> {
        val target = resolveAlly(ally) ?: ally
        val p = repository.getPokemon(target.id) ?: return emptyList()
        val options = p.evo.filter { it.size >= 2 && target.lvl >= it[1] }
        return if (target.id == 658 && target.item == "ash-greninjite") options + listOf(listOf(10117, target.lvl)) else options
    }

    /**
     * 메가진화 실행 (30초 지속)
     */
    fun megaEvolve(ally: AllyMon) {
        val target = resolveAlly(ally) ?: return
        val ultraBurstReady = target.item == "ultranecrozium-z" && target.id == 800 && target.isMega &&
            target.megaFormId in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID)
        if (!canMegaEvolve(target) || (target.isMega && !ultraBurstReady) || (target.mg < 100.0 && !ultraBurstReady)) return
        val dynamax = target.item == "max-mushroom"
        val ultraNecrozma = target.item == "ultranecrozium-z" && target.id == 800
        val ultraReturnFormId = if (ultraBurstReady) target.megaFormId else null
        val megas = repository.getMegas(target.id)
        val megaForm = when {
            target.id == 658 && AbilitySystem.has(target, gameState.team, repository, "유대변화") -> MegaDto(id = 10117, label = "유대변화")
            target.id in setOf(384, 1027) && target.move == 620 -> megas.firstOrNull { it.id == if (target.id == 1027) 11027 else 10079 }
            target.id == 383 && target.item == "red-orb" -> megas.firstOrNull { it.id == 10078 }
            target.id == 382 && target.item == "blue-orb" -> megas.firstOrNull { it.id == 10077 }
            dynamax -> null
            ultraNecrozma -> megas.firstOrNull { it.id == 10157 }
            else -> getMegaFormForStone(target.id, target.item, megas)
        }
        if (!dynamax && megaForm == null) return
        target.isMega = true
        target.megaFormId = if (dynamax) GigantamaxFormsData.getFormId(target.id) else megaForm?.id
        target.ultraRevertFormId = ultraReturnFormId
        val megaItem = target.item
        val isMegaStone = megaItem != null && (megaItem == "floettite" || repository.getHeldItem(megaItem)?.category == "mega-stones")
        val megaMult = if (isMegaStone) 1.1 else 1.0
        target.megaDuration = MEGA_DURATION * megaMult
        target.mg = 0.0

        ally.isMega = true
        ally.megaFormId = target.megaFormId
        ally.ultraRevertFormId = target.ultraRevertFormId
        ally.megaDuration = target.megaDuration
        ally.mg = 0.0
        ally.move = target.move

        val formName = when {
            dynamax && target.id == 890 -> "무한다이맥스"
            dynamax -> "거다이맥스"
            ultraNecrozma -> "울트라버스트"
            else -> megaForm?.label ?: "메가진화"
        }
        emit(BattleEvent.MegaEvolution(target.slot, formName))
    }

    /**
     * 메가진화 해제
     */
    fun megaRevert(ally: AllyMon) {
        val target = resolveAlly(ally) ?: return
        val fusionFormId = target.ultraRevertFormId
            ?.takeIf { target.id == 800 && it in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID) }
        target.isMega = fusionFormId != null
        target.megaFormId = fusionFormId
        target.megaDuration = if (fusionFormId != null) 1.0e12 else 0.0
        target.ultraRevertFormId = null
        ally.isMega = target.isMega
        ally.megaFormId = target.megaFormId
        ally.megaDuration = target.megaDuration
        ally.ultraRevertFormId = null
        ally.move = target.move
        emit(BattleEvent.MegaRevert(target.slot))
    }

    /**
     * 드래곤옐 / 코칭 (5초 동안 다른 동료 공격력 1.5배 + 시전자 레벨%)
     */
    fun dragonCheer(cheerer: AllyMon) {
        val targetMon = resolveAlly(cheerer) ?: cheerer
        val targets = gameState.team.filter { it !== targetMon && it.move != 270 && it.move != 913 && it.move != 811 }
        if (targets.isEmpty()) return
        val target = targets.random()
        target.status.rage = 5.0
    }

    /**
     * 포켓몬 레벨업 (경험치가 충분하면 정상적으로 레벨업 진행)
     */
    fun levelUp(ally: AllyMon, times: Int = 1) {
        val target = resolveAlly(ally) ?: return
        var count = 0
        val expPerk = gameState.getEffectivePerk("exp")
        while (count < times) {
            val costL = BattleMath.levelUpCostL(target.lvl, target.tb, expPerk)
            val cost = 10.0.pow(min(300.0, max(0.0, costL) - gameState.K))
            if (gameState.exp >= cost) {
                gameState.exp -= cost
                target.lvl++
                count++
            } else {
                break
            }
        }
        if (count > 0) {
            ally.lvl = target.lvl
            emit(BattleEvent.LevelUp(target.slot, target.lvl))
        }
    }

    /**
     * 포켓몬 진화 (진화체로 변경, 특성 계승, 기술 계승, 도감 등록)
     */
    fun evolve(ally: AllyMon, toId: Int): Boolean {
        val target = resolveAlly(ally) ?: return false
        if (target.id in com.pokeidle.app.data.model.ZygardeFusionData.allIds) {
            val rules = com.pokeidle.app.data.model.ZygardeFusionData
            if (rules.resultId(target.id) != toId) return false
            val materials = rules.materials(target, gameState.box) ?: return false
            if (repository.getPokemon(toId) == null) return false
            gameState.box.removeAll { mon -> materials.any { it.joined == mon.joined } }
            target.id = toId
            target.ab = rules.SWARM
            target.item = null
            target.mg = 0.0
            ally.id = target.id
            ally.ab = target.ab
            ally.item = null
            gameState.caught[toId] = (gameState.caught[toId] ?: 0) + 1
            gameState.seen[toId] = (gameState.seen[toId] ?: 0) + 1
            if (target.isShiny) gameState.shinySeen[-toId] = 1
            if (target.isShiny) gameState.shinySeen[toId] = (gameState.shinySeen[toId] ?: 0) + 1
            emit(BattleEvent.LogMessage("지가르데 ${materials.size + 1}마리가 합체했습니다!"))
            return true
        }
        val from = repository.getPokemon(target.id) ?: return false
        val to = repository.getPokemon(toId) ?: return false

        // 진화 조건 체크: from.evo 목록에 toId가 있고 현재 레벨 이상인지
        val ashGreninja = target.id == 658 && toId == 10117 && target.item == "ash-greninjite"
        val canEvolveTo = ashGreninja || from.evo.any { it.size >= 2 && it[0] == toId && target.lvl >= it[1] }
        if (!canEvolveTo) return false

        // 메가진화 해제
        target.isMega = false
        target.megaFormId = null
        target.ultraRevertFormId = null
        target.mg = 0.0
        target.megaDuration = 0.0

        // 특성 슬롯 계승
        target.ab = repository.carryAbility(target, to)

        // 기술 슬롯 계승 (기존 기술의 인덱스를 찾아 새 진화체의 해당 인덱스 기술로)
        val moveIndex = from.moves.indexOf(target.move).coerceAtLeast(0)
        target.move = if (ashGreninja) 594 else if (moveIndex < to.moves.size) to.moves[moveIndex] else (to.moves.firstOrNull() ?: 33)

        // ID 변경
        target.id = toId

        // 도감 등록
        gameState.caught[toId] = (gameState.caught[toId] ?: 0) + 1
        gameState.seen[toId] = (gameState.seen[toId] ?: 0) + 1

        // UI 파라미터 인스턴스도 동기화
        ally.id = target.id
        ally.ab = target.ab
        ally.move = target.move
        ally.isMega = false
        ally.megaFormId = null
        ally.ultraRevertFormId = null
        ally.mg = 0.0

        val newMoveDto = repository.getMove(target.move)
        emit(BattleEvent.Evolution(target.slot, from.id, to.id))
        emit(BattleEvent.LogMessage("✨ 축하합니다! ${from.ko}은(는) <b>${to.ko}</b>(으)로 진화했다! (기술: ${newMoveDto?.ko ?: target.move})"))
        return true
    }

    /**
     * 기술 바꾸기 (진화 라인 증표 1개 소모)
     */
    fun rerollMove(ally: AllyMon): Boolean {
        if (ally.id == 10117 || (ally.isMega && ally.megaFormId == 10117)) return false
        val target = resolveAlly(ally) ?: return false
        val p = repository.getPokemon(target.id) ?: return false
        val chain = p.chain
        val count = gameState.tokens[chain] ?: 0
        if (count < 1) {
            emit(BattleEvent.LogMessage("⚠ 증표가 부족합니다. (필요: 1개, 보유: ${count}개)"))
            return false
        }
        val others = p.moves.filter { it != target.move }
        if (others.isEmpty()) {
            emit(BattleEvent.LogMessage("⚠ ${p.ko}은(는) 배울 수 있는 다른 기술이 없습니다."))
            return false
        }

        gameState.tokens[chain] = count - 1
        val newMove = others.random()
        val oldMoveDto = repository.getMove(target.move)
        val newMoveDto = repository.getMove(newMove)
        target.move = newMove
        ally.move = newMove // UI 복사본도 동기화
        emit(BattleEvent.LogMessage("💎 증표를 사용했다. ${p.ko}의 기술: ${oldMoveDto?.ko ?: target.move} → ${newMoveDto?.ko ?: newMove}"))
        return true
    }

    /**
     * 특성 바꾸기 (진화 라인 증표 1개 소모, 숨겨진 특성 10% 확률)
     */
    fun rerollAbility(ally: AllyMon): Boolean {
        val target = resolveAlly(ally) ?: return false
        val p = repository.getPokemon(target.id) ?: return false
        val chain = p.chain
        val count = gameState.tokens[chain] ?: 0
        if (count < 1) {
            emit(BattleEvent.LogMessage("⚠ 증표가 부족합니다. (필요: 1개, 보유: ${count}개)"))
            return false
        }
        val others = p.abil.filter { it.isNotEmpty() && it[0] != target.ab }
        if (others.isEmpty()) {
            emit(BattleEvent.LogMessage("⚠ ${p.ko}은(는) 다른 특성이 없습니다."))
            return false
        }

        gameState.tokens[chain] = count - 1
        val hid = others.filter { it.size > 1 && it[1] == 1 }
        val nor = others.filter { it.size > 1 && it[1] == 0 }
        val picked = if (hid.isNotEmpty() && Random.nextDouble() < 0.1) {
            hid.random()
        } else if (nor.isNotEmpty()) {
            nor.random()
        } else {
            others.random()
        }
        val oldAbDto = repository.getAbility(target.ab)
        val newAbDto = repository.getAbility(picked[0])
        target.ab = picked[0]
        ally.ab = picked[0] // UI 복사본도 동기화
        emit(BattleEvent.LogMessage("💎 증표를 사용했다. ${p.ko}의 특성: ${oldAbDto?.ko ?: target.ab} → ${newAbDto?.ko ?: picked[0]}"))
        return true
    }

    /**
     * 증표 영구 강화 (공격 주기 및 필요 경험치 ×0.95 복리 단축)
     */
    fun upgradeTokenSpeed(ally: AllyMon): Boolean {
        val target = resolveAlly(ally) ?: return false
        val p = repository.getPokemon(target.id) ?: return false
        val chain = p.chain
        val count = gameState.tokens[chain] ?: 0
        val cost = BattleMath.tkCost(target.tb)
        if (count < cost) {
            emit(BattleEvent.LogMessage("⚠ 증표가 부족합니다. (필요: ${cost}개, 보유: ${count}개)"))
            return false
        }

        gameState.tokens[chain] = count - cost
        target.tb++
        ally.tb = target.tb // UI 복사본도 동기화
        val mult = 0.95.pow(target.tb.toDouble())
        emit(BattleEvent.LogMessage("💎 증표 ${cost}개로 영구 강화! ${p.ko}의 공격 주기·필요 EXP ×${String.format("%.2f", mult)} (강화 ${target.tb}회)"))
        return true
    }

    /**
     * 포맷 재정의: 포켓몬 삭제 및 지금까지 소모된 성장 재화(EXP, 증표) 80% 즉시 환급
     */
    fun formatMon(ally: AllyMon): Boolean {
        if (ally.id in setOf(1026, 1027)) return false
        val target = resolveAlly(ally) ?: return false
        val p = repository.getPokemon(target.id)
        val name = p?.ko ?: "포켓몬"
        val chainId = p?.chain ?: target.id

        // 1. 성장 재화 80% 환급 계산
        val expPerk = gameState.getEffectivePerk("exp")
        val totalExpSpent = BattleMath.calculateTotalExpSpent(target.lvl, target.tb, expPerk, gameState.K)
        val refundExp = (totalExpSpent * 0.8).coerceAtLeast(0.0)

        val totalTokensSpent = BattleMath.calculateTotalTokensSpent(target.tb)
        val refundTokens = (totalTokensSpent * 0.8).toInt().coerceAtLeast(0)

        // 2. 환급 지급
        gameState.exp += refundExp
        if (refundTokens > 0) {
            gameState.tokens[chainId] = (gameState.tokens[chainId] ?: 0) + refundTokens
        }

        // 3. 포켓몬 삭제 (파티 또는 보관 박스에서 완전히 제거)
        if (target.slot in 0..5) {
            gameState.team.removeAll { it.joined == target.joined || it.slot == target.slot }
        }
        synchronized(gameState.box) {
            gameState.box.removeAll { it.joined == target.joined }
        }

        val expText = if (refundExp > 0) BattleMath.fmtL(kotlin.math.log10(refundExp) + gameState.K) else "0"
        emit(BattleEvent.LogMessage("♻ ${name} 포맷 완료(삭제): EXP 80%(+${expText}) 및 증표 80%(+${refundTokens}개)가 환급되었습니다."))
        return true
    }

    /**
     * 포맷 시 환급될 예상 재화 계산 (EXP 환급액, 증표 환급액)
     */
    fun previewFormatRefund(ally: AllyMon): Pair<Double, Int> {
        val target = resolveAlly(ally) ?: ally
        val expPerk = gameState.getEffectivePerk("exp")
        val totalExpSpent = BattleMath.calculateTotalExpSpent(target.lvl, target.tb, expPerk, gameState.K)
        val refundExp = (totalExpSpent * 0.8).coerceAtLeast(0.0)
        val totalTokensSpent = BattleMath.calculateTotalTokensSpent(target.tb)
        val refundTokens = (totalTokensSpent * 0.8).toInt().coerceAtLeast(0)
        return Pair(refundExp, refundTokens)
    }

    /**
     * 박스 포켓몬 방생 (삭제)
     */
    fun releaseBoxMon(ally: AllyMon): Boolean = false

    /**
     * 파티 슬롯과 박스 포켓몬 교체 (인스턴스 및 joined 고유키 기준)
     */
    fun swapTeamAndBox(teamSlot: Int, boxMon: AllyMon) {
        val state = gameState
        val teamMon = state.team.find { it.slot == teamSlot }

        // 박스에서 대상 제거 (참조 또는 고유 식별자 joined 기준)
        val removedFromBox = state.box.remove(boxMon) || run {
            val idx = state.box.indexOfFirst { it.joined == boxMon.joined }
            if (idx >= 0) {
                state.box.removeAt(idx)
                true
            } else false
        }
        if (!removedFromBox) return

        if (teamMon != null) {
            state.team.remove(teamMon)
            teamMon.slot = -1
            if (teamMon.isMega) {
                val fusion = teamMon.ultraRevertFormId ?: teamMon.megaFormId?.takeIf { it == 10155 || it == 10156 }
                teamMon.isMega = fusion != null
                teamMon.megaFormId = fusion
                teamMon.ultraRevertFormId = null
                teamMon.megaDuration = if (fusion != null) 1.0e12 else 0.0
            }
            state.box.add(teamMon)
        }

        boxMon.slot = teamSlot
        boxMon.joined = ++state.seq
        state.team.add(boxMon)
        emit(BattleEvent.LogMessage("${repository.getPokemon(boxMon.id)?.ko ?: "포켓몬"}을(를) 파티 슬롯 ${teamSlot + 1}에 출전시켰다!"))
    }

    // --- 수치 계산 헬퍼 함수들 ---

    fun getEnemyLevel(): Int = 1 + floor(gameState.kills / 4.0).toInt()

    fun getExpReward(enemy: WildEnemy): Double {
        return enemy.lvl * 8.0 * 10.0.pow(-gameState.K.toDouble()) + enemy.maxHp / 10.0
    }

    fun isPokemonOwned(id: Int): Boolean {
        val chain = repository.getPokemon(id)?.chain ?: id
        return gameState.team.any { (repository.getPokemon(it.id)?.chain ?: it.id) == chain } ||
                gameState.box.any { (repository.getPokemon(it.id)?.chain ?: it.id) == chain }
    }

    fun buyShopItem(itemId: String): Boolean {
        if (repository.getHeldItem(itemId) == null || gameState.coins < 1) return false
        val count = gameState.items[itemId] ?: 0
        if (count == Int.MAX_VALUE) return false
        gameState.coins--
        gameState.items[itemId] = count + 1
        return true
    }

    fun canMegaEvolve(ally: AllyMon): Boolean {
        if (ally.id in com.pokeidle.app.data.model.ZygardeFusionData.allIds && (ally.id != 10120 || repository.getHeldItem(ally.item ?: "")?.ko != "지가르데나이트")) return false
        if (ally.id == 658 && AbilitySystem.has(ally, gameState.team, repository, "유대변화")) return true
        if (ally.id in setOf(384, 1027) && ally.move == 620) return true
        if (ally.id == 383) return ally.item == "red-orb"
        if (ally.id == 382) return ally.item == "blue-orb"
        val itemId = ally.item ?: return false
        return when {
            itemId == "max-mushroom" -> GigantamaxFormsData.canGigantamax(ally.id)
            itemId == "ultranecrozium-z" -> ally.id == 800 && ally.isMega &&
                ally.megaFormId in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID) &&
                repository.getMegas(ally.id).any { it.id == 10157 }
            else -> repository.getHeldItem(itemId)?.category == "mega-stones" &&
                getMegaFormForStone(ally.id, itemId, repository.getMegas(ally.id)) != null
        }
    }

    /** X/Y/Z 접미사가 붙은 메가스톤은 같은 접미사의 폼에만 대응한다. */
    private fun getMegaFormForStone(pokemonId: Int, itemId: String?, forms: List<com.pokeidle.app.data.model.MegaDto>)
        : com.pokeidle.app.data.model.MegaDto? {
        if (itemId == null) return null
        val item = repository.getHeldItem(itemId) ?: return null
        if (item.category != "mega-stones") return null
        val suffix = itemId.substringAfterLast('-').uppercase().takeIf { it in setOf("X", "Y", "Z") }
        val speciesForms = forms.ifEmpty { repository.getMegas(pokemonId) }
        if (suffix != null) return speciesForms.firstOrNull { it.suffix.equals(suffix, ignoreCase = true) }
        val unsuffixedForms = speciesForms.filter { it.suffix.isNullOrBlank() }
        return unsuffixedForms.singleOrNull() ?: speciesForms.singleOrNull()
    }

    fun getAllyInterval(ally: AllyMon): Double {
        val p = repository.getPokemon(ally.id) ?: return 1.0
        val fusion = getFusionForm(ally)
        val mega = if (ally.isMega && fusion == null && !GigantamaxFormsData.isForm(ally.megaFormId) && ally.megaFormId != -1) {
            repository.getMegas(ally.id).firstOrNull { it.id == ally.megaFormId }
                ?: repository.getMegas(ally.id).firstOrNull()
        } else null
        val activeStats = CanonicalStatsData.getActiveFormStat(ally)
        val spdStat = if (ally.id in ZygardeFusionData.allIds) activeStats?.spd ?: p.spd
            else fusion?.spd ?: activeStats?.spd ?: mega?.spd ?: p.spd
        val baseIv = max(0.5, 3.0 - spdStat / 60.0)
        val parMult = if (ally.status.par > 0.0) {
            if (AbilitySystem.has(ally, gameState.team, repository, "심술꾸러기")) 1.0 / 1.5 else 1.5
        } else 1.0

        val abilityMult = AbilitySystem.getSpeedMultiplier(
            ally, gameState.team, currentWeather?.weather, currentTerrain?.terrain, repository
        )
        val spdPerk = gameState.getEffectivePerk("spd")
        val tbMult = 10.0.pow(ally.tb * BattleMath.LOG10_0_95 + spdPerk * BattleMath.LOG10_0_95)

        // 구애스카프는 1개 장착 효과만 적용한다.
        val scarfMult = if (ally.item == "choice-scarf") 0.95 else 1.0
        return max(1e-9, baseIv * parMult * abilityMult * tbMult * scarfMult)
    }

    fun getEffectiveMoveType(ally: AllyMon): Int {
        if (ally.id == 10117 || (ally.isMega && ally.megaFormId == 10117)) return 11
        val move = repository.getMove(ally.move) ?: return 1
        return AbilitySystem.getEffectiveMoveType(ally, move.t, gameState.team, repository)
    }

    private fun getFusionForm(ally: AllyMon) = when {
        ally.id in ZygardeFusionData.allIds -> null
        ally.id == 800 && ally.isMega -> repository.getAllFormViews(800).firstOrNull { form ->
            (ally.megaFormId == NecrozmaFusionData.DUSK_MANE_FORM_ID && form.formKey == "necrozma_dusk_mane") ||
                (ally.megaFormId == NecrozmaFusionData.DAWN_WINGS_FORM_ID && form.formKey == "necrozma_dawn_wings")
        }
        else -> null
    }

    fun getBaseDamageL(ally: AllyMon, moveOverride: MoveDto? = null): Double {
        val p = repository.getPokemon(ally.id) ?: return 0.0
        val move = moveOverride ?: repository.getMove(ally.move)
        val fusion = getFusionForm(ally)
        val mega = if (ally.isMega && fusion == null && !GigantamaxFormsData.isForm(ally.megaFormId) && ally.megaFormId != -1) {
            repository.getMegas(ally.id).firstOrNull { it.id == ally.megaFormId }
                ?: repository.getMegas(ally.id).firstOrNull()
        } else null
        val activeStats = CanonicalStatsData.getActiveFormStat(ally)
        val atkStat = if (ally.id in ZygardeFusionData.allIds && activeStats != null) {
            if (move?.c == 3) activeStats.spa else activeStats.atk
        } else if (fusion != null) {
            if (move?.c == 3) (fusion.spa ?: p.spa) else (fusion.atk ?: p.atk)
        } else if (activeStats != null) {
            if (move?.c == 3) activeStats.spa else activeStats.atk
        } else if (mega != null) {
            if (move?.c == 3) (mega.spa ?: p.spa) else (mega.atk ?: p.atk)
        } else {
            if (move?.c == 3) p.spa else p.atk
        }
        val maxMushroomMult = if (ally.isMega && GigantamaxFormsData.isForm(ally.megaFormId)) 1.5 else 1.0

        val dexCount = gameState.caught.size
        val dexMult = 1.0 + 0.01 * dexCount
        val dmgPerk = gameState.getEffectivePerk("dmg")

        return log10(atkStat * maxMushroomMult * 0.25) +
                (ally.lvl - 1) * log10(1.1) +
                (ally.tb * BattleMath.LOG10_1_05) + // 강화 추가
                log10(dexMult) + (if (ally.rbOff) 0 else ally.rb) * log10(1.3) +
                dmgPerk * log10(1.2)
    }

    /** 현재 파티의 기본 공격력과 공격 주기 기준 이론 DPS의 log10 값 */
    fun getTeamDpsL(): Double {
        var total = Double.NEGATIVE_INFINITY
        gameState.team.forEach { ally ->
            val move = repository.getMove(ally.move) ?: return@forEach
            if (move.p <= 0.0) return@forEach
            val pokemon = repository.getPokemon(ally.id) ?: return@forEach
            val moveMultiplier = move.p / 50.0
            val stabMultiplier = if (move.t in pokemon.types) 2.0 else 1.0
            val dpsL = getBaseDamageL(ally) - gameState.K + log10(moveMultiplier * stabMultiplier) - log10(getAllyInterval(ally))
            total = BattleMath.logAdd(total, dpsL)
        }
        return if (total.isFinite()) total else 0.0
    }

    /** Approximate EXP per second on the current enemy, returned as log10(actual EXP). */
    fun getTeamExpPerSecondL(): Double {
        val enemy = gameState.enemy ?: return Double.NEGATIVE_INFINITY
        if (enemy.maxHp <= 0.0) return Double.NEGATIVE_INFINITY
        val dpsL = getTeamDpsL()
        if (!dpsL.isFinite()) return Double.NEGATIVE_INFINITY
        val abilityMult = AbilitySystem.getExpMultiplier(gameState.team, repository)
        val eggMult = if (gameState.team.any { it.item == "lucky-egg" }) 1.1 else 1.0
        return dpsL - log10(enemy.maxHp) + log10(getExpReward(enemy)) + log10(abilityMult * eggMult)
    }

    /** Grants capped idle earnings using the source game's 10% offline rate and 25% model factor. */
    fun applyOfflineProgress(elapsedSeconds: Double): Pair<Double, Long>? {
        if (gameState.team.isEmpty() || elapsedSeconds < 60.0) return null
        val enemy = gameState.enemy ?: return null
        val effectiveSeconds = elapsedSeconds.coerceAtMost(6.0 * 60.0 * 60.0) * 0.025
        val expRateL = getTeamExpPerSecondL()
        if (!expRateL.isFinite()) return null
        val earnedExpL = expRateL + log10(effectiveSeconds)
        val scaledExpL = earnedExpL - gameState.K
        val gainedExp = 10.0.pow(scaledExpL.coerceIn(-300.0, 300.0))
        if (!gainedExp.isFinite() || gainedExp <= 0.0) return null

        val oldKills = gameState.kills
        val hpL = log10(max(1e-300, enemy.maxHp)) + gameState.K
        val damageL = getTeamDpsL() + log10(effectiveSeconds)
        val estimatedKills = if (damageL > hpL) {
            10.0.pow((damageL - hpL).coerceAtMost(log10(3_000_000.0))).toLong().coerceAtMost(3_000_000L)
        } else 0L
        gameState.exp += gainedExp
        gameState.runExp += gainedExp
        gameState.totalL = BattleMath.logAdd(gameState.totalL, earnedExpL)
        gameState.kills += estimatedKills
        val levelAfter = getEnemyLevel()
        gameState.maxLvl = max(gameState.maxLvl, levelAfter)
        gameState.pballs += (gameState.kills / 100L - oldKills / 100L).toInt()
        gameState.balls += (gameState.kills / 200L - oldKills / 200L).toInt()
        gameState.mballs += (gameState.kills / 1000L - oldKills / 1000L).toInt()
        if (estimatedKills > 0L) {
            gameState.enemy = null
            spawnEnemy()
        }
        normalizeScale()
        return earnedExpL to estimatedKills
    }

    fun calculateDamage(ally: AllyMon, enemy: WildEnemy): Pair<Double, Double> {
        val p = repository.getPokemon(ally.id) ?: return Pair(0.0, 1.0)
        val ultraBurstZMoveActive = ally.item == "ultranecrozium-z" && ally.id == 800 && ally.isMega && ally.megaFormId == 10157 && ally.move == 722
        val baseMove = if (ally.id == 10117 || (ally.isMega && ally.megaFormId == 10117))
            MoveDto(t = 11, p = 90.0, c = 3, ko = "물수리검")
        else repository.getBattleMove(ally) ?: return Pair(0.0, 1.0)
        val isDynamax = ally.isMega && GigantamaxFormsData.isForm(ally.megaFormId)
        val move = when {
            ultraBurstZMoveActive -> MoveDto(t = 14, p = 200.0, c = 3, ko = "하늘을 태우는 멸망의 빛")
            isDynamax -> baseMove.copy(p = GigantamaxFormsData.getTransformedMovePower(baseMove.t, baseMove.p), ko = GigantamaxFormsData.getTransformedMoveName(baseMove.t))
            else -> baseMove
        }
        val enemyPokemon = repository.getPokemon(enemy.id) ?: return Pair(0.0, 1.0)

        // 씨뿌리기 (73): 적 최대체력의 1/32
        if (!isDynamax && !ultraBurstZMoveActive && ally.move == 73) {
            return Pair(enemy.maxHp / 32.0, 1.0)
        }
        // 도우미(270) / 드래곤옐(913, 811): 직접 공격 안 함
        if (!isDynamax && !ultraBurstZMoveActive && (ally.move == 270 || ally.move == 913 || ally.move == 811)) {
            return Pair(0.0, 1.0)
        }

        val baseDmgL = getBaseDamageL(ally, move)
        val baseDmg = 10.0.pow(min(300.0, baseDmgL - gameState.K))

        val moveType = if (ultraBurstZMoveActive) 14 else if (isDynamax) baseMove.t else getEffectiveMoveType(ally)
        val activeZMove = ally.item?.takeIf { ally.status.zMoveDuration > 0.0 || ultraBurstZMoveActive }?.let { itemId ->
            ZMoveData.resolve(itemId, ally.id, ally.move, moveType, move.p, ally.megaFormId)
        }
        if (activeZMove != null && ally.item == "tapunium-z--held") return Pair(enemy.hp * 0.75, 1.0)
        if (activeZMove != null && ally.item == "eevium-z--held") return Pair(0.0, 1.0)
        if (activeZMove == null && ally.move == 717) return Pair(enemy.hp * 0.5, 1.0)
        var movePower = activeZMove?.power ?: move.p
        if (activeZMove == null) {
            if (AbilitySystem.has(ally, gameState.team, repository, "스킬링크")) movePower = 125.0
            if (AbilitySystem.has(ally, gameState.team, repository, "테크니션") && movePower <= 60.0) movePower *= 1.5
        }
        val weather = currentWeather
        val terrain = currentTerrain
        val baseWeatherMult = WeatherTerrainSystem.getWeatherMultiplier(moveType, weather?.weather)
        val baseTerrainMult = WeatherTerrainSystem.getTerrainMultiplier(moveType, terrain?.terrain)
        // 그라운드코트는 장착한 포켓몬이 직접 만든 날씨/필드의 유리한 배율만 강화한다.
        val weatherMult = if (baseWeatherMult > 1.0 && weather?.setter?.item == "terrain-extender") baseWeatherMult * 1.1 else baseWeatherMult
        val terrainMult = if (baseTerrainMult > 1.0 && terrain?.setter?.item == "terrain-extender") baseTerrainMult * 1.1 else baseTerrainMult

        val rank = ally.status.rank.coerceIn(-6, 6)
        val rankM = if (rank != 0) 2.0 / (2.0 - rank) else 1.0
        val rankMult = if (AbilitySystem.has(ally, gameState.team, repository, "심술꾸러기")) 1.0 / rankM else rankM

        val burnPenalty = if (ally.status.brn > 0.0) 0.5 else 1.0
        val poisonPenalty = if (ally.status.psn > 0.0) 0.7 else 1.0

        var d = baseDmg * (movePower / 50.0) * weatherMult * terrainMult * rankMult * burnPenalty * poisonPenalty

        // 현재 폼의 타입으로 자속을 판정한다. 같은 타입 기술은 2배 피해.
        val activeMegaTypes = getFusionForm(ally)?.types ?: if (ally.isMega) {
            repository.getMegas(ally.id).firstOrNull { it.id == ally.megaFormId }?.types
                ?.takeIf { it.isNotEmpty() }
        } else null
        var allyTypes = activeMegaTypes ?: p.types
        if (AbilitySystem.has(ally, gameState.team, repository, "리베로", "변환자재")) {
            allyTypes = listOf(moveType)
        }
        if (ally.status.color != null && AbilitySystem.has(ally, gameState.team, repository, "변색")) {
            allyTypes = ally.status.color!!
        }

        if (moveType in allyTypes) {
            d *= 2.0
            if (AbilitySystem.has(ally, gameState.team, repository, "적응력")) {
                d *= 1.33
            }
        }

        // 특성 데미지 배율
        d *= AbilitySystem.getDamageMultiplier(ally, moveType, gameState.team, currentWeather?.weather, currentTerrain?.terrain, repository)

        // 상성 배율
        var enemyTypes = enemyPokemon.types
        if (AbilitySystem.has(ally, gameState.team, repository, "배짱", "심안") && (moveType == 1 || moveType == 2)) {
            enemyTypes = enemyTypes.filter { it != 8 } // 고스트 무효 무시
        }
        if (AbilitySystem.has(ally, gameState.team, repository, "부식") && moveType == 4) {
            enemyTypes = enemyTypes.filter { it != 9 } // 강철 독 무효 무시
        }

        var eff = if (ally.id == 493 && ally.item == "legend-plate" && ally.move == 449) 2.0 else repository.getTypeEff(moveType, enemyTypes)
        if (AbilitySystem.has(ally, gameState.team, repository, "색안경") && eff < 1.0 && eff > 0.1) {
            eff = 1.0
        }
        if (AbilitySystem.has(ally, gameState.team, repository, "브레인포스") && eff > 1.0) {
            d *= 1.25
        }

        // 적 버프 경감
        val ignoreScreens = AbilitySystem.has(ally, gameState.team, repository, "틈새포착", "터보블레이즈", "테라볼티지") ||
                AbilitySystem.teamHas(gameState.team, repository, "배리어프리")
        val ignoreRanks = AbilitySystem.has(ally, gameState.team, repository, "보이지않는주먹", "천진")
        d *= ResistSystem.getEnemyMitigation(move.c, enemy.enemyBuffs, ignoreScreens, ignoreRanks)

        // 재앙 특성 (1.2배)
        if (AbilitySystem.teamHas(gameState.team, repository, "재앙의검", "재앙의구슬")) d *= 1.2
        // 정의의마음 (적이 악타입일 때 1.5배)
        if (17 in enemyPokemon.types && AbilitySystem.has(ally, gameState.team, repository, "정의의마음")) d *= 1.5
        // 도우미 동료들의 버프 누적
        val helpers = gameState.team.filter { it !== ally && it.move == 270 }
        if (helpers.isNotEmpty()) {
            val maxLvl = helpers.maxOf { it.lvl }
            d *= 1.5 + (maxLvl / 100.0)
        }

        // 도구(Held Item) 데미지 배율 적용
        d *= getItemDamageMultiplier(ally, moveType, move, eff > 1.0)

        val totalDmg = min(1e300, max(0.0, d * eff))
        return Pair(totalDmg, eff)
    }

    /**
     * 포켓몬이 장착한 도구 1개의 데미지 효과 계산
     */
    fun getItemDamageMultiplier(ally: AllyMon, moveType: Int, move: MoveDto, isSuperEffective: Boolean): Double {
        val itemId = ally.item ?: return 1.0
        val item = repository.getHeldItem(itemId) ?: return 1.0
        if (gameState.getItemStack(itemId) <= 0) return 1.0
        val mult = 1.1

        return when {
            // Z크리스탈은 해당 타입 기술에만 1.2배 적용한다.
            item.category == "z-crystals" -> {
                if ((ally.status.zMoveDuration > 0.0 || (itemId == "ultranecrozium-z" && ally.isMega && ally.megaFormId == 10157)) &&
                    ZMoveData.resolve(itemId, ally.id, ally.move, moveType, move.p, ally.megaFormId) != null) 1.0
                else 1.0
            }
            // src.html의 타입 강화 도구
            item.kind == "type" -> {
                if (item.type == moveType) mult else 1.0
            }
            item.kind == "phys" -> {
                if (move.c != 3) mult else 1.0
            }
            item.kind == "spec" -> {
                if (move.c == 3) mult else 1.0
            }
            item.kind == "belt" -> {
                if (isSuperEffective) 1.15 else 1.0
            }
            item.kind == "orb" -> {
                1.3
            }
            item.kind == "evio" -> {
                val p = repository.getPokemon(ally.id)
                if (p != null && p.evo.isNotEmpty()) mult else 1.0
            }
            item.kind?.startsWith("seed:") == true -> {
                val requiredTerrain = item.kind.removePrefix("seed:")
                val current = currentTerrain?.terrain?.name?.lowercase() ?: ""
                if (current.contains(requiredTerrain)) mult else 1.0
            }
            else -> 1.0
        }
    }

    /**
     * 특정 도구의 현재 배율 계산 (표시용)
     */
    fun getItemMultiplier(itemId: String?, stack: Int = 1): Double {
        if (itemId == null || stack <= 0) return 1.0
        val item = repository.getHeldItem(itemId) ?: return 1.0
        val base = when {
            item.kind == "scarf" || item.kind == "leftovers" || item.kind == "amulet" -> 0.95
            item.kind == "belt" -> 1.15
            item.kind == "orb" -> 1.3
            item.category == "z-crystals" -> 1.2
            item.kind == "type" || item.kind == "phys" || item.kind == "spec" || item.kind == "evio" || item.kind.startsWith("seed:") -> 1.1
            else -> 1.0
        }
        return base
    }

    /** src.html의 학습장치 효과를 퀘스트 경험치 보상에 적용한다. */
    fun applyQuestRewardItemBonus(baseReward: Double): Double =
        if (gameState.team.any { it.item == "exp-share" }) baseReward * 1.1 else baseReward

    /**
     * 포켓몬에 도구 장착/해제. 동일 도구는 보유 수량만큼 여러 포켓몬이 장착할 수 있다.
     */
    fun equipItem(ally: AllyMon, itemId: String?): Boolean {
        val target = resolveAlly(ally) ?: ally
        if (itemId == null) {
            val prev = target.item
            target.item = null
            ally.item = null
            if (prev != null) {
                val prevDto = repository.getHeldItem(prev)
                emit(BattleEvent.ItemEquipped(target.slot, null, prevDto?.ko ?: "도구"))
            }
            return true
        }

        val itemDto = repository.getHeldItem(itemId) ?: return false
        if (itemDto.ko == "지가르데나이트" && target.id != 10120) return false
        if (itemId == "ash-greninjite" && target.id !in setOf(658, 10117)) return false
        if ((itemId == "red-orb" && target.id != 383) || (itemId == "blue-orb" && target.id != 382)) return false
        if (itemId == "legend-plate" && target.id != 493) return false
        if (itemDto.category == "z-crystals" && itemId != "ultranecrozium-z" && !ZMoveData.canEquip(itemId, target.id)) return false
        if (itemId == "max-mushroom" && !GigantamaxFormsData.canGigantamax(target.id)) return false
        if (itemId == "ultranecrozium-z" && (target.id != 800 || !target.isMega ||
                target.megaFormId !in setOf(NecrozmaFusionData.DUSK_MANE_FORM_ID, NecrozmaFusionData.DAWN_WINGS_FORM_ID))) return false
        val stack = gameState.getItemStack(itemId)
        if (stack <= 0) return false
        val equippedCount = (gameState.team + gameState.box).count { it.item == itemId }
        if (target.item != itemId && equippedCount >= stack) return false

        val fusionFormId = NecrozmaFusionData.formIdForItem(itemId)
        if (fusionFormId != null) {
            if (target.id != 800 || target.isMega) return false
            val partnerId = NecrozmaFusionData.partnerIdForItem(itemId) ?: return false
            val partner = gameState.team.firstOrNull { it.id == partnerId }
                ?: gameState.box.firstOrNull { it.id == partnerId }
                ?: return false
            gameState.team.remove(partner)
            gameState.box.remove(partner)
            gameState.items[itemId] = stack - 1
            target.item = null
            target.isMega = true
            target.megaFormId = fusionFormId
            target.megaDuration = 1.0e12 // 융합은 시간 제한 없이 유지
            target.mg = 0.0
            ally.item = null
            ally.isMega = true
            ally.megaFormId = fusionFormId
            ally.megaDuration = target.megaDuration
            ally.mg = 0.0
            emit(BattleEvent.LogMessage("${itemDto.ko}을(를) 사용해 네크로즈마가 융합했다. 네크로즈마, 파트너, 도구가 소모되었다."))
            emit(BattleEvent.MegaEvolution(target.slot, if (fusionFormId == NecrozmaFusionData.DUSK_MANE_FORM_ID) "황혼의 갈기" else "새벽의 날개"))
            return true
        }

        target.item = itemId
        ally.item = itemId
        emit(BattleEvent.ItemEquipped(target.slot, itemId, itemDto.ko))
        return true
    }

    private fun getMissChance(ally: AllyMon): Double {
        val s = ally.status
        var miss = 0.0
        if (s.cnf > 0.0) miss += 0.5
        if (s.acc > 0.0) {
            val ignoresAcc = AbilitySystem.teamHas(gameState.team, repository, "노가드", "발광", "승리의별") ||
                    AbilitySystem.has(ally, gameState.team, repository, "복안", "심안")
            if (!ignoresAcc) miss += 0.3
        }
        if (AbilitySystem.has(ally, gameState.team, repository, "무아지경", "의욕")) {
            miss += 0.2
        }
        return miss
    }

    /**
     * 큰 수 스케일링 지수 K 시프트 정규화 (normalizeScale)
     */
    fun normalizeScale() {
        val l = getEnemyLevel()
        var lmax = if (gameState.exp > 0) log10(gameState.exp) + gameState.K else 0.0
        gameState.enemy?.let {
            lmax = max(lmax, log10(max(1e-300, it.maxHp)) + gameState.K)
        }
        lmax = max(lmax, log10(1500.0) + (l - 1) * log10(1.12))

        for (ally in gameState.team) {
            lmax = max(lmax, getBaseDamageL(ally) + 1.0)
            lmax = max(lmax, BattleMath.levelUpCostL(ally.lvl, ally.tb, gameState.getEffectivePerk("exp")))
        }

        var want = if (lmax > 200.0) kotlin.math.ceil((lmax - 150.0) / 50.0).toInt() * 50 else 0
        val lhp = log10(1500.0) + (l - 1) * log10(1.12)
        if (lhp - want < -200.0) {
            want = max(0, kotlin.math.floor((lhp + 100.0) / 50.0).toInt() * 50)
        }

        val cur = gameState.K
        if (want != cur) {
            val f = 10.0.pow((cur - want).toDouble())
            gameState.K = want
            gameState.exp *= f
            gameState.runExp *= f
            gameState.enemy?.let {
                it.hp *= f
                it.maxHp *= f
            }
            for (q in gameState.quests) {
                q.rewardExp *= f
            }
        }
    }
}
