package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.presentation.components.PokemonSprite
import com.pokeidle.app.presentation.components.TypeBadge

@Composable
fun StarterSelectionDialog(
    starters: List<PokemonDto>,
    onSelectStarter: (Int) -> Unit
) {
    Dialog(onDismissRequest = { /* 반드시 선택해야 하므로 닫기 방지 */ }) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(16.dp),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "함께 떠날 포켓몬을 고르세요",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "1~9세대 스타터와 피카츄 중 하나를 선택하세요.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(starters) { starter ->
                        StarterCard(
                            starter = starter,
                            onClick = { onSelectStarter(starter.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StarterCard(
    starter: PokemonDto,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, Color(0xFFCCD5CA), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            PokemonSprite(
                imgBase64 = starter.img,
                contentDescription = starter.ko,
                size = 56.dp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = starter.ko,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${starter.gen}세대",
                fontSize = 10.sp,
                color = Color(0xFF5A665E)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                starter.types.forEach { t ->
                    TypeBadge(typeId = t)
                }
            }
        }
    }
}
