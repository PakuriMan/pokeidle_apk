package com.pokeidle.app.data.model

/** Type Z moves and Pokémon specific Z moves used by the battle engine and UI. */
object ZMoveData {
    data class ZMove(val name: String, val power: Double)

    fun canEquip(itemId: String, pokemonId: Int): Boolean = when (itemId) {
        "pikanium-z--held" -> pokemonId == 25
        "pikashunium-z--held" -> isCapPikachu(pokemonId)
        "decidium-z--held" -> pokemonId == 724
        "incinium-z--held" -> pokemonId == 727
        "primarium-z--held" -> pokemonId == 730
        "tapunium-z--held" -> pokemonId in 785..788
        "marshadium-z--held" -> pokemonId == 802
        "aloraichium-z--held" -> pokemonId == 10100
        "snorlium-z--held" -> pokemonId == 143
        "eevium-z--held" -> pokemonId == 133
        "mewnium-z--held" -> pokemonId == 151
        "lycanium-z--held" -> pokemonId in setOf(745, 10126, 10152)
        "mimikium-z--held" -> pokemonId in setOf(778, 10143, 10144, 10145)
        "kommonium-z--held" -> pokemonId == 784
        "solganium-z--held" -> pokemonId == 791 || pokemonId == 800
        "lunalium-z--held" -> pokemonId == 792 || pokemonId == 800
        else -> true
    }

    private val typeMoves = mapOf(
        1 to "울트라대시어택", 2 to "전력무쌍격렬권", 3 to "파이널다이브클래시",
        4 to "애시드포이즌딜리트", 5 to "라이징랜드오버", 6 to "월즈엔드폴",
        7 to "절대포식회전참", 8 to "무한암야로의유인", 9 to "초월나선연격",
        10 to "다이내믹풀플레임", 11 to "슈퍼아쿠아토네이도", 12 to "블룸샤인엑스트라",
        13 to "스파킹기가볼트", 14 to "맥시멈사이브레이커", 15 to "레이징지오프리즈",
        16 to "얼티메이트드래곤번", 17 to "블랙홀이클립스", 18 to "아름다운페어리오라"
    )

    /** Returns the Z-move name and base power for the held crystal and selected move. */
    fun resolve(itemId: String, pokemonId: Int, moveId: Int, moveType: Int, movePower: Double, formId: Int? = null): ZMove? {
        when (itemId) {
            "ultranecrozium-z" -> if (pokemonId == 800 && formId == 10157 && moveId == 722) {
                return ZMove("하늘을 태우는 멸망의 빛", 200.0)
            }
            "pikashunium-z--held" -> if (pokemonId in CAP_PIKACHU_IDS && moveId == 85) return ZMove("1000만볼트", 195.0)
            "pikanium-z--held" -> if (pokemonId == 25 && moveId == 344) return ZMove("필살피카슛", 210.0)
            "decidium-z--held" -> if (pokemonId == 724 && moveId == 662) return ZMove("섀도애로우즈스트라이크", 180.0)
            "incinium-z--held" -> if (pokemonId == 727 && moveId == 663) return ZMove("하이퍼다크크러셔", 180.0)
            "primarium-z--held" -> if (pokemonId == 730 && moveId == 664) return ZMove("바다의심포니", 195.0)
            "tapunium-z--held" -> if (pokemonId in 785..788 && moveId == 717) return ZMove("알로라의수호자", 150.0)
            "marshadium-z--held" -> if (pokemonId == 802 && moveId == 712) return ZMove("칠성탈혼퇴", 195.0)
            "aloraichium-z--held" -> if (pokemonId == 10100 && moveId == 85) return ZMove("라이트닝서프라이드", 175.0)
            "snorlium-z--held" -> if (pokemonId == 143 && moveId == 416) return ZMove("진심의공격", 210.0)
            "eevium-z--held" -> if (pokemonId == 133 && moveId == 387) return ZMove("나인이볼부스트", 0.0)
            "mewnium-z--held" -> if (pokemonId == 151 && moveId == 94) return ZMove("오리진즈슈퍼노바", 185.0)
            "lycanium-z--held" -> if (pokemonId in setOf(745, 10126, 10152) && moveId == 444) return ZMove("레이디얼에지스톰", 190.0)
            "mimikium-z--held" -> if (pokemonId in setOf(778, 10143, 10144, 10145) && moveId == 583) return ZMove("투닥투닥프렌드타임", 190.0)
            "kommonium-z--held" -> if (pokemonId == 784 && moveId == 691) return ZMove("브레이징소울비트", 185.0)
            "solganium-z--held" -> if ((pokemonId == 791 || (pokemonId == 800 && formId == 10155)) && moveId == 713) return ZMove("선샤인스매셔", 200.0)
            "lunalium-z--held" -> if ((pokemonId == 792 || (pokemonId == 800 && formId == 10156)) && moveId == 714) return ZMove("문라이트블래스터", 200.0)
        }

        val typeId = when (itemId) {
            "normalium-z--held" -> 1
            "fightinium-z--held" -> 2
            "flyinium-z--held" -> 3
            "poisonium-z--held" -> 4
            "groundium-z--held" -> 5
            "rockium-z--held" -> 6
            "buginium-z--held" -> 7
            "ghostium-z--held" -> 8
            "steelium-z--held" -> 9
            "firium-z--held" -> 10
            "waterium-z--held" -> 11
            "grassium-z--held" -> 12
            "electrium-z--held" -> 13
            "psychium-z--held" -> 14
            "icium-z--held" -> 15
            "dragonium-z--held" -> 16
            "darkinium-z--held" -> 17
            "fairium-z--held" -> 18
            else -> null
        }
        if (typeId != moveType || movePower <= 0.0) return null
        return ZMove(typeMoves[typeId] ?: "Z기술", typeZPower(moveId, movePower))
    }

    private fun typeZPower(moveId: Int, power: Double): Double = when (moveId) {
        72 -> 120.0   // Mega Drain
        311 -> 160.0  // Weather Ball
        506 -> 160.0  // Hex
        557 -> 220.0  // V-create
        560 -> 170.0  // Flying Press
        687 -> 140.0  // Core Enforcer
        718 -> 185.0  // Multi-Attack
        else -> when {
            power <= 55.0 -> 100.0
            power <= 65.0 -> 120.0
            power <= 75.0 -> 140.0
            power <= 85.0 -> 160.0
            power <= 95.0 -> 175.0
            power <= 100.0 -> 180.0
            power <= 110.0 -> 185.0
            power <= 120.0 -> 190.0
            power <= 130.0 -> 195.0
            else -> 200.0
        }
    }

    fun isCapPikachu(pokemonId: Int): Boolean = pokemonId in CAP_PIKACHU_IDS

    fun typeName(typeId: Int): String? = typeMoves[typeId]

    private val CAP_PIKACHU_IDS = setOf(10094, 10095, 10096, 10097, 10098, 10099, 10148, 10160)
}
