package com.pokeidle.app.data.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.pokeidle.app.data.local.db.PokeIdleDatabaseHelper
import com.pokeidle.app.domain.model.GameState
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * .psv (PokéIdle Save) 파일의 무결성 검증, 내보내기(Export) 및 가져오기(Import)를 총괄하는 매니저
 */
class PsvFileManager(
    private val context: Context,
    private val dbHelper: PokeIdleDatabaseHelper
) {

    companion object {
        // SQLite 파일 헤더의 16바이트 매직 문자열: "SQLite format 3\0"
        private val SQLITE_MAGIC_HEADER = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
    }

    /**
     * 내부 SQLite 데이터베이스 파일을 단일 .psv 파일로 내보냅니다.
     *
     * @param destinationStream 유저가 지정한 파일 대상의 OutputStream (예: SAF Uri, 백업 파일 등)
     * @return 성공 시 Result.success(Unit), 실패 시 Result.failure(Exception)
     */
    fun exportToPsv(destinationStream: OutputStream): Result<Unit> = runCatching {
        if (!dbHelper.hasSave()) {
            throw IllegalStateException("내보낼 세이브 데이터가 존재하지 않습니다.")
        }

        // 1. WAL 저널의 모든 변경사항을 메인 .psv 파일로 체크포인트 플러시
        dbHelper.checkpointWal()

        // 2. 내부 DB 파일 위치 탐색
        val dbFile = context.getDatabasePath(PokeIdleDatabaseHelper.DATABASE_NAME)
        if (!dbFile.exists() || dbFile.length() == 0L) {
            throw IllegalStateException("데이터베이스 파일이 비어있거나 존재하지 않습니다.")
        }

        // 3. 파일 스트림 복사
        FileInputStream(dbFile).use { input ->
            destinationStream.use { output ->
                input.copyTo(output, bufferSize = 8192)
                output.flush()
            }
        }
    }

    /**
     * 외부 .psv 파일로부터 데이터를 읽어 무결성을 엄격하게 검증한 후,
     * 내부 SQLite 데이터베이스를 교체하고 복원된 GameState를 반환합니다.
     *
     * @param sourceStream 가져올 .psv 파일의 InputStream (예: SAF Uri)
     * @return 성공 시 복원된 Result.success(GameState), 검증 실패 시 Result.failure(Exception)
     */
    fun importFromPsv(sourceStream: InputStream): Result<GameState> = runCatching {
        val stagingFile = File(context.cacheDir, "pokeidle_import_staging.tmp")
        try {
            // 1. 스트림을 임시 스테이징 파일로 복사
            FileOutputStream(stagingFile).use { output ->
                sourceStream.use { input ->
                    input.copyTo(output, bufferSize = 8192)
                    output.flush()
                }
            }

            // 2. SQLite 매직 헤더 검증 (최소 100바이트 및 16바이트 시그니처)
            if (stagingFile.length() < 100L) {
                throw IllegalArgumentException("유효하지 않은 파일 크기입니다. 정상적인 .psv 파일이 아닙니다.")
            }

            val headerBytes = ByteArray(16)
            FileInputStream(stagingFile).use { input ->
                val readBytes = input.read(headerBytes)
                if (readBytes != 16 || !headerBytes.contentEquals(SQLITE_MAGIC_HEADER)) {
                    throw IllegalArgumentException("파일 헤더가 올바른 SQLite .psv 규격이 아닙니다.")
                }
            }

            // 3. SQLite DB 무결성 및 스키마 검증
            validateStagingDatabase(stagingFile)

            // 4. 기존 DB 락 해제 및 안전한 파일 교체
            dbHelper.close()

            val targetDbFile = context.getDatabasePath(PokeIdleDatabaseHelper.DATABASE_NAME)
            val walFile = File(targetDbFile.parentFile, "${targetDbFile.name}-wal")
            val shmFile = File(targetDbFile.parentFile, "${targetDbFile.name}-shm")
            val journalFile = File(targetDbFile.parentFile, "${targetDbFile.name}-journal")

            // 잔여 저널 파일 정리
            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()
            if (journalFile.exists()) journalFile.delete()

            // 대상 디렉토리 보장
            targetDbFile.parentFile?.mkdirs()

            // 원자적 파일 이동 (실패 시 스트림 복사)
            if (!stagingFile.renameTo(targetDbFile)) {
                FileInputStream(stagingFile).use { input ->
                    FileOutputStream(targetDbFile).use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
            }

            // 5. DB 재오픈 및 복원된 상태 로드
            val restoredState = dbHelper.loadGameState()
                ?: throw IllegalStateException("세이브 파일 복원 후 데이터를 읽어오지 못했습니다.")

            restoredState
        } finally {
            if (stagingFile.exists()) {
                stagingFile.delete()
            }
        }
    }

    /**
     * 스테이징된 파일이 올바른 포켓몬 아이들 배틀 세이브 DB인지 검사합니다.
     */
    private fun validateStagingDatabase(file: File) {
        var tempDb: SQLiteDatabase? = null
        try {
            tempDb = SQLiteDatabase.openDatabase(
                file.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY
            )

            // 무결성 체크
            val cursor = tempDb.rawQuery("PRAGMA integrity_check;", null)
            val isOk = cursor.use {
                if (it.moveToFirst()) {
                    it.getString(0).equals("ok", ignoreCase = true)
                } else false
            }
            if (!isOk) {
                throw IllegalStateException("데이터베이스 무결성 검사에 실패했습니다 (손상된 세이브).")
            }

            // 필수 테이블 존재 여부 확인
            val tableCursor = tempDb.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='game_metadata';",
                null
            )
            val hasMetadata = tableCursor.use { it.moveToFirst() }
            if (!hasMetadata) {
                throw IllegalArgumentException("포켓몬 아이들 배틀 세이브 데이터(game_metadata)가 포함되어 있지 않습니다.")
            }
        } finally {
            tempDb?.close()
        }
    }
}
