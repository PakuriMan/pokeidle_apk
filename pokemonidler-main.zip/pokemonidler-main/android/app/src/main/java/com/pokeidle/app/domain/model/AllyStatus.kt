package com.pokeidle.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 변덕쟁이 특성 무작위 버프치
 */
@Serializable
data class WhimBuff(
    val iv: Double = 1.0,
    val d: Double = 1.0
)

/**
 * 동료 포켓몬의 전투 중 상태이상 및 랭크 변화
 */
@Serializable
data class AllyStatus(
    var rank: Int = 0,             // 위력 랭크 (-6 ~ +6)
    var rankLeft: Double = 0.0,    // 랭크 변화 잔여 시간(초, 기본 40초)
    var psn: Double = 0.0,         // 독 상태 잔여 시간 (25초)
    var tox: Double = 0.0,         // 맹독 상태 잔여 시간 (40초)
    var brn: Double = 0.0,         // 화상 상태 잔여 시간 (20초)
    var par: Double = 0.0,         // 마비 상태 잔여 시간 (20초)
    var slp: Double = 0.0,         // 잠듦 상태 잔여 시간 (8초)
    var frz: Double = 0.0,         // 얼음 상태 잔여 시간 (7초)
    var cnf: Double = 0.0,         // 혼란 상태 잔여 시간 (13초)
    var acc: Double = 0.0,         // 명중 저하 잔여 시간 (25초)

    // 특성 발동 버프 타이머
    var wb: Double = 0.0,          // 깨어진갑옷 지속 시간 (10초)
    var rage: Double = 0.0,        // 발끈 / 분노의경혈 지속 시간 (10초)
    var shell: Double = 0.0,       // 분노의껍질 지속 시간 (8초)
    var kill: Double = 0.0,        // 백의울음 / 흑의울음 / 자기과신 / 비스트부스트 / 소울하트 (15초)
    var steam: Double = 0.0,       // 증기기관 지속 시간 (10초)
    var charge: Boolean = false,   // 전기로바꾸기 충전 상태 (다음 전기 기술 위력 2배)
    var color: List<Int>? = null,  // 변색으로 바뀐 타입 목록
    var quick: Boolean = false,    // 퀵드로 발동 상태
    var whim: WhimBuff? = null,    // 변덕쟁이 버프
    var lifeOrbAttackCount: Int = 0, // 생명의구슬 연속 공격 횟수
    var lifeOrbRest: Double = 0.0, // 생명의구슬 휴식 잔여 시간
    var zMoveDuration: Double = 0.0 // Z기술 변환 잔여 시간
) {
    /**
     * 증기기관 활성화 여부
     */
    val steamEngine: Boolean get() = steam > 0.0

    /**
     * 분노의경혈 / 발끈 활성화 여부
     */
    val angerPoint: Boolean get() = rage > 0.0

    /**
     * 퀵드로 활성화 여부
     */
    val quickDraw: Boolean get() = quick

    /**
     * 부정적 상태이상 또는 랭크 저하가 있는지 여부 ("회복 돕기" 버튼 활성화 기준)
     */
    val hasAilment: Boolean
        get() = rank < 0 || acc > 0.0 || psn > 0.0 || tox > 0.0 || brn > 0.0 || par > 0.0 || slp > 0.0 || frz > 0.0 || cnf > 0.0

    /**
     * 화면에 표시할 상태 태그가 있는지 여부 (자가 버프 태그 포함)
     */
    val hasTags: Boolean
        get() = hasAilment || rank > 0 || wb > 0.0 || rage > 0.0 || shell > 0.0 || kill > 0.0 || steam > 0.0 || charge || color != null

    /**
     * 잠듦 또는 얼음 상태로 행동 불능 여부
     */
    val isAsleepOrFrozen: Boolean
        get() = slp > 0.0 || frz > 0.0
}
