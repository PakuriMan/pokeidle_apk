package com.pokeidle.app.domain.math

import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * 포켓몬 아이들 배틀의 핵심 수학 및 로그 스케일 연산 공식 모음 (순수 도메인 로직)
 */
object BattleMath {

    const val LOG10_1_05 = 0.021189299069938054  // log10(1.05)
    const val LOG10_1_12 = 0.049218022670181514  // log10(1.12)
    const val LOG10_1_25 = 0.09691001300805642   // log10(1.25)
    const val LOG10_1_6 = 0.2041199826559248     // log10(1.6)
    const val LOG10_0_95 = -0.02227639471115228  // log10(0.95)
    const val LOG10_1500 = 3.176091259055681      // log10(1500)
    const val LOG10_50 = 1.6989700043360187       // log10(50)

    // 큰 수 축약 표기 단위 접미사 접두어
    private val UNITS = arrayOf(
        "", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No",
        "Dc", "Ud", "Dd", "Td", "Qad", "Qid", "Sxd", "Spd", "Ocd", "Nod", "Vg"
    )

    /**
     * 두 로그값의 덧셈: log10(10^a + 10^b)
     */
    fun logAdd(a: Double, b: Double): Double {
        if (a.isNaN() || a <= -300.0) return b
        if (b.isNaN() || b <= -300.0) return a
        val m = max(a, b)
        val d = kotlin.math.abs(a - b)
        return if (d > 16.0) m else m + log10(1.0 + 10.0.pow(-d))
    }

    /**
     * 두 로그값의 뺄셈: log10(10^a - 10^b) (단, a >= b)
     */
    fun logSub(a: Double, b: Double): Double {
        if (a <= b) return -300.0
        val d = a - b
        return if (d > 16.0) a else a + log10(1.0 - 10.0.pow(-d))
    }

    /**
     * 스피드 폴딩: 공격 주기가 TICK(0.1초) 미만일 때 압축 공식
     * speedFold(n) = n (n <= 1), 1 + log2(1 + log10(n)) (n > 1)
     */
    fun speedFold(n: Double): Double {
        return if (n <= 1.0) {
            n
        } else {
            1.0 + log2(1.0 + log10(n))
        }
    }

    /**
     * 적 체력의 로그값 (L_hp) — 원작 웹 규격: Math.log10(p.hp * 1.5) + (lvl - 1) * Math.log10(1.12)
     */
    fun enemyHpL(baseHp: Double, lvl: Int): Double {
        val h = max(10.0, baseHp * 1.5)
        return log10(h) + (lvl - 1).coerceAtLeast(0) * LOG10_1_12
    }

    /**
     * 적 체력의 로그값 (L_hp 기본 fallback / 상한 추정용)
     */
    fun enemyHpL(lvl: Int): Double {
        return LOG10_1500 + (lvl - 1).coerceAtLeast(0) * LOG10_1_12
    }

    /**
     * 오버킬 추가 연쇄 처치 수 (extra)
     * r: 초과 데미지 비율 (dmg / enemy.hp)
     */
    fun calcOverkillExtra(r: Double, isUnderMaxLevel: Boolean): Int {
        if (r < 1.0) return 0
        val logR = log10(r)
        if (logR <= 0.0) return 0
        val rawExtra = floor(log2(logR)).toInt() + 1
        val cap = if (isUnderMaxLevel) 100 else 10
        return rawExtra.coerceIn(0, cap)
    }

    /**
     * 증표 영구 강화 비용 (tkCost) — 원작 웹 규격: Math.round(10 * Math.pow(1.1, tb))
     */
    fun tkCost(tb: Int): Int {
        return kotlin.math.round(10.0 * 1.1.pow(tb.toDouble())).toInt().coerceAtLeast(10)
    }

    /**
     * 환생 회차 획득 포인트 로그값: runPointsL = (log10(runExp) + K) / 2 - 1
     */
    fun runPointsL(runExp: Double, K: Int): Double {
        if (runExp <= 0.0) return 0.0
        val expL = log10(runExp) + K
        return (expL / 2.0 - 1.0).coerceAtLeast(0.0)
    }

    /**
     * 환생 강화 단일 구매 비용 (로그값): 2 + rb * log10(1.6)
     */
    fun rbCostL(rb: Int): Double {
        return 2.0 + rb * LOG10_1_6
    }

    /**
     * 환생 강화 n회 연속 구매 비용 (등비수열 합 로그값)
     */
    fun rbCostNL(rb: Int, n: Int): Double {
        if (n <= 1) return rbCostL(rb)
        val sumRatioL = log10((1.6.pow(n) - 1.0) / 0.6)
        return rbCostL(rb) + sumRatioL
    }

    /**
     * 상점 특전 단일 구매 비용 (로그값): log10(base) + lv * log10(1.6)
     */
    fun perkCostL(base: Double, lv: Int): Double {
        return log10(base) + lv * LOG10_1_6
    }

    /**
     * 상점 특전 n회 연속 구매 비용 (등비수열 합 로그값)
     */
    fun perkCostNL(base: Double, lv: Int, n: Int): Double {
        if (n <= 1) return perkCostL(base, lv)
        val sumRatioL = log10((1.6.pow(n) - 1.0) / 0.6)
        return perkCostL(base, lv) + sumRatioL
    }

    /**
     * 포켓몬 레벨업 비용 (로그값):
     * 1 + (lvl - 1)*log10(1.25) + tb*log10(0.95) + perk('exp')*log10(0.95)
     */
    fun levelUpCostL(lvl: Int, tb: Int = 0, expPerk: Int = 0): Double {
        return 1.0 +
                (lvl - 1).coerceAtLeast(0) * LOG10_1_25 +
                tb * LOG10_0_95 +
                expPerk * LOG10_0_95
    }

    /**
     * Lv.1부터 현재 Lv까지 레벨업에 소모된 누적 경험치 총합 계산 (스케일 K 반영)
     */
    fun calculateTotalExpSpent(lvl: Int, tb: Int = 0, expPerk: Int = 0, K: Int = 0): Double {
        val n = (lvl - 1).coerceAtLeast(0)
        if (n == 0) return 0.0

        val baseL = 1.0 + tb * LOG10_0_95 + expPerk * LOG10_0_95 - K
        if (baseL > 300.0) return Double.MAX_VALUE
        if (baseL < -300.0) return 0.0

        val base = 10.0.pow(baseL)
        val ratioSum = if (n < 500) {
            (1.25.pow(n) - 1.0) / 0.25
        } else {
            1.25.pow(n) / 0.25
        }
        return (base * ratioSum).coerceAtLeast(0.0)
    }

    /**
     * 증표 영구 강화(tb)에 소모된 누적 증표 총합 계산
     */
    fun calculateTotalTokensSpent(tb: Int): Int {
        if (tb <= 0) return 0
        var sum = 0
        for (i in 0 until tb) {
            sum += tkCost(i)
        }
        return sum
    }

    /**
     * 로그값 L을 사람이 읽기 편한 단위(K, M, B, ...) 또는 지수 형식으로 포맷팅
     */
    fun fmtL(L: Double): String {
        if (L.isNaN()) return "0"
        if (L < -4.0) {
            val v = 10.0.pow(L)
            return String.format(java.util.Locale.US, "%.2e", v)
        }
        if (L < 0.0) {
            val v = 10.0.pow(L)
            return String.format(java.util.Locale.US, "%.4f", v)
        }
        if (L < 3.0) {
            val v = 10.0.pow(L)
            return if (v >= 100.0) String.format(java.util.Locale.US, "%.0f", v) else String.format(java.util.Locale.US, "%.1f", v)
        }

        val tier = floor(L / 3.0).toInt()
        val remainder = L - tier * 3.0
        val mantissa = 10.0.pow(remainder)

        return if (tier < UNITS.size) {
            val unit = UNITS[tier]
            if (mantissa >= 100.0) {
                String.format(java.util.Locale.US, "%.0f%s", mantissa, unit)
            } else if (mantissa >= 10.0) {
                String.format(java.util.Locale.US, "%.1f%s", mantissa, unit)
            } else {
                String.format(java.util.Locale.US, "%.2f%s", mantissa, unit)
            }
        } else {
            // 접두어 범위를 초과하는 경우 e형태 표기
            String.format(java.util.Locale.US, "%.2fe%d", mantissa, tier * 3)
        }
    }

    /**
     * 일반 실수 수치(데미지, 경험치 등)를 K, M, B 등 알파벳 축약 단위로 포맷팅
     * - NaN 또는 0 이하: "0"
     * - 1 미만: "0.X" (예: "0.5")
     * - 1 이상 1,000 미만: 정수 표기 ("25", "999")
     * - 1,000 이상: fmtL(log10(value)) 기반 축약 표기 ("1.50K", "12.5K", "150M" 등)
     */
    fun formatNumber(value: Double): String {
        if (value.isNaN() || value <= 0.0) return "0"
        if (value < 1.0) return String.format(java.util.Locale.US, "%.1f", value)
        if (value < 1000.0) return String.format(java.util.Locale.US, "%.0f", value)
        return fmtL(log10(value))
    }
}
