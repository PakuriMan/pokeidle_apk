package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.data.model.ZMoveData
import com.pokeidle.app.domain.model.AllyMon
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.presentation.components.PokemonSprite
import com.pokeidle.app.presentation.components.TypeBadge

/**
 * 포켓몬 도구(Held Items) 장착/해제/이동 관리 모달 다이얼로그
 * - 포켓몬 1마리당 도구 1개 장착 가능
 * - 1종류의 도구는 전 팀/박스 통틀어 1마리만 장착 가능 (다른 포켓몬 선택 시 자동 이전)
 * - 한 마리에는 한 도구만 장착하며, 보유 중복 수량은 효과를 중첩하지 않음
 * - src.html 등록 도구, 메가스톤 및 Z크리스탈 지원
 */
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ItemManageDialog(
    ally: AllyMon,
    gameState: GameState,
    repository: PokemonRepository,
    onEquip: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    val targetPokemon = remember(ally.id) { repository.getPokemon(ally.id) }
    val hasSolgaleo = gameState.team.any { it.id == 791 } || gameState.box.any { it.id == 791 }
    val hasLunala = gameState.team.any { it.id == 792 } || gameState.box.any { it.id == 792 }
    var searchQuery by remember { mutableStateOf("") }
    var pendingFusionItem by remember { mutableStateOf<String?>(null) }
    var selectedCategoryIndex by remember { mutableIntStateOf(0) } // 0: 전체, 1: 타입강화, 2: 배틀도구, 3: Z크리스탈, 4: 메가스톤, 5: 기타

    val categories = listOf("전체", "타입 강화", "배틀 도구", "Z크리스탈", "메가스톤", "기타")

    // 보유 중인 도구 목록 (개수 > 0)
    val ownedItems = remember(gameState.items.size, gameState.items.values.sum()) {
        repository.getAllHeldItems().filter { item ->
            (gameState.items[item.id] ?: 0) > 0
        }
    }

    // 카테고리 & 검색 필터링된 도구 목록
    val filteredItems = remember(ownedItems, selectedCategoryIndex, searchQuery) {
        ownedItems.filter { item ->
            val matchesCategory = when (selectedCategoryIndex) {
                0 -> true
                1 -> item.category == "type-enhancement" || item.category == "plates" || item.category == "memories" || item.category == "jewels"
                2 -> item.category == "held-items" || item.category == "choice" || item.category == "training"
                3 -> item.category == "z-crystals"
                4 -> item.category == "mega-stones"
                else -> item.category !in listOf("type-enhancement", "plates", "memories", "jewels", "held-items", "choice", "training", "z-crystals", "mega-stones")
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                item.ko.contains(searchQuery.trim(), ignoreCase = true) ||
                        item.desc.contains(searchQuery.trim(), ignoreCase = true) ||
                        item.id.contains(searchQuery.trim(), ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }

    val currentHeldDto = remember(ally.item) {
        ally.item?.let { repository.getHeldItem(it) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC9D1C8))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // 1. 헤더: 타이틀 + 닫기 버튼
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🎒 도구 가방 (장착 관리)",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF2F7BD9).copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "보유 종류: ${ownedItems.size}종",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2F7BD9),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "닫기",
                            tint = Color(0xFF5A665E)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 2. 대상 포켓몬 및 현재 장착 도구 카드
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD9E2D6))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        // 포켓몬 요약 행
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (targetPokemon != null) {
                                PokemonSprite(imgBase64 = targetPokemon.img, contentDescription = targetPokemon.ko, size = 36.dp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = targetPokemon?.ko ?: "포켓몬",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Lv.${ally.lvl}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2F7BD9)
                                    )
                                    targetPokemon?.types?.forEach { typeId ->
                                        TypeBadge(typeId = typeId)
                                    }
                                }
                                Text(
                                    text = "현재 지닌 도구 현황",
                                    fontSize = 11.sp,
                                    color = Color(0xFF6A746E)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFE8ECE5))
                        Spacer(modifier = Modifier.height(8.dp))

                        // 현재 장착된 도구 정보
                        if (currentHeldDto != null) {
                            val stack = gameState.getItemStack(currentHeldDto.id)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = currentHeldDto.ko,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFFE08A1B)
                                        )
                                        CategoryBadge(category = currentHeldDto.category)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFE08A1B).copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = "보유: ${stack}개 · 장착 효과 1개분",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFC06A00),
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = currentHeldDto.desc,
                                        fontSize = 11.sp,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 15.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                OutlinedButton(
                                    onClick = { onEquip(null) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD93A2F)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("해제", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "지닌 도구 없음",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF888888)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "· 아래 목록에서 장착할 도구를 선택하세요",
                                    fontSize = 11.sp,
                                    color = Color(0xFF999999)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 3. 카테고리 필터 탭
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEachIndexed { index, name ->
                        val isSelected = selectedCategoryIndex == index
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategoryIndex = index },
                            label = { Text(name, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF2F7BD9),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 4. 검색창
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("도구 이름 또는 설명 검색", fontSize = 11.sp) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "검색", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(18.dp)) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "지우기", tint = Color.Gray)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        cursorColor = Color.Black,
                        focusedPlaceholderColor = Color.Black,
                        unfocusedPlaceholderColor = Color.Black,
                        focusedBorderColor = Color(0xFF2F7BD9),
                        unfocusedBorderColor = Color(0xFFD9E2D6),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(5.dp))

                // 5. 보유 도구 목록 (LazyColumn)
                if (filteredItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (ownedItems.isEmpty()) {
                                "지니게 할 수 있는 도구가 없습니다.\n레벨이 10의 배수인 야생 포켓몬을 쓰러뜨리면 30% 확률로 도구를 획득합니다."
                            } else {
                                "검색 및 필터 결과와 일치하는 도구가 없습니다."
                            },
                            color = Color(0xFF888888),
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredItems, key = { it.id }) { item ->
                            val stack = gameState.getItemStack(item.id)
                            val holders = (gameState.team + gameState.box).filter { it.item == item.id }
                            val holderNames = holders.joinToString { repository.getPokemon(it.id)?.ko ?: "동료" }
                            val isCurrentEquipped = ally.item == item.id
                            val canUseAnotherCopy = isCurrentEquipped || holders.size < stack
                            val canEquipUltraNecrozium = ally.id == 800 && ally.isMega && ally.megaFormId in setOf(10155, 10156)
                            val ultraNecroziumBlocked = item.id == "ultranecrozium-z" && !isCurrentEquipped && !canEquipUltraNecrozium
                            val specialZBlocked = item.category == "z-crystals" && item.id != "ultranecrozium-z" && !isCurrentEquipped && !ZMoveData.canEquip(item.id, ally.id)
                            val zygardeBlocked = item.ko == "지가르데나이트" && ally.id != 10120

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isCurrentEquipped) Color(0xFFEBF3FC) else Color.White
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isCurrentEquipped) Color(0xFF2F7BD9) else Color(0xFFE2E7DF)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            Text(
                                                text = item.ko,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                            )
                                            CategoryBadge(category = item.category)
                                            Text(
                                                text = "보유 ${stack}개",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF2F7BD9)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = item.desc,
                                            fontSize = 11.sp,
                                            color = Color(0xFF555555),
                                            lineHeight = 13.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        if (holders.isNotEmpty() && !isCurrentEquipped) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "장착 중 ${holders.size}마리: $holderNames",
                                                fontSize = 10.sp,
                                                color = Color(0xFF8E5BD1),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        if (item.id == "ash-greninjite" && ally.id !in setOf(658, 10117)) {
                                            Text("개굴닌자 전용 도구입니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                        }
                                        if (ally.id == 800 && item.id == "necropluser-sol" && !hasSolgaleo) {
                                            Text("융합하려면 팀 또는 박스에 솔가레오가 필요합니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                        }
                                        if (ally.id == 800 && item.id == "necropluser-luna" && !hasLunala) {
                                            Text("융합하려면 팀 또는 박스에 루나아라가 필요합니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                        }
                                        if (item.id == "ultranecrozium-z" && !canEquipUltraNecrozium) {
                                            Text("황혼의 갈기 또는 새벽의 날개 폼일 때만 장착할 수 있습니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                        }
                                        if (specialZBlocked) Text("이 포켓몬은 해당 Z크리스탈의 전용 Z기술 사용자 조건에 맞지 않습니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                        if (zygardeBlocked) Text("지가르데 퍼펙트폼 전용 도구입니다.", fontSize = 10.sp, color = Color(0xFFB0261C))
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // 액션 버튼
                                    when {
                                        isCurrentEquipped -> {
                                            Button(
                                                onClick = { onEquip(null) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF888888)),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.heightIn(min = 40.dp)
                                            ) {
                                                Text("해제", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        else -> {
                                            Button(
                                                onClick = {
                                                    if (ally.id == 800 && item.id in setOf("necropluser-sol", "necropluser-luna")) {
                                                        val partnerAvailable = if (item.id == "necropluser-sol") hasSolgaleo else hasLunala
                                                        if (partnerAvailable) pendingFusionItem = item.id
                                                    }
                                                    else onEquip(item.id)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9)),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.heightIn(min = 40.dp),
                                                enabled = !ultraNecroziumBlocked && !specialZBlocked && !zygardeBlocked && canUseAnotherCopy && (item.id != "ash-greninjite" || ally.id in setOf(658, 10117))
                                            ) {
                                                Text(if (holders.isNotEmpty()) "추가 장착" else "지니게 하기", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 6. 하단 닫기 버튼
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A665E)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("닫기", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    pendingFusionItem?.let { itemId ->
        val itemName = repository.getHeldItem(itemId)?.ko ?: "네크로플러스"
        val partnerName = if (itemId == "necropluser-sol") "솔가레오" else "루나아라"
        AlertDialog(
            onDismissRequest = { pendingFusionItem = null },
            title = { Text("융합을 진행할까요?") },
            text = { Text("주의: 네크로즈마는 해당 융합 폼으로 영구 변환되고, ${partnerName}과 $itemName 1개는 소모됩니다. 이 작업은 되돌릴 수 없습니다. 계속하시겠습니까?") },
            confirmButton = {
                TextButton(onClick = {
                    pendingFusionItem = null
                    onEquip(itemId)
                }) { Text("융합하기") }
            },
            dismissButton = {
                TextButton(onClick = { pendingFusionItem = null }) { Text("취소") }
            }
        )
    }
}

@Composable
fun CategoryBadge(category: String) {
    val (label, bg, fg) = when (category) {
        "type-enhancement" -> Triple("타입", Color(0xFF3CAE5C).copy(alpha = 0.15f), Color(0xFF2E8546))
        "plates" -> Triple("플레이트", Color(0xFFE08A1B).copy(alpha = 0.15f), Color(0xFFB36707))
        "memories" -> Triple("메모리", Color(0xFF8E5BD1).copy(alpha = 0.15f), Color(0xFF6F3DB5))
        "jewels" -> Triple("주얼", Color(0xFFD93A2F).copy(alpha = 0.15f), Color(0xFFB0261C))
        "z-crystals" -> Triple("Z크리스탈", Color(0xFF9C27B0).copy(alpha = 0.15f), Color(0xFF7B1FA2))
        "mega-stones" -> Triple("메가스톤", Color(0xFFE91E63).copy(alpha = 0.15f), Color(0xFFC2185B))
        "held-items" -> Triple("배틀", Color(0xFF2F7BD9).copy(alpha = 0.15f), Color(0xFF1E5EB5))
        "choice" -> Triple("구애", Color(0xFFFF5722).copy(alpha = 0.15f), Color(0xFFE64A19))
        "training" -> Triple("육성", Color(0xFF009688).copy(alpha = 0.15f), Color(0xFF00796B))
        "species-specific" -> Triple("전용", Color(0xFFFF9800).copy(alpha = 0.15f), Color(0xFFF57C00))
        else -> Triple("도구", Color.LightGray.copy(alpha = 0.2f), Color.DarkGray)
    }

    Surface(
        shape = RoundedCornerShape(3.dp),
        color = bg
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
        )
    }
}
