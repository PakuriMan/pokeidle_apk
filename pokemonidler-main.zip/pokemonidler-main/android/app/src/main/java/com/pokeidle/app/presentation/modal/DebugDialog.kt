package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pokeidle.app.R
import com.pokeidle.app.data.model.PokemonDto
import com.pokeidle.app.data.repository.PokemonRepository
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.presentation.components.PokemonSprite
import com.pokeidle.app.presentation.components.TypeBadge
import kotlin.math.log10

@Composable
fun DebugDialog(
    gameState: GameState,
    repository: PokemonRepository,
    onDismiss: () -> Unit,
    onAddExp: (Double) -> Unit,
    onAddRp: (Double) -> Unit,
    onResetRp: () -> Unit,
    onAddBalls: (Int, Int, Int) -> Unit,
    onAddAllHeldItems: () -> Unit,
    onAddTokensToParty: (Int) -> Unit,
    onSetAllyLevel: (Int, Int) -> Unit,
    onAddAllyTb: (Int, Int) -> Unit,
    onAddAllyRb: (Int, Int) -> Unit,
    onFillMegaGauge: (Int) -> Unit,
    onHealStatus: (Int) -> Unit,
    onSetSlotPokemon: (Int, Int, Boolean) -> Unit,
    onAddPokemonToBox: (Int, Int, Boolean) -> Unit,
    onSpawnEnemy: (Int, Boolean) -> Unit,
    onKillEnemy: () -> Unit,
    onAddKills: (Long) -> Unit,
    onUnlockAllPokedex: () -> Unit,
    onSetWeather: (String?) -> Unit,
    onSetTerrain: (String?) -> Unit,
    onResetAllSave: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedPartySlot by remember { mutableIntStateOf(0) }
    var showResetConfirm by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // 상단 헤더: 타이틀 & 닫기 버튼
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "🛠️ 개발자 디버그 콘솔",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("✕", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 탭 네비게이션
                val tabs = listOf("재화/EXP", "파티 육성", "소환/도감", "전투/환경")
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF3F5F0),
                    contentColor = Color(0xFF2F7BD9),
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                ) {
                    tabs.forEachIndexed { idx, title ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 탭별 본문 내용
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (selectedTab) {
                        0 -> CurrencyExpTab(
                            gameState = gameState,
                            onAddExp = onAddExp,
                            onAddRp = onAddRp,
                            onResetRp = onResetRp,
                            onAddBalls = onAddBalls,
                            onAddAllHeldItems = onAddAllHeldItems,
                            heldItemCount = repository.getAllHeldItems().size,
                            onAddTokensToParty = onAddTokensToParty
                        )
                        1 -> PartyTrainingTab(
                            gameState = gameState,
                            repository = repository,
                            selectedSlot = selectedPartySlot,
                            onSelectSlot = { selectedPartySlot = it },
                            onSetAllyLevel = onSetAllyLevel,
                            onAddAllyTb = onAddAllyTb,
                            onAddAllyRb = onAddAllyRb,
                            onFillMegaGauge = onFillMegaGauge,
                            onHealStatus = onHealStatus
                        )
                        2 -> SpawnPokedexTab(
                            repository = repository,
                            selectedSlot = selectedPartySlot,
                            onSetSlotPokemon = onSetSlotPokemon,
                            onAddPokemonToBox = onAddPokemonToBox,
                            onSpawnEnemy = onSpawnEnemy,
                            onUnlockAllPokedex = onUnlockAllPokedex
                        )
                        3 -> BattleEnvironmentTab(
                            gameState = gameState,
                            onKillEnemy = onKillEnemy,
                            onAddKills = onAddKills,
                            onSetWeather = onSetWeather,
                            onSetTerrain = onSetTerrain,
                            onRequestReset = { showResetConfirm = true }
                        )
                    }
                }
            }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("⚠ 세이브 데이터 완전 초기화", color = Color(0xFFD93A2F), fontWeight = FontWeight.Bold) },
            text = { Text("정말로 모든 세이브 데이터(파티, 박스, 증표, 환생 등)를 초기화하시겠습니까? 피카츄 Lv.1 상태로 복구됩니다.") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetAllSave()
                        showResetConfirm = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F))
                ) {
                    Text("초기화 실행", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showResetConfirm = false }) {
                    Text("취소")
                }
            }
        )
    }
}

@Composable
private fun CurrencyExpTab(
    gameState: GameState,
    onAddExp: (Double) -> Unit,
    onAddRp: (Double) -> Unit,
    onResetRp: () -> Unit,
    onAddBalls: (Int, Int, Int) -> Unit,
    onAddAllHeldItems: () -> Unit,
    heldItemCount: Int,
    onAddTokensToParty: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. 경험치
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    val expL = if (gameState.exp > 0) log10(gameState.exp) + gameState.K else 0.0
                    Text("✨ 경험치 (EXP)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2F7BD9))
                    Text("현재 EXP: ${BattleMath.fmtL(expL)} (순수: ${String.format("%.0f", gameState.exp)})", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { onAddExp(100_000.0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("+10만", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddExp(10_000_000.0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("+1,000만", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddExp(1_000_000_000.0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("+10억", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddExp(1_000_000_000_000.0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("+1조", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 2. 환생 포인트 (RP)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("🔄 환생 포인트 (Rebirth Points)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE08A1B))
                    Text("현재 RP: ${BattleMath.fmtL(gameState.rpL)}P (log10: ${String.format("%.2f", gameState.rpL)})", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { onAddRp(3.0) }, // 10^3 = 1,000
                            modifier = Modifier.weight(1f).height(32.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                        ) {
                            Text("+1,000P", fontSize = 10.sp)
                        }
                        Button(
                            onClick = { onAddRp(6.0) }, // 10^6 = 1,000,000
                            modifier = Modifier.weight(1f).height(32.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                        ) {
                            Text("+100만P", fontSize = 10.sp)
                        }
                        Button(
                            onClick = { onAddRp(9.0) }, // 10^9 = 1,000,000,000
                            modifier = Modifier.weight(1f).height(32.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                        ) {
                            Text("+10억P", fontSize = 10.sp)
                        }
                        Button(
                            onClick = { onAddRp(15.0) }, // 10^15
                            modifier = Modifier.weight(1f).height(32.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                        ) {
                            Text("+1,000조P", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = onResetRp,
                        modifier = Modifier.fillMaxWidth().height(30.dp),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD93A2F))
                    ) {
                        Text("RP 0P로 초기화", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 3. 몬스터볼
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Image(painter = painterResource(R.drawable.monsterball), contentDescription = null, modifier = Modifier.size(18.dp))
                        Text("몬스터볼 수량 현황", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Image(painter = painterResource(R.drawable.monsterball), contentDescription = null, modifier = Modifier.size(14.dp))
                            Text("몬스터볼: ${gameState.pballs}개", fontSize = 11.sp, color = Color(0xFFD93A2F), fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Image(painter = painterResource(R.drawable.ultraball), contentDescription = null, modifier = Modifier.size(14.dp))
                            Text("하이퍼볼: ${gameState.balls}개", fontSize = 11.sp, color = Color(0xFFE08A1B), fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Image(painter = painterResource(R.drawable.masterball), contentDescription = null, modifier = Modifier.size(14.dp))
                            Text("마스터볼: ${gameState.mballs}개", fontSize = 11.sp, color = Color(0xFF8E5BD1), fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { onAddBalls(50, 0, 0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("일반볼 +50", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddBalls(0, 50, 0) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("하이퍼볼 +50", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddBalls(0, 0, 10) }, modifier = Modifier.weight(1f).height(32.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))) {
                            Text("마스터볼 +10", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 4. 등록된 지닌도구 일괄 지급
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("🎒 지닌 도구 지급", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2F7BD9))
                    Text("등록된 장착 가능 도구 ${heldItemCount}종을 각각 999개 추가합니다.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onAddAllHeldItems,
                        modifier = Modifier.fillMaxWidth().height(34.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))
                    ) {
                        Text("모든 도구 +999개 지급", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5. 파티 증표 일괄 지급
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("💎 증표 지급", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF8E5BD1))
                    Text("현재 파티에 출전 중인 6마리 포켓몬의 종족 증표를 대량으로 지급합니다.", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { onAddTokensToParty(50) },
                            modifier = Modifier.weight(1f).height(32.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                        ) {
                            Text("파티 전원 증표 +50개", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { onAddTokensToParty(500) },
                            modifier = Modifier.weight(1f).height(32.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                        ) {
                            Text("파티 전원 증표 +500개", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PartyTrainingTab(
    gameState: GameState,
    repository: PokemonRepository,
    selectedSlot: Int,
    onSelectSlot: (Int) -> Unit,
    onSetAllyLevel: (Int, Int) -> Unit,
    onAddAllyTb: (Int, Int) -> Unit,
    onAddAllyRb: (Int, Int) -> Unit,
    onFillMegaGauge: (Int) -> Unit,
    onHealStatus: (Int) -> Unit
) {
    val selectedAlly = gameState.team.find { it.slot == selectedSlot }
    val monDto = selectedAlly?.let { repository.getPokemon(it.id) }
    var customLevelInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 슬롯 선택 버튼 바
        item {
            Text("조작할 파티 슬롯을 선택하세요:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2F7BD9))
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0..5) {
                    val ally = gameState.team.find { it.slot == i }
                    val name = ally?.let { repository.getPokemon(it.id)?.ko?.take(2) } ?: "-"
                    val isSel = selectedSlot == i
                    Button(
                        onClick = { onSelectSlot(i) },
                        modifier = Modifier.weight(1f).height(32.dp),
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isSel) Color(0xFF2F7BD9) else Color(0xFFEAEAEA))
                    ) {
                        Text(
                            text = "${i + 1}:$name",
                            fontSize = 10.sp,
                            color = if (isSel) Color.White else Color.Black,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // 선택된 동료 정보
        if (selectedAlly != null && monDto != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PokemonSprite(imgBase64 = monDto.img, contentDescription = monDto.ko, size = 46.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(monDto.ko, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Lv.${selectedAlly.lvl}", fontSize = 12.sp, color = Color(0xFF2F7BD9), fontWeight = FontWeight.Bold)
                                if (selectedAlly.tb > 0) Text("◆${selectedAlly.tb}", fontSize = 10.sp, color = Color(0xFF8E5BD1), fontWeight = FontWeight.Bold)
                                if (selectedAlly.rb > 0) Text("★${selectedAlly.rb}", fontSize = 10.sp, color = Color(0xFFE08A1B), fontWeight = FontWeight.Bold)
                            }
                            Text("메가 게이지: ${String.format("%.1f", selectedAlly.mg)}% · 상태이상: ${if (selectedAlly.status.hasAilment) "있음" else "정상"}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }

            // 레벨 즉시 설정
            item {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("📊 레벨 설정", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2F7BD9))
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(onClick = { onSetAllyLevel(selectedSlot, 1) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("Lv.1", fontSize = 10.sp)
                            }
                            Button(onClick = { onSetAllyLevel(selectedSlot, 50) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("Lv.50", fontSize = 10.sp)
                            }
                            Button(onClick = { onSetAllyLevel(selectedSlot, 100) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("Lv.100", fontSize = 10.sp)
                            }
                            Button(onClick = { onSetAllyLevel(selectedSlot, 500) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("Lv.500", fontSize = 10.sp)
                            }
                            Button(onClick = { onSetAllyLevel(selectedSlot, selectedAlly.lvl + 50) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3CAE5C))) {
                                Text("+50 Lv", fontSize = 10.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = customLevelInput,
                                onValueChange = { customLevelInput = it.filter { ch -> ch.isDigit() } },
                                placeholder = { Text("직접 레벨 입력 (예: 250)", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f).height(44.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Color.Black)
                            )
                            Button(
                                onClick = {
                                    val lvl = customLevelInput.toIntOrNull()
                                    if (lvl != null && lvl > 0) {
                                        onSetAllyLevel(selectedSlot, lvl)
                                    }
                                },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("적용", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 영구 강화 & 환생 강화
            item {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("◆ 증표강화 (현재: ◆${selectedAlly.tb})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF8E5BD1))
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(onClick = { onAddAllyTb(selectedSlot, 1) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("◆+1", fontSize = 10.sp)
                            }
                            Button(onClick = { onAddAllyTb(selectedSlot, 5) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("◆+5", fontSize = 10.sp)
                            }
                            Button(onClick = { onAddAllyTb(selectedSlot, -1) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("◆-1", fontSize = 10.sp)
                            }
                            OutlinedButton(onClick = { onAddAllyTb(selectedSlot, -selectedAlly.tb) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("리셋", fontSize = 10.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("★ 환생강화 (현재: ★${selectedAlly.rb})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFE08A1B))
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(onClick = { onAddAllyRb(selectedSlot, 1) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))) {
                                Text("★+1", fontSize = 10.sp)
                            }
                            Button(onClick = { onAddAllyRb(selectedSlot, 5) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))) {
                                Text("★+5", fontSize = 10.sp)
                            }
                            Button(onClick = { onAddAllyRb(selectedSlot, -1) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))) {
                                Text("★-1", fontSize = 10.sp)
                            }
                            OutlinedButton(onClick = { onAddAllyRb(selectedSlot, -selectedAlly.rb) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                                Text("리셋", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            // 게이지 & 상태이상 회복
            item {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("⚡ 게이지 & 상태", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { onFillMegaGauge(selectedSlot) },
                                modifier = Modifier.weight(1f).height(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                            ) {
                                Text("메가게이지 100%", fontSize = 10.sp)
                            }
                            Button(
                                onClick = { onHealStatus(selectedSlot) },
                                modifier = Modifier.weight(1f).height(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3CAE5C))
                            ) {
                                Text("상태이상 즉시 치료", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                    Text("선택된 슬롯에 포켓몬이 없습니다.", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun SpawnPokedexTab(
    repository: PokemonRepository,
    selectedSlot: Int,
    onSetSlotPokemon: (Int, Int, Boolean) -> Unit,
    onAddPokemonToBox: (Int, Int, Boolean) -> Unit,
    onSpawnEnemy: (Int, Boolean) -> Unit,
    onUnlockAllPokedex: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("25") } // 기본 피카츄(25)
    var addShiny by remember { mutableStateOf(false) }
    val allPokemon = remember { repository.getAllPokemon() }

    val matchedPokemon = remember(searchQuery) {
        val q = searchQuery.trim()
        val num = q.toIntOrNull()
        if (num != null) {
            allPokemon.filter { it.id == num }
        } else if (q.isNotEmpty()) {
            allPokemon.filter { it.ko.contains(q, true) || it.en.contains(q, true) }.take(10)
        } else {
            allPokemon.take(5)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("포켓몬 검색 (도감 번호 1~1025 또는 한글 이름)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2F7BD9))
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("예: 25, 150, 피카츄, 뮤츠", fontSize = 11.sp) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Color.Black)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = addShiny, onCheckedChange = { addShiny = it })
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (addShiny) "이로치 포켓몬으로 추가" else "일반 포켓몬으로 추가", fontSize = 11.sp, color = if (addShiny) Color(0xFF6A43A5) else androidx.compose.material3.MaterialTheme.colorScheme.onSurface)
            }
        }

        // 검색된 포켓몬 결과 목록
        items(matchedPokemon.size) { idx ->
            val p = matchedPokemon[idx]
            Card(
                colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PokemonSprite(imgBase64 = if (addShiny) repository.getShinySprite(p.id) ?: p.img else p.img, contentDescription = if (addShiny) "${p.ko} 이로치" else p.ko, size = 42.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(p.ko, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("No.${p.id}", fontSize = 11.sp, color = Color.Gray)
                                p.types.forEach { t -> TypeBadge(typeId = t) }
                            }
                            Text("${p.gen}세대 · 공격력 ${p.atk} · HP ${p.hp}", fontSize = 10.sp, color = Color(0xFF5A665E))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // 액션 버튼 그리드
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { onSetSlotPokemon(selectedSlot, p.id, addShiny) },
                            modifier = Modifier.weight(1f).height(30.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))
                        ) {
                            Text(if (addShiny) "✨ 슬롯${selectedSlot + 1} 이로치 추가" else "슬롯${selectedSlot + 1} 장착", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { onAddPokemonToBox(p.id, 100, addShiny) },
                            modifier = Modifier.weight(1f).height(30.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3CAE5C))
                        ) {
                            Text(if (addShiny) "✨ 이로치 박스 추가" else "박스 추가(Lv100)", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { onSpawnEnemy(p.id, false) },
                            modifier = Modifier.weight(1f).height(30.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))
                        ) {
                            Text("야생 적으로 출현", fontSize = 10.sp)
                        }
                        Button(
                            onClick = { onSpawnEnemy(p.id, true) },
                            modifier = Modifier.weight(1f).height(30.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E5BD1))
                        ) {
                            Text("✨이로치 적 출현", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 전체 도감 개방 버튼
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9EE)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("📖 전체 도감 마스터", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFD96A1B))
                    Text("전 포켓몬 1,025종을 발견·포획 처리하고, 이로치 도감 플래그도 함께 해금합니다.", fontSize = 10.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onUnlockAllPokedex,
                        modifier = Modifier.fillMaxWidth().height(32.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD96A1B))
                    ) {
                        Text("일반/이로치 도감 전체 해금", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun BattleEnvironmentTab(
    gameState: GameState,
    onKillEnemy: () -> Unit,
    onAddKills: (Long) -> Unit,
    onSetWeather: (String?) -> Unit,
    onSetTerrain: (String?) -> Unit,
    onRequestReset: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 즉시 처치 & 킬수
        item {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("⚔️ 전투 제어", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFD93A2F))
                    Text("현재 처치: ${gameState.kills}마리", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = onKillEnemy,
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F))
                    ) {
                        Text("💥 현재 적 즉시 처치 (Instant Kill)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { onAddKills(100) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("킬수 +100", fontSize = 10.sp)
                        }
                        Button(onClick = { onAddKills(1000) }, modifier = Modifier.weight(1f).height(30.dp), contentPadding = PaddingValues(0.dp)) {
                            Text("킬수 +1,000", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // 날씨 강제 변경
        item {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("🌦 날씨 강제 변경", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFD96A1B))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { onSetWeather(null) }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) {
                            Text("해제", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetWeather("SUNNY") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE08A1B))) {
                            Text("쾌청", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetWeather("RAIN") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F7BD9))) {
                            Text("비", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetWeather("SANDSTORM") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8D6E63))) {
                            Text("모래바람", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetWeather("SNOW") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81D4FA))) {
                            Text("싸라기눈", fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        // 필드/지형 강제 변경
        item {
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("🌿 필드(지형) 강제 변경", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { onSetTerrain(null) }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) {
                            Text("해제", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetTerrain("ELECTRIC") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFBC02D))) {
                            Text("일렉트릭", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetTerrain("GRASSY") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))) {
                            Text("그래스", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetTerrain("MISTY") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE91E63))) {
                            Text("미스트", fontSize = 9.sp)
                        }
                        Button(onClick = { onSetTerrain("PSYCHIC") }, modifier = Modifier.weight(1f).height(28.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C27B0))) {
                            Text("사이코", fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        // 세이브 데이터 초기화
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("⚠️ 위험 구역 (Data Reset)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFD93A2F))
                    Text("진행 상황을 모두 삭제하고 최초 시작 상태로 초기화합니다.", fontSize = 10.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = onRequestReset,
                        modifier = Modifier.fillMaxWidth().height(32.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD93A2F))
                    ) {
                        Text("세이브 데이터 완전 초기화", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
