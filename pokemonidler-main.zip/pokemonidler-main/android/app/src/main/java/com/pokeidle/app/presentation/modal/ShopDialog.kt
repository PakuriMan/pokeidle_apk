package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pokeidle.app.data.model.HeldItemDto
import com.pokeidle.app.domain.model.GameState

@Composable
fun ShopDialog(state: GameState, catalog: List<HeldItemDto>, onBuy: (String) -> Unit, onDismiss: () -> Unit) {
    var search by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("일반 상점 · ${state.coins}코인") }, text = {
        Column {
            Text("적 처치 시 100레벨당 1코인 · 모든 도구 개당 1코인")
            OutlinedTextField(value = search, onValueChange = { search = it }, placeholder = { Text("아이템 이름·설명 검색") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(catalog.filter { search.isBlank() || it.ko.contains(search.trim(), true) || it.desc.contains(search.trim(), true) }, key = { it.id }) { item ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text("${item.ko} · 보유 ${state.items[item.id] ?: 0}개")
                        Text(item.desc, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { onBuy(item.id) }, enabled = state.coins > 0) { Text("1코인 구매") }
                    }
                }
            }
        }
    }, confirmButton = { Button(onClick = onDismiss) { Text("닫기") } })
}
