package com.pokeidle.app.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokeidle.app.R
import com.pokeidle.app.domain.math.BattleMath
import com.pokeidle.app.domain.model.GameState
import com.pokeidle.app.domain.system.ActiveTerrain
import com.pokeidle.app.domain.system.ActiveWeather

@Composable
fun GameTopBar(
    gameState: GameState,
    teamDps: String = "0",
    expPerSecond: String = "초당 약 0 EXP",
    currentWeather: ActiveWeather?,
    currentTerrain: ActiveTerrain?,
    onChangeRegion: (Int) -> Unit,
    onOpenDebug: () -> Unit = {},
    onOpenPokedex: () -> Unit = {},
    onOpenShop: () -> Unit = {},
    onOpenPrestige: () -> Unit = {},
    onOpenAchievements: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showRegionMenu by remember { mutableStateOf(false) }
    var toolboxExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFFFFFFF), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFD3DCD0), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        // 1. 경험치 & 킬 수 & 지역 선택 & 디버그 도구 & 도감 버튼
        Row(
            modifier = Modifier.fillMaxWidth().clickable { toolboxExpanded = !toolboxExpanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // EXP 상자
            Column(modifier = Modifier.clickable { toolboxExpanded = !toolboxExpanded }) {
                val expL = if (gameState.exp > 0) kotlin.math.log10(gameState.exp) + gameState.K else 0.0
                Text(
                    text = "EXP: ${BattleMath.fmtL(expL)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF2F7BD9)
                )
                Text(
                    text = "처치: ${gameState.kills}마리 (Lv.${1 + gameState.kills / 4})",
                    fontSize = 11.sp,
                    color = Color(0xFF5A665E)
                )
                Text(if (toolboxExpanded) "▲ 툴박스 접기" else "▼ 툴박스 펼치기", fontSize = 9.sp, color = Color.Gray)
            }

            // 상단 우측 버튼군 (디버그 바로 아래 도감 배치 & 지역 선택)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 디버그 버튼 및 그 바로 아래 배치된 도감 버튼
                Column(
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    if (com.pokeidle.app.BuildConfig.DEBUG) {
                    Button(
                        onClick = onOpenDebug,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A5568)),
                        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Text(
                            text = "🛠️ 디버그",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    }
                    // 도감 버튼
                    Button(
                        onClick = onOpenPokedex,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD93A2F)),
                        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.pokedex),
                            contentDescription = "도감",
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "도감",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 지역 선택 버튼
                Box {
                    Button(
                        onClick = { showRegionMenu = true },
                        colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(55.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "🗺 ${getRegionName(gameState.region)}",
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "(${gameState.region}세대)",
                                color = Color(0xFF5A665E),
                                fontSize = 9.sp
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showRegionMenu,
                        onDismissRequest = { showRegionMenu = false }
                    ) {
                        for (gen in 1..9) {
                            DropdownMenuItem(
                                text = { Text("${gen}세대: ${getRegionName(gen)}") },
                                onClick = {
                                    onChangeRegion(gen)
                                    showRegionMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        if (toolboxExpanded) {
            val dexCaught = gameState.caught.count { it.value > 0 }
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFD3DCD0))
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("누적 경험치", fontSize = 9.sp, color = Color.Gray)
                    Text(BattleMath.fmtL(gameState.totalL), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2F7BD9))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("도감 보너스", fontSize = 9.sp, color = Color.Gray)
                    Text("+$dexCaught%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3CAE5C))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("DPS", fontSize = 9.sp, color = Color.Gray)
                    Text(teamDps, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD93A2F))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(expPerSecond, fontSize = 10.sp, color = Color(0xFF5A665E), modifier = Modifier.align(Alignment.End))
            Spacer(modifier = Modifier.height(5.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("도감" to onOpenPokedex, "🪙 상점" to onOpenShop, "🌀 환생상점" to onOpenPrestige, "🏆 업적" to onOpenAchievements, "⚙ 설정" to onOpenSettings).forEach { (label, action) ->
                    Button(
                        onClick = action,
                        modifier = Modifier.weight(1f).height(30.dp),
                        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 1.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (label == "도감") Color(0xFFD93A2F) else androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant)
                    ) { if (label == "도감") Image(painterResource(R.drawable.pokedex), contentDescription = null, modifier = Modifier.size(13.dp)); Text(label, fontSize = 9.sp, color = if (label == "도감") Color.White else androidx.compose.material3.MaterialTheme.colorScheme.onSurface, maxLines = 1) }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. 보유 볼 수량 & 날씨 / 필드 배지
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 볼 현황 (몬스터볼, 하이퍼/울트라볼, 마스터볼 스프라이트 아이콘)
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 몬스터볼 (포켓볼)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.monsterball),
                        contentDescription = "몬스터볼",
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "${gameState.pballs}",
                        fontSize = 11.sp,
                        color = Color(0xFFD93A2F),
                        fontWeight = FontWeight.Bold
                    )
                }

                // 하이퍼/울트라볼
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ultraball),
                        contentDescription = "하이퍼볼",
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "${gameState.balls}",
                        fontSize = 11.sp,
                        color = Color(0xFFE08A1B),
                        fontWeight = FontWeight.Bold
                    )
                }

                // 마스터볼
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.masterball),
                        contentDescription = "마스터볼",
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "${gameState.mballs}",
                        fontSize = 11.sp,
                        color = Color(0xFF8E5BD1),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 날씨 및 필드
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (currentWeather != null) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFFFF2D6), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${currentWeather.weather.icon} ${currentWeather.weather.ko}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD96A1B)
                        )
                    }
                }

                if (currentTerrain != null) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFE8F5E9), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${currentTerrain.terrain.icon} ${currentTerrain.terrain.ko}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }
        }
    }
}

fun getRegionName(gen: Int): String {
    return when (gen) {
        1 -> "관동"
        2 -> "성도"
        3 -> "호연"
        4 -> "신오"
        5 -> "하나"
        6 -> "칼로스"
        7 -> "알로라"
        8 -> "가라르"
        9 -> "팔데아"
        else -> "관동"
    }
}
