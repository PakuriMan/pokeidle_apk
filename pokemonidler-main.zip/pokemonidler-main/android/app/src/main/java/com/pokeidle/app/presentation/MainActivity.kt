package com.pokeidle.app.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.pokeidle.app.presentation.theme.PokéIdleTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val preferences = androidx.compose.runtime.remember { getSharedPreferences("pokeidle-settings", MODE_PRIVATE) }
            val dark = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(preferences.getBoolean("dark_mode", false)) }
            androidx.compose.runtime.DisposableEffect(preferences) {
                val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { prefs, key -> if (key == "dark_mode") dark.value = prefs.getBoolean(key, false) }
                preferences.registerOnSharedPreferenceChangeListener(listener)
                onDispose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
            }
            PokéIdleTheme(darkTheme = dark.value, dynamicColor = false) {
                Scaffold { innerPadding ->
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        GamePlayScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
