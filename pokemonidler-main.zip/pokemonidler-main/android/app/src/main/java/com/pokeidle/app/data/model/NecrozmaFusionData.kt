package com.pokeidle.app.data.model

object NecrozmaFusionData {
    const val DUSK_MANE_FORM_ID = 10155
    const val DAWN_WINGS_FORM_ID = 10156

    fun formIdForItem(itemId: String): Int? = when (itemId) {
        "necropluser-sol" -> DUSK_MANE_FORM_ID
        "necropluser-luna" -> DAWN_WINGS_FORM_ID
        else -> null
    }

    fun partnerIdForItem(itemId: String): Int? = when (itemId) {
        "necropluser-sol" -> 791 // 솔가레오
        "necropluser-luna" -> 792 // 루나아라
        else -> null
    }
}
