package com.pokeidle.app.domain.engine

/**
 * 전투 루프 중 발생하는 시청각/UI 이벤트
 */
sealed class BattleEvent {
    data class Hit(
        val slot: Int,
        val damage: Double,
        val isSuperEffective: Boolean,
        val isNotVeryEffective: Boolean,
        val isCritical: Boolean,
        val moveType: Int
    ) : BattleEvent()

    data class Miss(val slot: Int) : BattleEvent()

    data class EnemyResist(val moveName: String, val message: String) : BattleEvent()

    data class Overkill(val extraKills: Int) : BattleEvent()

    data class EnemyDefeated(
        val pokemonId: Int,
        val isShiny: Boolean,
        val expGained: Double
    ) : BattleEvent()

    data class PokemonCaught(
        val pokemonId: Int,
        val isSentToBox: Boolean,
        val slot: Int,
        val isShiny: Boolean = false
    ) : BattleEvent()

    data class TokenGained(
        val pokemonId: Int,
        val count: Int
    ) : BattleEvent()

    data class BallRewarded(
        val ballType: String, // "poke", "ultra", "master"
        val count: Int
    ) : BattleEvent()

    data class ShinyEncounter(val pokemonId: Int) : BattleEvent()

    data class LevelUp(val slot: Int, val newLevel: Int) : BattleEvent()

    data class Evolution(val slot: Int, val oldId: Int, val newId: Int) : BattleEvent()

    data class MegaEvolution(val slot: Int, val formName: String) : BattleEvent()

    data class MegaRevert(val slot: Int) : BattleEvent()

    data class ItemDropped(
        val itemId: String,
        val itemName: String,
        val count: Int
    ) : BattleEvent()

    data class ItemEquipped(
        val slot: Int,
        val itemId: String?,
        val itemName: String
    ) : BattleEvent()

    data class LogMessage(val text: String) : BattleEvent()
}
