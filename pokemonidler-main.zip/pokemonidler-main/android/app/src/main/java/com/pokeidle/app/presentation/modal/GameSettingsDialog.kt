package com.pokeidle.app.presentation.modal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.material3.Switch
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun GameSettingsDialog(
    bgmVolume: Float,
    sfxVolume: Float,
    onBgmVolumeChange: (Float) -> Unit,
    onSfxVolumeChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pokeidle-settings", android.content.Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }
    var credits by remember { mutableStateOf(false) }
    if (credits) AlertDialog(onDismissRequest = { credits = false }, title = { Text("크레딧") }, text = { Text("special thanks to 생리혈(oo9x981)") }, confirmButton = { Button(onClick = { credits = false }) { Text("닫기") } })
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("⚙ 환경 설정") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("배경음악 음량 ${(bgmVolume * 100).toInt()}%")
                Slider(value = bgmVolume, onValueChange = onBgmVolumeChange, valueRange = 0f..1f, modifier = Modifier.fillMaxWidth())
                Text("효과음 음량 ${(sfxVolume * 100).toInt()}%")
                Slider(value = sfxVolume, onValueChange = onSfxVolumeChange, valueRange = 0f..1f, modifier = Modifier.fillMaxWidth())
                Text("다크모드")
                Switch(checked = dark, onCheckedChange = { dark = it; prefs.edit().putBoolean("dark_mode", it).apply() })
                Button(onClick = { credits = true }) { Text("크레딧") }
                Text("음악 저작권: GAME FREAK / Nintendo / Creatures · 비영리 팬 제작물")
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("닫기") } }
    )
}

