package com.pokeidle.app.presentation.components

import android.graphics.BitmapFactory
import android.graphics.Bitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import android.util.Base64
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.concurrent.ConcurrentHashMap

object SpriteCache {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()

    fun decodeBase64ToBitmap(base64Str: String): ImageBitmap? {
        if (base64Str.isEmpty()) return null
        return cache.getOrPut(base64Str) {
            try {
                val cleanBase64 = if (base64Str.startsWith("data:")) {
                    base64Str.substringAfter("base64,")
                } else {
                    base64Str
                }
                val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                bitmap?.asImageBitmap() ?: return null
            } catch (e: Exception) {
                null
            }
        }
    }

    fun decodeAssetToBitmap(context: Context, assetPath: String): ImageBitmap? {
        return cache.getOrPut("asset:$assetPath") {
            try {
                context.assets.open(assetPath).use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                } ?: return null
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * 픽셀 도트가 뭉개지지 않도록 FilterQuality.None을 적용한 포켓몬 스프라이트 컴포저블
 */
@Composable
fun PokemonSprite(
    imgBase64: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    spriteAssetName: String? = null,
    centerVisiblePixels: Boolean = false
) {
    val context = LocalContext.current
    val bitmap = remember(imgBase64, spriteAssetName, context) {
        spriteAssetName?.let { SpriteCache.decodeAssetToBitmap(context, it) }
            ?: SpriteCache.decodeBase64ToBitmap(imgBase64)
    }

    val centered = remember(bitmap, centerVisiblePixels) {
        if (bitmap == null || !centerVisiblePixels) bitmap else {
            val source = bitmap.asAndroidBitmap()
            var left = source.width
            var top = source.height
            var right = -1
            var bottom = -1
            for (y in 0 until source.height) for (x in 0 until source.width) {
                if ((source.getPixel(x, y) ushr 24) > 0) {
                    left = minOf(left, x); right = maxOf(right, x)
                    top = minOf(top, y); bottom = maxOf(bottom, y)
                }
            }
            if (right < left) bitmap else Bitmap.createBitmap(source, left, top, right - left + 1, bottom - top + 1).asImageBitmap()
        }
    }
    if (centered != null) {
        Image(
            bitmap = centered,
            contentDescription = contentDescription,
            modifier = modifier.size(size),
            filterQuality = FilterQuality.None
        )
    }
}
