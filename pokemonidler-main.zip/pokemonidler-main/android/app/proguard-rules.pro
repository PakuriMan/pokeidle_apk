# kotlinx.serialization: keep @Serializable classes
-keepattributes *Annotation*
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
-keep,includedescriptorclasses class com.pokeidle.app.**$$serializer { *; }
-keepclassmembers class com.pokeidle.app.** {
    *** Companion;
}
